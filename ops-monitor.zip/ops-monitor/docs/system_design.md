# Ops-Monitor v1.9.8 架构与代码审查报告

> 审查日期：2025-07-17 | 审查人：Bob (Architect) | 项目版本：v1.9.8

---

## 一、总体评分

| 维度 | 评分 | 说明 |
|------|------|------|
| **架构设计** | **B** | Agent-Server 架构清晰，但单体控制器和脚本过于臃肿 |
| **代码质量** | **B-** | 注释质量好，但代码重复、内联导入、混合关注点问题突出 |
| **数据库设计** | **B** | SQLite 选择合理，WAL 模式优化到位，但缺少正式迁移机制 |
| **Agent 采集逻辑** | **B+** | 覆盖面广、兼容性好(DMS)、有完善的异常保护，但串行采集有优化空间 |
| **前端架构** | **C+** | 功能完整但模板臃肿，JS/CSS 内联，无构建工具链 |
| **安全性** | **A-** | CSRF、暴力破解防护、会话管理、Token 认证、加密存储均覆盖 |
| **综合评分** | **B** | 生产可用的监控系统，有明确的技术债务需要分阶段偿还 |

---

## 二、发现问题列表（按严重性排序）

### 🔴 严重 (Critical) — 3 项

| ID | 问题 | 位置 | 影响 |
|----|------|------|------|
| **C01** | **app.py 严重单体化 (1790行)**：路由、认证、数据导出、后台线程调度全部耦合在一个文件。`create_app()` 函数内部启动4个后台线程(export-scheduler, session-cleanup, WAL-checkpoint, export-scheduler)，使单测和模块复用极其困难 | `server/app.py:33-1777` | 可维护性、可测试性 |
| **C02** | **agent.py 严重单体化 (3014行)**：采集逻辑、HTTP 上报、安全检测、RAID 采集、NTP 同步全部在一个文件，没有模块拆分。任何一个采集模块修改都可能影响整体稳定性 | `agent/agent.py:1-3014` | 可维护性、扩展性 |
| **C03** | **缺少数据库迁移框架**：`init_db()` 使用手写 ALTER TABLE 做 schema 迁移（`database.py:314-328`），无版本控制、无回滚能力、无迁移历史记录。生产环境升级风险高 | `server/database.py:306-332` | 数据库升级安全 |

### 🟠 高危 (High) — 5 项

| ID | 问题 | 位置 | 影响 |
|----|------|------|------|
| **H01** | **内联导入泛滥**：`import threading` 在 `app.py:38, 1720` 两处导入；`import secrets` 在 `app.py:174, 343, 390, 987` 及 `database.py:344` 共5处重复导入；`from sqlalchemy import func` 在 `app.py:670, 1194` 重复导入 | `app.py` 多处 | 代码规范、可读性 |
| **H02** | **`__import__('datetime')` 非标准导入**：`app.py:1375` 使用了 `__import__('datetime').time.min`，这是反模式，应使用标准 import 语句 | `server/app.py:1375` | 代码可读性 |
| **H03** | **数据库手动级联删除**：删除节点时手动逐表删除关联数据（`app.py:1024-1032`），而非使用 SQLAlchemy 的 `cascade` 配置。容易遗漏新增的关联表 | `server/app.py:1021-1035` | 数据完整性 |
| **H04** | **网络流量采集 sleep 阻塞**：`get_network_info()` 使用 `time.sleep(1)` 做两次采样差值计算（`agent.py:837`），在主采集流程中引入强制1秒延迟 | `agent/agent.py:837` | 采集效率 |
| **H05** | **`ps aux` 解析脆弱**：进程采集依赖 `ps aux` 输出解析（`agent.py:988-1000`），不同发行版/区域设置的列格式可能不同（USER 列含空格时会偏移）。无结构化替代方案 | `agent/agent.py:970-1056` | 跨平台兼容性 |

### 🟡 中危 (Medium) — 7 项

| ID | 问题 | 位置 | 影响 |
|----|------|------|------|
| **M01** | **阈值检查与告警服务紧耦合**：`check_thresholds()` 直接创建 `AlertRecord`，无法独立测试阈值逻辑。阈值配置分散在 `SystemConfig` 和 `Node.thresholds` 两处 | `services/alert_service.py:154-373` | 可测试性 |
| **M02** | **清理逻辑散落各处**：数据清理（90天/30天）在 `api_report_metrics()` 内概率触发（2%），与业务逻辑耦合。清理失败可能影响正常上报 | `server/app.py:449-471` | 职责分离 |
| **M03** | **HTML 模板体积过大**：`node_detail.html`(28KB)、`settings.html`(20KB)、`base.html`(16KB) 包含大量内联 JS/CSS。模板间可能存在重复代码 | `templates/*.html` | 前端可维护性 |
| **M04** | **ECharts CDN 强依赖**：报表和仪表盘通过 CDN 加载 ECharts (`report_service.py:135` + 模板)，内网环境无法使用 | `services/report_service.py:135` | 离线可用性 |
| **M05** | **报表生成内存风险**：`get_dashboard_data()` 一次性加载所有节点2000条快照到内存，多节点场景下可能 OOM | `services/report_service.py:180-391` | 性能、稳定性 |
| **M06** | **无响应数据分页的 API**：`api_node_detail()` 返回节点所有关联数据，无分页；登录记录、安全事件限制了20-50条但端口记录限制200条仍可能过大 | `server/app.py:728-832` | API 性能 |
| **M07** | **`service.sh` 使用 `&` 后台运行**：Agent 通过 shell 脚本 `&` 和 `nohup` 管理进程，无 systemd/ supervisor 集成 | `agent/service.sh` | 运维标准化 |

### 🔵 低危 (Low) — 4 项

| ID | 问题 | 位置 | 影响 |
|----|------|------|------|
| **L01** | **`config/` 目录仅一个模板文件**：可以考虑合并到 agent/ 或 server/ 目录减少目录层级 | `config/agent.conf.template` | 项目结构 |
| **L02** | **密码明文写入文件**：`default_admin_password.txt` 和 `password_reset.txt` 在首次使用后应确保被删除（依赖登录/定时清理），但存在残留风险 | `database.py:353-361`, `main.py:46-50` | 安全性（低风险，已 chmod 600） |
| **L03** | **`requirements.txt` 未锁定次版本**：`Flask>=2.3.2,<4.0` 允许次版本自动升级，可能导致不兼容 | `requirements.txt:7` | 部署稳定性 |
| **L04** | **缺少 `__init__.py`**：`server/` 根目录缺少包初始化文件，可能导致某些工具/IDE 的导入问题 | `server/` | 工具兼容性 |

---

## 三、详细分析

### 3.1 架构设计

#### 3.1.1 当前架构

```
┌──────────────────────────────────────────────────────┐
│                    Agent (Python 3 stdlib)            │
│  agent.py (3014行单体)                                │
│  ├── 采集模块 (CPU/内存/磁盘/SMART/进程/安全/RAID)      │
│  ├── HTTP上报 (gzip + retry + pending cache)          │
│  ├── Token管理 / NTP对时                              │
│  └── 信号处理 (SIGALRM/SIGTERM)                       │
└────────────────────┬─────────────────────────────────┘
                     │ HTTP POST (gzip JSON)
                     ▼
┌──────────────────────────────────────────────────────┐
│                  Server (Flask + SQLite)              │
│  app.py (1790行单体)                                  │
│  ├── Web页面路由 (8个模板)                             │
│  ├── 数据上报API (/api/report/*)                       │
│  ├── Dashboard查询API (/api/nodes/*)                   │
│  ├── 用户认证 + CSRF防护                               │
│  ├── 配置管理 / 数据导出                               │
│  └── 4个后台线程 (export/session/WAL/cleanup)          │
│                                                       │
│  services/                                            │
│  ├── alert_service.py  ── 阈值检查 + 邮件发送          │
│  ├── offline_detector.py ── 离线检测                   │
│  └── report_service.py ── 报表生成                     │
│                                                       │
│  database.py ── 11个模型 + init_db (迁移+种子数据)     │
│  crypto_utils.py ── Fernet 加密                       │
│  main.py ── 多服务启动器                              │
└──────────────────────────────────────────────────────┘
```

#### 3.1.2 优点

1. **Agent-Server 分离**：职责清晰，Agent 仅负责采集和上报，Server 负责存储、展示和告警
2. **Agent 零外部依赖**：纯 Python 3 标准库，部署简单（scp + cron 即可）
3. **多层兼容设计**：对 Synology DSM、标准 Linux 均有适配路径
4. **安全防护完善**：CSRF、暴力破解锁定、会话固定攻击防护、Token 认证、敏感字段加密
5. **原子文件写入**：所有缓存/配置文件写入均采用 `.tmp + rename` 模式，防止 SIGTERM 导致损坏

#### 3.1.3 主要问题

1. **app.py 和 agent.py 均超过1500行**，是 "God Object" 反模式。建议：
   - `app.py` → 拆分为 `routes/web.py`, `routes/api_nodes.py`, `routes/api_reports.py`, `routes/api_auth.py`, `middleware.py`, `tasks.py`
   - `agent.py` → 拆分为 `collectors/cpu.py`, `collectors/memory.py`, `collectors/disk.py`, `collectors/smart.py`, `collectors/security.py`, `reporter.py`

2. **后台线程直接启动于 `create_app()`**：使得应用工厂函数有副作用，不利于测试。建议移至 `main.py` 或独立 `scheduler.py`

3. **无服务层抽象**：路由直接操作数据库模型，无 Service/Repository 层。建议引入分层：
   ```
   Route → Service → Repository → Model
   ```

### 3.2 代码质量

#### 3.2.1 优点

1. **中文注释详尽**：所有函数和关键逻辑都有清晰的中文注释
2. **版本追踪**：`deploy.sh` 包含完整的版本修复历史，便于追溯
3. **防御性编程**：`MAX_WALL_TIME`、`MAX_CAPTURE_BYTES`、`MAX_PAYLOAD_BYTES` 等硬限制保护系统稳定性
4. **异常隔离**：各采集模块独立 try-except，单个模块失败不影响整体

#### 3.2.2 主要问题

1. **内联导入泛滥**（H01）：7+处函数内 import，应全部移至文件顶部
2. **代码重复**：
   - 节点查找/创建逻辑在 `node_api_auth`(172-195行)、`_get_or_create_node`(386-398行)、`api_report_metrics`(410-418行) 三处重复
   - 配置读取 `get_config()` / `_get_cfg()` / `_get_export_config_val()` 三个几乎相同的函数
   - `_build_export_data` 和 `_parse_iso` 等辅助函数仅在一个调用方使用
3. **`__import__('datetime')` 使用**（H02）：应替换为标准 `from datetime import time`
4. **`import random` 仅用于概率清理**(app.py:451)：建议将清理逻辑提取到独立后台任务

### 3.3 数据库设计

#### 3.3.1 优点

1. **SQLite WAL 模式**：有效提升并发读写性能
2. **定期 WAL checkpoint**：防止 WAL 文件无限增长
3. **复合索引设计合理**：`idx_snapshot_node_time`、`idx_port_node_time`
4. **JSON 字段灵活存储**：disk_info、net_info、raid_info 等半结构化数据用 JSON 存储合理

#### 3.3.2 主要问题

1. **无正式迁移框架**(C03)：手动 ALTER TABLE 无版本号、无回滚
2. **手动级联删除**(H03)：应使用 SQLAlchemy `cascade='all, delete-orphan'` 配置
3. **`raw_data` 冗余存储**：每条 MetricsSnapshot 存储完整 JSON 原文，导致数据库膨胀。当前有30天清理策略但仍有风险
4. **无数据归档策略**：仅删除90天前数据，无冷热分离或聚合策略
5. **`AssetRecord.software_list` 字段**：注释说"已移除软件清单"，但字段仍在表中

### 3.4 Agent 采集逻辑

#### 3.4.1 优点

1. **采集覆盖面广**：CPU/内存/磁盘/SMART/温度/进程/安全/RAID/端口/网卡/资产，全方位覆盖
2. **DSM 兼容性极好**：`synodisk`、`synohdparm`、`synodmidecode` 等多路径适配
3. **磁盘温度/SMART 并行采集**：使用 `ThreadPoolExecutor` 控制并发度（最多4线程）
4. **CPU 采样策略优秀**：在所有重操作前后分别采样 `/proc/stat`，消除采集过程自身的 CPU 干扰
5. **安全保护齐全**：Wall-clock 超时、输出截断、payload 截断、pending 缓存限制、磁盘文件大小预检
6. **原子写入模式**：所有持久化文件使用 `.tmp + rename` 模式

#### 3.4.2 主要问题

1. **`get_network_info()` 阻塞1秒**(H04)：这是串行路径上的强制等待，影响总采集时间。可通过将第一次采样提前到采集开始时来解决
2. **进程采集串行执行**：`get_process_info()` 在主线程执行且依赖 `ps aux` 输出解析(H05)，耗时可能较长
3. **无增量采集**：每次都采集全量数据，即使某些指标未变化
4. **NTP 同步仅首次执行**：长时间运行的 cron 任务可能产生时间漂移
5. **`_run_pipe` 使用 `shell=True`**：虽然注释说明仅用于硬编码命令，但仍然是安全边界上的风险点

### 3.5 前端架构

#### 3.5.1 优点

1. **Bootstrap 5 + ECharts**：成熟稳定的技术选型
2. **模板继承**：`base.html` 提供统一布局
3. **CSRF 双重验证**：表单 + AJAX Header 均支持
4. **报表 HTML 可直接离线查看**：内嵌样式和数据

#### 3.5.2 主要问题

1. **模板体积大**：`node_detail.html`(28KB) 包含大量内联 JavaScript
2. **无前端构建工具**：无 bundler（webpack/vite）、无 CSS 预处理、无 JS 压缩
3. **ECharts CDN 依赖**：离线环境不可用
4. **AJAX 请求分散**：各模板各自发起数据请求，无统一的 API 客户端模块
5. **报表生成使用字符串拼接**：`_render_report_html()` 通过 f-string 拼接 HTML，可读性差

---

## 四、改进建议（按优先级）

### 第一优先：安全与稳定（建议 v1.9.9 完成）

| 建议 | 关联问题 | 工作量 |
|------|---------|--------|
| 将所有内联 `import` 移至文件顶部 | H01, H02 | 1h |
| 为 `MetricsSnapshot`、`ProcessRecord` 等关联表添加 SQLAlchemy cascade 配置 | H03 | 2h |
| 将数据清理逻辑从 `api_report_metrics()` 提取到独立后台任务 | M02 | 2h |
| 在 `requirements.txt` 中使用 `==` 锁定当前稳定版本 | L03 | 0.5h |

### 第二优先：架构重构（建议 v2.0 完成）

| 建议 | 关联问题 | 工作量 |
|------|---------|--------|
| **拆分 `app.py`**：路由 → `routes/`，中间件 → `middleware.py`，后台任务 → `tasks.py` | C01 | 8h |
| **拆分 `agent.py`**：采集器 → `collectors/`，上报 → `reporter.py`，工具 → `utils.py` | C02 | 8h |
| **引入 Alembic 迁移框架**，替代手写 ALTER TABLE | C03 | 3h |
| 引入 Service 层，解耦路由与数据库操作 | M01 | 4h |

### 第三优先：性能与运维（建议 v2.1 完成）

| 建议 | 关联问题 | 工作量 |
|------|---------|--------|
| 优化 `get_network_info()` 采样时序，消除 sleep(1) 阻塞 | H04 | 1h |
| 引入 `/proc/pid/stat` 替代 `ps aux` 解析进程信息 | H05 | 3h |
| 报表查询添加流式处理，避免一次性加载全部快照 | M05 | 3h |
| 添加 systemd service 文件替代 `service.sh` | M07 | 1h |
| 前端引入 Vite + TypeScript 构建工具链 | M03, M04 | 16h |

---

## 五、架构评分明细

| 评估维度 | 子项 | 评分 | 权重 | 加权分 |
|----------|------|------|------|--------|
| **架构设计** | 模块划分 | C | 25% | 0.50 |
| | 耦合度 | B | 25% | 0.75 |
| | 可扩展性 | B | 25% | 0.75 |
| | 设计模式应用 | B | 25% | 0.75 |
| | **小计** | | | **2.75 → B** |
| **代码质量** | 命名规范 | B | 20% | 0.60 |
| | 注释质量 | A | 20% | 0.80 |
| | 错误处理 | B+ | 25% | 0.88 |
| | 代码重复 | C+ | 20% | 0.50 |
| | 导入规范 | C | 15% | 0.30 |
| | **小计** | | | **3.08 → B-** |
| **数据库设计** | 表结构合理性 | B+ | 30% | 1.05 |
| | 索引设计 | B+ | 25% | 0.88 |
| | 迁移策略 | D | 25% | 0.25 |
| | 数据生命周期 | B | 20% | 0.60 |
| | **小计** | | | **2.78 → B** |
| **Agent采集** | 采集效率 | B | 25% | 0.75 |
| | 并发设计 | B+ | 20% | 0.70 |
| | 异常处理 | A | 30% | 1.20 |
| | 兼容性 | A | 25% | 1.00 |
| | **小计** | | | **3.65 → B+** |
| **前端架构** | 模板结构 | B- | 30% | 0.80 |
| | 前后端交互 | B | 30% | 0.90 |
| | 构建工具链 | D | 20% | 0.20 |
| | 离线可用性 | C | 20% | 0.40 |
| | **小计** | | | **2.30 → C+** |
| **安全性** | 认证机制 | A | 25% | 1.00 |
| | CSRF 防护 | A | 20% | 0.80 |
| | 数据加密 | A | 25% | 1.00 |
| | 审计日志 | B | 15% | 0.45 |
| | 输入校验 | B+ | 15% | 0.53 |
| | **小计** | | | **3.78 → A-** |

---

## 六、总结

Ops-Monitor v1.9.8 是一个**功能完整、生产可用**的轻量级 Linux 服务器监控系统。其最大的亮点是：

- **Agent 零依赖设计**，极大降低了部署门槛
- **Synology DSM 深度兼容**，覆盖了 NAS 监控的细分场景
- **安全机制完善**，从认证到 CSRF 到加密存储形成了完整链路
- **容错设计到位**，原子写入、超时保护、异常隔离等措施保证了稳定性

主要技术债务集中在**单体文件过大**（app.py 1790行 / agent.py 3014行）和**缺少数据库迁移框架**两个方面。建议在 v2.0 版本中完成模块拆分，引入 Alembic，为后续功能迭代打好基础。
