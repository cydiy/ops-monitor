#!/bin/bash
# ================================================================
# 运维监控系统 - Agent 服务管理脚本
# 用法: bash service.sh {start|stop|restart|status|uninstall}
#
# 支持环境：
#   - 标准 Linux（Debian / CentOS / Rocky）- cron + systemd 自启
#   - 群晖 DSM（NAS）                      - /etc/crontab + rc.d 自启
# ================================================================
# 注意：不使用 set -e，改用显式错误处理，避免 CentOS 下 crontab -l
# 无任务时返回非零码导致脚本意外中止
set -u

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m'

info()    { echo -e "${CYAN}[INFO]${NC}  $1"; }
success() { echo -e "${GREEN}[OK]${NC}    $1"; }
warn()    { echo -e "${YELLOW}[WARN]${NC}  $1"; }
error()   { echo -e "${RED}[ERROR]${NC} $1"; exit 1; }

# ─────────── 路径检测 ───────────
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
AGENT_DIR="${SCRIPT_DIR}"
AGENT_PY="${AGENT_DIR}/agent.py"
AGENT_CONF="${AGENT_DIR}/agent.conf"
CRON_LOG="${AGENT_DIR}/cron.log"

# 自动查找可用 Python
_find_python() {
    for py in python3.13 python3.12 python3.11 python3.10 python3.9 python3.8 python3 python; do
        if command -v "$py" &>/dev/null; then
            ver=$("$py" -c 'import sys; print(sys.version_info.major*10+sys.version_info.minor)' 2>/dev/null) || continue
            if [ -n "$ver" ] && [ "$ver" -ge 38 ]; then
                echo "$py"; return 0
            fi
        fi
    done
    echo "python3"
}
AGENT_PYTHON=$(_find_python)
# 解析为绝对路径（cron 环境的 PATH 可能不含 /usr/local/bin）
AGENT_PYTHON_ABS="$(command -v "${AGENT_PYTHON}" 2>/dev/null || which "${AGENT_PYTHON}" 2>/dev/null || echo "${AGENT_PYTHON}")"

# ─────────── 工具函数：安全获取 crontab 内容 ───────────
# CentOS/RHEL 在无任务时 crontab -l 返回非零码并打印到stderr
# 使用此函数安全获取，无任务时返回空字符串
_safe_crontab_list() {
    crontab -l 2>/dev/null || true
}

# 判断 crontab 中是否已包含 ops-monitor 任务
_cron_has_agent() {
    _safe_crontab_list | grep -q 'ops-monitor\|agent\.py' 2>/dev/null
}

# ─────────── 状态检查 ───────────
cmd_status() {
    echo ""
    echo -e "${CYAN}═══ Agent 状态 ═══${NC}"

    # agent.py 是否存在
    if [ -f "$AGENT_PY" ]; then
        echo -e "  ${GREEN}●${NC} agent.py       - 存在 (${AGENT_PY})"
    else
        echo -e "  ${RED}●${NC} agent.py       - 不存在"
    fi

    # 配置文件
    if [ -f "$AGENT_CONF" ]; then
        echo -e "  ${GREEN}●${NC} agent.conf     - 存在"
    else
        echo -e "  ${YELLOW}○${NC} agent.conf     - 不存在（未配置）"
    fi

    # cron 定时任务
    echo ""
    echo -e "${CYAN}  定时任务：${NC}"
    if command -v crontab &>/dev/null && _cron_has_agent; then
        echo -e "  ${GREEN}●${NC} crontab        - 已配置"
        _safe_crontab_list | grep 'ops-monitor\|agent\.py' | sed 's/^/    /'
    elif [ -f /etc/crontab ] && grep -q 'ops-monitor\|agent\.py' /etc/crontab; then
        echo -e "  ${GREEN}●${NC} /etc/crontab   - 已配置（群晖）"
        grep 'ops-monitor\|agent\.py' /etc/crontab | sed 's/^/    /'
    else
        echo -e "  ${YELLOW}○${NC} 定时任务       - 未配置"
    fi

    # 开机自启
    echo ""
    echo -e "${CYAN}  开机自启：${NC}"
    if systemctl is-enabled ops-monitor-agent &>/dev/null 2>&1; then
        echo -e "  ${GREEN}●${NC} systemd        - 已启用 (ops-monitor-agent.service)"
    elif [ -f /usr/local/etc/rc.d/S99ops-monitor-agent.sh ]; then
        echo -e "  ${GREEN}●${NC} 群晖 rc.d      - 已配置"
    elif [ -f /etc/rc.local ] && grep -q 'ops-monitor\|agent\.py' /etc/rc.local; then
        echo -e "  ${GREEN}●${NC} rc.local       - 已配置"
    else
        echo -e "  ${YELLOW}○${NC} 开机自启       - 未配置"
    fi

    # 上报状态
    echo ""
    echo -e "${CYAN}  上报状态：${NC}"
    if [ -f "$CRON_LOG" ]; then
        LAST_LINE=$(grep -E '上报成功|上报完成|POST.*200|OK' "$CRON_LOG" 2>/dev/null | tail -1)
        if [ -n "$LAST_LINE" ]; then
            LAST_TIME=$(echo "$LAST_LINE" | awk '{print $1, $2}')
            echo -e "  ${GREEN}●${NC} 上次上报: $LAST_TIME"
        else
            LAST_TIME=$(date -r "$CRON_LOG" "+%Y-%m-%d %H:%M:%S" 2>/dev/null || ls -l "$CRON_LOG" 2>/dev/null | awk '{print $6, $7, $8}')
            echo -e "  ${YELLOW}○${NC} 上次活动: $LAST_TIME"
        fi

        if _safe_crontab_list | grep -q 'agent\.py.*full'; then
            echo -e "  ${CYAN}ℹ${NC} 下次 full 上报: 每3小时（整点执行）"
        elif [ -f /etc/crontab ] && grep -q 'agent\.py.*full' /etc/crontab 2>/dev/null; then
            echo -e "  ${CYAN}ℹ${NC} 下次 full 上报: 每3小时（整点执行）"
        fi
        if _safe_crontab_list | grep -q 'agent\.py.*heartbeat'; then
            echo -e "  ${CYAN}ℹ${NC} 心跳上报: 每5分钟"
        elif [ -f /etc/crontab ] && grep -q 'agent\.py.*heartbeat' /etc/crontab 2>/dev/null; then
            echo -e "  ${CYAN}ℹ${NC} 心跳上报: 每5分钟"
        fi
    else
        echo -e "  ${YELLOW}○${NC} 尚未有上报记录（cron.log 不存在）"
    fi

    # 最近日志
    if [ -f "$CRON_LOG" ]; then
        echo ""
        echo -e "${CYAN}  最近日志（${CRON_LOG}）：${NC}"
        tail -10 "$CRON_LOG" | sed 's/^/    /'
    fi
    echo ""
}

# ─────────── 启动（安装定时任务 + 立即上报）───────────
cmd_start() {
    info "启动 Agent 服务（安装定时任务 + 立即上报）..."

    # 确保 cron 任务已安装
    # 注意：CentOS 在无任务时 crontab -l 返回非零，需用 _cron_has_agent 安全检测
    if _cron_has_agent; then
        info "定时任务已配置（crontab），跳过安装"
    elif [ -f /etc/crontab ] && grep -q 'agent\.py' /etc/crontab 2>/dev/null; then
        info "定时任务已配置（/etc/crontab 群晖模式），跳过安装"
    else
        info "定时任务未配置，正在安装..."
        _reinstall_cron
    fi

    # 触发一次立即上报
    if [ ! -f "$AGENT_PY" ]; then
        error "agent.py 不存在: ${AGENT_PY}"
    fi
    if "${AGENT_PYTHON}" "${AGENT_PY}" --mode full; then
        success "上报完成，定时任务已启用"
    else
        warn "上报失败，请检查日志: ${CRON_LOG}"
    fi
}

# ─────────── 停止（移除 cron 定时任务，保留文件）───────────
cmd_stop() {
    info "停止 Agent 定时任务（不删除文件）..."

    # 标准 crontab（CentOS 安全方式）
    if command -v crontab &>/dev/null && _cron_has_agent; then
        (_safe_crontab_list | grep -v 'ops-monitor\|agent\.py\|# OPS-MONITOR-CRON\|运维监控') | crontab - && \
            success "已移除 crontab 定时任务" || warn "crontab 移除失败"
    fi

    # 群晖 /etc/crontab
    if [ -f /etc/crontab ] && grep -q 'ops-monitor\|agent\.py' /etc/crontab; then
        grep -v 'ops-monitor\|agent\.py\|运维监控系统' /etc/crontab > /tmp/_cron.tmp || true
        cat /tmp/_cron.tmp > /etc/crontab
        command -v synoservice &>/dev/null && synoservice --restart crond 2>/dev/null || true
        success "已移除 /etc/crontab 定时任务"
    fi

    success "Agent 定时任务已停止（文件保留，可用 start 重新激活）"
}

# ─────────── 重启 ───────────
cmd_restart() {
    info "重启 Agent 定时任务..."
    cmd_stop
    _reinstall_cron
    cmd_start
    success "Agent 已重启"
}

# ─────────── 检查并启动 cron 服务 ───────────
_ensure_cron_service() {
    # systemd 系统：确保 crond 服务已启用并运行
    if command -v systemctl &>/dev/null; then
        if systemctl list-unit-files crond.service &>/dev/null 2>&1; then
            systemctl enable crond 2>/dev/null || true
            if ! systemctl is-active crond &>/dev/null 2>&1; then
                systemctl start crond 2>/dev/null || true
                info "已启动 crond 服务"
            fi
        elif systemctl list-unit-files cron.service &>/dev/null 2>&1; then
            systemctl enable cron 2>/dev/null || true
            if ! systemctl is-active cron &>/dev/null 2>&1; then
                systemctl start cron 2>/dev/null || true
                info "已启动 cron 服务"
            fi
        fi
    fi
    # SysV init 系统（旧版 CentOS 6）
    if command -v service &>/dev/null && ! command -v systemctl &>/dev/null; then
        if [ -f /etc/init.d/crond ]; then
            if ! service crond status &>/dev/null 2>&1; then
                service crond start 2>/dev/null || true
                chkconfig crond on 2>/dev/null || true
                info "已启动 crond 服务 (SysV)"
            fi
        fi
    fi
}

# ─────────── 重新安装 cron 任务 ───────────
_reinstall_cron() {
    if command -v crontab &>/dev/null; then
        # 确保 cron 服务已启动（CentOS/RHEL 需要显式启动 crond）
        _ensure_cron_service
        # 使用 _safe_crontab_list 安全获取现有任务（CentOS无任务时不报错）
        ( _safe_crontab_list | grep -v 'ops-monitor\|agent\.py\|# OPS-MONITOR-CRON\|运维监控' || true
          echo "# OPS-MONITOR-CRON 运维监控系统 Agent 定时任务（自动生成）"
          echo "SHELL=/bin/bash"
          echo "PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
          echo "0 */3 * * * flock -n /tmp/ops-monitor-full.lock ${AGENT_PYTHON_ABS} ${AGENT_PY} --mode full >> ${CRON_LOG} 2>&1 || true"
          echo "*/5 * * * * flock -n /tmp/ops-monitor-heartbeat.lock ${AGENT_PYTHON_ABS} ${AGENT_PY} --mode heartbeat >> ${CRON_LOG} 2>&1 || true"
          echo "*/15 * * * * flock -n /tmp/ops-monitor-alert.lock ${AGENT_PYTHON_ABS} ${AGENT_PY} --mode alert >> ${CRON_LOG} 2>&1 || true"
          # 每日日志截断：cron.log 超过 20MB 时保留末尾 5MB（防磁盘撑满+兼容无logrotate环境）
          echo "0 4 * * * [ -f ${CRON_LOG} ] && LOG_SIZE=\$(stat -c%s ${CRON_LOG} 2>/dev/null || stat -f%z ${CRON_LOG} 2>/dev/null) && [ \"\${LOG_SIZE:-0}\" -gt 20971520 ] && tail -c 5242880 ${CRON_LOG} > ${CRON_LOG}.tmp && mv ${CRON_LOG}.tmp ${CRON_LOG} && echo \"[cron.log 日志截断] 原始大小 \${LOG_SIZE}B\" >> ${CRON_LOG}"
        ) | crontab -
        success "定时任务已重新安装（crontab）"
    elif [ -f /etc/crontab ]; then
        grep -v 'ops-monitor\|agent\.py\|# OPS-MONITOR-CRON\|运维监控' /etc/crontab > /tmp/_cron.tmp || true
        cat /tmp/_cron.tmp > /etc/crontab
        {
            echo ""
            echo "# OPS-MONITOR-CRON 运维监控系统 Agent 定时任务（自动生成）"
            echo "0 */3 * * * root flock -n /tmp/ops-monitor-full.lock ${AGENT_PYTHON_ABS} ${AGENT_PY} --mode full >> ${CRON_LOG} 2>&1 || true"
            echo "*/5 * * * * root flock -n /tmp/ops-monitor-heartbeat.lock ${AGENT_PYTHON_ABS} ${AGENT_PY} --mode heartbeat >> ${CRON_LOG} 2>&1 || true"
            echo "*/15 * * * * root flock -n /tmp/ops-monitor-alert.lock ${AGENT_PYTHON_ABS} ${AGENT_PY} --mode alert >> ${CRON_LOG} 2>&1 || true"
            # 每日日志截断（DSM 兼容 stat 语法）
            echo "0 4 * * * root [ -f ${CRON_LOG} ] && LOG_SIZE=\$(stat -f%z ${CRON_LOG} 2>/dev/null || echo 0) && [ \"\${LOG_SIZE:-0}\" -gt 20971520 ] && tail -c 5242880 ${CRON_LOG} > ${CRON_LOG}.tmp && mv ${CRON_LOG}.tmp ${CRON_LOG}"
        } >> /etc/crontab
        command -v synoservice &>/dev/null && synoservice --restart crond 2>/dev/null || true
        success "定时任务已重新安装（/etc/crontab）"
    else
        warn "无法安装定时任务，请手动配置"
    fi
}

# ─────────── 卸载（完全移除）───────────
cmd_uninstall() {
    echo ""
    echo -e "${RED}⚠  即将卸载 Agent，此操作将：${NC}"
    echo "   1. 移除所有 cron 定时任务"
    echo "   2. 禁用并删除 systemd/rc.local 开机自启"
    echo "   3. 删除 Agent 目录: ${AGENT_DIR}"
    echo ""
    printf "确认卸载？(输入 yes 继续): "
    read -r CONFIRM
    [ "$CONFIRM" != "yes" ] && { info "已取消"; exit 0; }

    # 移除 cron
    if command -v crontab &>/dev/null; then
        (_safe_crontab_list | grep -v 'ops-monitor\|agent\.py') | crontab - 2>/dev/null || true
    fi
    if [ -f /etc/crontab ]; then
        grep -v 'ops-monitor\|agent\.py\|运维监控系统' /etc/crontab > /tmp/_cron.tmp || true
        cat /tmp/_cron.tmp > /etc/crontab
        command -v synoservice &>/dev/null && synoservice --restart crond 2>/dev/null || true
    fi

    # 移除 systemd 自启
    if systemctl is-enabled ops-monitor-agent &>/dev/null 2>&1; then
        systemctl disable ops-monitor-agent 2>/dev/null || true
        rm -f /etc/systemd/system/ops-monitor-agent.service
        systemctl daemon-reload 2>/dev/null || true
    fi

    # 移除群晖 rc.d
    rm -f /usr/local/etc/rc.d/S99ops-monitor-agent.sh 2>/dev/null || true

    # 移除 rc.local 条目
    if [ -f /etc/rc.local ] && grep -q 'ops-monitor\|agent\.py' /etc/rc.local; then
        grep -v 'ops-monitor\|agent\.py' /etc/rc.local > /tmp/_rc.tmp || true
        cat /tmp/_rc.tmp > /etc/rc.local
    fi

    # 删除目录
    rm -rf "${AGENT_DIR}"
    success "Agent 已完全卸载"
}

# ─────────── 帮助 ───────────
cmd_help() {
    echo ""
    echo -e "${CYAN}用法: bash $(basename "$0") {start|stop|restart|status|uninstall}${NC}"
    echo ""
    echo "  start     触发一次立即上报（full 模式）"
    echo "  stop      停止定时任务（保留文件，可重启恢复）"
    echo "  restart   重新安装定时任务并立即上报"
    echo "  status    查看运行状态、定时任务、开机自启及最近日志"
    echo "  uninstall 完全卸载 Agent（移除定时任务+自启+文件）"
    echo ""
}

# ─────────── 主入口 ───────────
COMMAND="${1:-status}"
case "$COMMAND" in
    start)     cmd_start     ;;
    stop)      cmd_stop      ;;
    restart)   cmd_restart   ;;
    status)    cmd_status    ;;
    uninstall) cmd_uninstall ;;
    *)         cmd_help      ;;
esac
