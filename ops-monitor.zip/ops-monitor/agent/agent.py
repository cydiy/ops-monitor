#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
运维监控系统 - Agent端主程序
负责采集本机系统信息并上报至监控服务端
支持：
  - 系统基础信息（CPU/内存/磁盘/负载/温度/网卡）
  - 进程监控（TOP10/僵尸进程/异常进程）
  - 磁盘SMART健康信息
  - 安全监控（登录检测/文件变更/入侵检测/防火墙）
  - 告警实时上报
  - 资产台账采集
"""

import os
import re
import sys
import json
import gzip
import time
import socket
import signal
import hashlib
import logging
import argparse
import subprocess
import urllib.request
import urllib.error
from datetime import datetime, timezone
from pathlib import Path
import concurrent.futures
from logging.handlers import RotatingFileHandler

__version__ = '1.9.9'

# ─────────────── 全局配置 ───────────────
CONFIG_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'agent.conf')
CACHE_DIR   = os.path.join(os.path.dirname(os.path.abspath(__file__)), '.cache')
LOG_FILE    = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'agent.log')

# 确保缓存目录存在（限制权限为700）
os.makedirs(CACHE_DIR, exist_ok=True, mode=0o700)

# 本地时间转UTC：使用 time.mktime + datetime.fromtimestamp(tz=utc)
# 由系统时区自动处理偏移，比数值 offset 更可靠

def _local_time_to_utc(local_str, default=None):
    """将本地时间字符串转换为UTC ISO格式（带Z后缀）。
    使用 time.mktime 将系统本地时间转时间戳，再由时间戳转UTC。
    这比手动计算 time.timezone 偏移更可靠，不受系统时区配置差异影响。

    支持格式：YYYY-MM-DDTHH:MM:SS, YYYY-MM-DD HH:MM:SS, Mon DD HH:MM:SS, HH:MM:SS
    """
    if not local_str:
        return default
    try:
        s = str(local_str)[:19].strip()
        # 如果已包含时区信息（有+或Z），直接返回
        if '+' in s or s.endswith('Z'):
            return s
        now = datetime.now()
        for fmt in ['%Y-%m-%dT%H:%M:%S', '%Y-%m-%d %H:%M:%S',
                     '%b %d %H:%M:%S', '%b %d %H:%M', '%H:%M:%S', '%H:%M']:
            try:
                dt = datetime.strptime(s, fmt)
                if dt.year == 1900:
                    dt = dt.replace(year=now.year)
                # 使用 time.mktime 将本地时间转为 Unix 时间戳（依赖系统时区）
                # 再由时间戳构建 UTC datetime，比 time.timezone 偏移更可靠
                ts = time.mktime(dt.timetuple())
                utc_dt = datetime.fromtimestamp(ts, tz=timezone.utc)
                return utc_dt.strftime('%Y-%m-%dT%H:%M:%S') + 'Z'
            except (ValueError, OverflowError, OSError):
                continue
    except Exception:
        pass
    return default or (str(local_str)[:19] if local_str else '')

# Agent最大总执行时间（秒），超时后强制退出，防止采集卡死影响节点
MAX_WALL_TIME = 600

# 子进程输出最大捕获字节数，防止异常命令输出撑满内存
MAX_CAPTURE_BYTES = 1 * 1024 * 1024  # 1MB

# 日志最大文件大小（字节），保留5个备份，防日志撑满磁盘
LOG_MAX_BYTES = 5 * 1024 * 1024  # 5MB
LOG_BACKUP_COUNT = 5

# pending缓存最大文件数量，超出时删除最旧的
MAX_PENDING_CACHE = 50

# ─── 全局安全标志：SIGTERM 触发时置 True，缓存写入函数可提前退出 ───
_terminating = False

def _wall_time_handler(signum, frame):
    """SIGALRM 处理：超过 MAX_WALL_TIME 强制退出，防止采集卡死影响节点"""
    logger.error(f'Agent 运行超过 {MAX_WALL_TIME}s 上限，强制退出以保护节点')
    sys.exit(2)

def _sigterm_handler(signum, frame):
    """SIGTERM 处理：设置终止标志，下次写入缓存文件前检查并退出"""
    global _terminating
    _terminating = True
    logger.warning('收到 SIGTERM，将在安全点退出...')

# 注册信号处理
signal.signal(signal.SIGALRM, _wall_time_handler)
signal.signal(signal.SIGTERM, _sigterm_handler)

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(message)s',
    handlers=[
        logging.StreamHandler(),
        RotatingFileHandler(LOG_FILE, encoding='utf-8',
                            maxBytes=LOG_MAX_BYTES, backupCount=LOG_BACKUP_COUNT),
    ]
)
logger = logging.getLogger('ops-agent')

# ─────────────── 系统类型检测 ───────────────
def _detect_system_type():
    """检测当前系统类型，返回 'synology' | 'linux' | 'unknown'
    群辉DSM检测优先级：
      1. /etc/os-release 包含 'Synology' 或 ID='synology'
      2. 存在 /etc/default/synoinfo.conf（所有 DSM 版本均有）
      3. 存在 /usr/syno/bin/synodisk（DSM 专用工具）"""
    # 方式1：标准 os-release 检测
    try:
        if os.path.exists('/etc/os-release'):
            with open('/etc/os-release') as f:
                content = f.read().lower()
            if 'synology' in content:
                return 'synology'
    except Exception:
        pass
    # 方式2：DSM 特征文件检测（兼容 VM 环境下 os-release 无 synology 关键字的情况）
    dsm_markers = ['/etc/default/synoinfo.conf', '/usr/syno/bin/synodisk',
                   '/usr/syno/bin/synohdparm', '/usr/syno/sbin/synologset']
    for marker in dsm_markers:
        if os.path.exists(marker):
            return 'synology'
    # 方式3：通用 Linux 检测
    try:
        if os.path.exists('/etc/os-release'):
            with open('/etc/os-release') as f:
                content = f.read().lower()
            if 'debian' in content or 'ubuntu' in content or 'centos' in content or 'red hat' in content:
                return 'linux'
    except Exception:
        pass
    return 'unknown'

SYSTEM_TYPE = _detect_system_type()
IS_DSM = (SYSTEM_TYPE == 'synology')
if IS_DSM:
    logger.info('检测到群辉 Synology DSM 系统，启用 DSM 兼容模式')


def load_config():
    """加载配置文件"""
    if not os.path.exists(CONFIG_FILE):
        logger.error(f'配置文件不存在: {CONFIG_FILE}，请先运行 deploy.sh 完成配置')
        sys.exit(1)
    cfg = {}
    with open(CONFIG_FILE, 'r', encoding='utf-8') as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith('#'):
                continue
            if '=' in line:
                k, v = line.split('=', 1)
                cfg[k.strip()] = v.strip()
    return cfg


# ══════════════════════════════════════════
# 系统信息采集模块
# ══════════════════════════════════════════

def get_hostname():
    """获取主机名"""
    return socket.gethostname()


def get_ip():
    """获取主机主要IP（优先获取非回环地址）"""
    try:
        # GNU hostname -I 不可用于 busybox/DSM，优先使用 ip 命令
        output = _run(['ip', 'route', 'get', '1.1.1.1'])
        if output:
            for part in output.split():
                if part == 'src':
                    idx = output.split().index(part)
                    if idx + 1 < len(output.split()):
                        return output.split()[idx + 1]
    except Exception:
        pass
    try:
        # fallback: hostname -I（仅 GNU coreutils 支持）
        output = _run(['hostname', '-I'])
        if output:
            return output.strip().split()[0]
    except Exception:
        pass
    return socket.gethostbyname(socket.gethostname())


def get_os_info():
    """获取操作系统信息"""
    try:
        # 优先读取 /etc/os-release
        if os.path.exists('/etc/os-release'):
            with open('/etc/os-release') as f:
                for line in f:
                    if line.startswith('PRETTY_NAME='):
                        return line.split('=', 1)[1].strip().strip('"')
    except Exception:
        pass
    return _run(['uname', '-sr']) or 'Unknown'


def get_uptime():
    """获取系统开机时长（秒）"""
    try:
        with open('/proc/uptime') as f:
            return int(float(f.read().split()[0]))
    except Exception:
        return 0


def get_cpu_info():
    """采集CPU使用率、负载、核心信息

    注意：此函数已被重构为两阶段采样。
    实际调用方（_collect_all）会在所有重操作前后分别调用 _read_cpu_stat_raw()，
    然后将两次样本传给本函数进行计算，避免 ps aux 等采集操作本身干扰 CPU 测量。
    """
    result = {'cpu_usage': 0.0, 'cpu_cores': [], 'load_1': 0.0, 'load_5': 0.0, 'load_15': 0.0, 'cpu_model': ''}

    # 负载
    try:
        with open('/proc/loadavg') as f:
            parts = f.read().split()
            result['load_1']  = float(parts[0])
            result['load_5']  = float(parts[1])
            result['load_15'] = float(parts[2])
    except Exception:
        pass

    # CPU型号
    try:
        with open('/proc/cpuinfo') as f:
            for line in f:
                if 'model name' in line:
                    result['cpu_model'] = line.split(':', 1)[1].strip()
                    break
    except Exception:
        pass

    return result


def _read_cpu_stat_raw():
    """读取 /proc/stat 原始 CPU 计数值（不睡眠、不计算，供外部调用做差值）"""
    stats = []
    try:
        with open('/proc/stat') as f:
            for line in f:
                if line.startswith('cpu'):
                    parts = line.split()
                    name = parts[0]
                    vals = list(map(int, parts[1:9]))
                    idle = vals[3] + (vals[4] if len(vals) > 4 else 0)
                    total = sum(vals)
                    stats.append((name, total, idle))
    except Exception:
        pass
    return stats


def _compute_cpu_from_stats(stat_before, stat_after):
    """从两次 /proc/stat 采样计算 CPU 使用率（各核心 + 总体）"""
    cpu_usage = 0.0
    cpu_cores = []
    if not stat_before or not stat_after:
        return cpu_usage, cpu_cores
    for (n1, t1, i1), (n2, t2, i2) in zip(stat_before, stat_after):
        dt = t2 - t1
        di = i2 - i1
        usage = round((1 - di / dt) * 100, 1) if dt > 10 else 0.0
        if n1 == 'cpu':
            cpu_usage = usage
        else:
            cpu_cores.append(usage)
    return cpu_usage, cpu_cores


def get_memory_info():
    """采集内存使用情况（MB）

    精度说明：
    - 优先使用 MemAvailable（内核 3.14+ 提供），它精确反映应用程序可用内存，
      已自动排除 page cache、buffers 及可回收 slab（SReclaimable）。
    - 旧内核 fallback：MemFree + Buffers + Cached + SReclaimable，
      其中 SReclaimable 是内核 slab 中可被回收的部分，不应计入"已用内存"。
    """
    result = {'mem_total': 0, 'mem_used': 0, 'mem_free': 0, 'mem_usage': 0.0,
              'swap_total': 0, 'swap_used': 0, 'swap_free': 0}
    try:
        mem = {}
        with open('/proc/meminfo') as f:
            for line in f:
                parts = line.split()
                if len(parts) >= 2:
                    mem[parts[0].rstrip(':')] = int(parts[1])
        total = mem.get('MemTotal', 0)
        if 'MemAvailable' in mem:
            avail = mem['MemAvailable']
        else:
            avail = (mem.get('MemFree', 0)
                     + mem.get('Buffers', 0)
                     + mem.get('Cached', 0)
                     + mem.get('SReclaimable', 0))
        used  = total - avail
        if used < 0:
            used = 0
        result['mem_total'] = total // 1024
        result['mem_used']  = used  // 1024
        result['mem_free']  = avail // 1024
        result['mem_usage'] = round(used / total * 100, 1) if total > 0 else 0.0

        # Swap 信息
        swap_total = mem.get('SwapTotal', 0)
        if swap_total > 0:
            swap_free = mem.get('SwapFree', 0)
            swap_used = swap_total - swap_free
            result['swap_total'] = swap_total // 1024
            result['swap_used']  = swap_used  // 1024
            result['swap_free']  = swap_free  // 1024
    except Exception as e:
        logger.warning(f'内存采集失败: {e}')
    return result


def get_disk_info():
    """采集各磁盘分区使用情况（兼容 DSM busybox df）"""
    disks = []
    try:
        if IS_DSM:
            # DSM busybox df 不支持 --output，使用传统解析
            # 先从 /proc/mounts 获取挂载点→文件系统类型映射
            mount_fstype = {}
            try:
                with open('/proc/mounts') as f:
                    for line in f:
                        parts = line.split()
                        if len(parts) >= 3:
                            mount_fstype[parts[1]] = parts[2]
            except Exception:
                pass

            output = _run(['df', '-h'])
            for line in (output or '').splitlines()[1:]:
                parts = line.split()
                if len(parts) >= 6:
                    # busybox df 格式: Filesystem Size Used Avail Use% Mounted
                    device  = parts[0]
                    mount   = parts[5]
                    fstype  = mount_fstype.get(mount, device)
                    total   = parts[1]
                    used    = parts[2]
                    avail   = parts[3]
                    pct_str = parts[4].rstrip('%')
                    # 跳过伪文件系统和tmpfs
                    if fstype in ('tmpfs', 'devtmpfs', 'sysfs', 'proc', 'cgroup', 'overlay', 'squashfs'):
                        continue
                    if mount in ('/dev/shm', '/proc', '/sys', '/dev'):
                        continue
                    disks.append({
                        'mount': mount, 'fstype': fstype,
                        'total': total, 'used': used, 'avail': avail,
                        'use_percent': float(pct_str) if pct_str.replace('.','',1).isdigit() else 0.0
                    })
        else:
            output = _run(['df', '-h', '--output=target,fstype,size,used,avail,pcent'])
            for line in (output or '').splitlines()[1:]:
                parts = line.split()
                if len(parts) >= 6:
                    mount   = parts[0]
                    fstype  = parts[1]
                    total   = parts[2]
                    used    = parts[3]
                    avail   = parts[4]
                    pct_str = parts[5].rstrip('%')
                    if fstype in ('tmpfs', 'devtmpfs', 'sysfs', 'proc', 'cgroup', 'overlay', 'squashfs'):
                        continue
                    disks.append({
                        'mount': mount, 'fstype': fstype,
                        'total': total, 'used': used, 'avail': avail,
                        'use_percent': float(pct_str) if pct_str.isdigit() else 0.0
                    })
    except Exception as e:
        logger.warning(f'磁盘使用率采集失败: {e}')
    return disks


def get_cpu_temperature():
    """采集CPU温度（多种方式兼容：lm-sensors, /sys/class/thermal, /sys/class/hwmon）"""
    # 方式0：lm-sensors（所有非DSM系统优先）
    if not IS_DSM:
        try:
            output = _run(['sensors'])
            if output:
                # 逐块解析 sensors 输出，按适配器/芯片分组
                adapter_name = ''
                temps = []
                for line in output.splitlines():
                    stripped = line.strip()
                    # 检测适配器行，如 "coretemp-isa-0000", "acpitz-virtual-0", "iio_hwmon-virtual-0", "k10temp-pci-00c3"
                    if re.match(r'^[\w\-]+:', line):
                        adapter_name = line.split(':')[0].strip().lower()
                    # 匹配温度行（末尾有 (high=.../crit=...) 等阈值信息）
                    m = re.match(r'^([\w\s]+?):\s*\+?(\d+\.?\d*)\s*°?[CF](?:\s|$)', stripped)
                    if m:
                        label = m.group(1).strip().lower()
                        temp_val = float(m.group(2))
                        # 优先匹配明确的CPU温度标签
                        if any(kw in label for kw in ('core 0', 'core0', 'package id 0', 'package',
                                                        'cpu', 'tctl', 'tccd1', 'tccd2',
                                                        'cputin', 'peci agent')):
                            return temp_val
                        # 次选：匹配已知适配器下的 temp1/temp2/tempN
                        if re.match(r'^temp\d+$', label) and adapter_name:
                            if any(kw in adapter_name for kw in
                                   ('acpitz', 'coretemp', 'k10temp', 'iio_hwmon',
                                    'cpu_thermal', 'peci', 'nouveau',
                                    'cpu-thermal', 'soc_thermal', 'scpi')):
                                temps.append(temp_val)
                            # dell iDRAC 等环境用 dell-smm-virtual-* 适配器
                            elif 'dell' in adapter_name or 'smm' in adapter_name:
                                temps.append(temp_val)
                if temps:
                    return max(temps)
        except Exception:
            pass

    # 方式1：/sys/class/thermal（所有系统通用）
    try:
        thermal_dir = Path('/sys/class/thermal')
        temps = []
        for zone in sorted(thermal_dir.glob('thermal_zone*')):
            try:
                type_file = zone / 'type'
                temp_file = zone / 'temp'
                zone_type = type_file.read_text().strip().lower()
                # 匹配 x86_pkg_temp, cpu_thermal, cpu-thermal, soc_thermal 等
                if any(kw in zone_type for kw in ('x86', 'cpu', 'pkg', 'soc', 'a76', 'a55', 'a53', 'a72', 'a35')):
                    temp = int(temp_file.read_text().strip()) / 1000
                    if 0 < temp < 150:  # 合理温度范围
                        temps.append(temp)
            except Exception:
                pass
        if temps:
            return max(temps)
    except Exception:
        pass

    # 方式2：/sys/class/hwmon（DSM、虚拟化、嵌入式系统等无sensors环境）
    try:
        hwmon_dir = Path('/sys/class/hwmon')
        temps = []
        for hwmon in sorted(hwmon_dir.glob('hwmon*')):
            try:
                name_file = hwmon / 'name'
                if not name_file.exists():
                    # 某些内核版本 name 在 device 目录
                    name_file = hwmon / 'device' / 'name'
                if name_file.exists():
                    sensor_name = name_file.read_text().strip().lower()
                else:
                    continue
                # 跳过明确非CPU的温度传感器
                if any(skip in sensor_name for skip in ('nvme', 'drivetemp', 'sata', 'ahci',
                                                          'pwmfan', 'battery', 'acpi', 'border')):
                    continue
                # 读取该 hwmon 下的所有 tempN_input
                for temp_input in sorted(hwmon.glob('temp*_input')):
                    try:
                        raw = int(temp_input.read_text().strip())
                        temp = raw / 1000.0
                        if 0 < temp < 150:
                            # 优先级：coretemp > k10temp > peci > 其他
                            if any(kw in sensor_name for kw in ('coretemp', 'k10temp', 'peci')):
                                return temp  # 高优先级直接返回
                            temps.append(temp)
                    except Exception:
                        pass
            except Exception:
                pass
        if temps:
            return max(temps)
    except Exception:
        pass
    return None


def _get_single_disk_temp(dev):
    """获取单块磁盘温度（供并发调用）"""
    dev = dev.strip()
    if not dev:
        return None, None
    dev_path = f'/dev/{dev}'

    # NVMe设备：优先使用 nvme smart-log（DSM上smartctl可能未安装）
    if dev.startswith('nvme'):
        out = _run(['nvme', 'smart-log', dev_path], timeout=15)
        if out:
            m = re.search(r'^temperature\s*:\s*(\d+)', out, re.MULTILINE)
            if m:
                return dev, float(m.group(1))

    smart_out = _run_safe(['smartctl', '-A', dev_path], timeout=15)
    if not smart_out:
        return None, None
    # SATA HDD/SSD：查找温度属性（属性190或194）
    m = re.search(r'(Temperature_Celsius|Airflow_Temperature_Cel)\s+\S+\s+\d+\s+\d+\s+\d+\s+\S+\s+\S+\s+\S+\s+(\d+)', smart_out)
    if m:
        return dev, float(m.group(2))
    # NVMe：Composite Temperature
    m = re.search(r'Temperature[:\s]+(\d+)(?:\s*(?:C|Celsius|°C))?', smart_out)
    if m:
        return dev, float(m.group(1))
    return None, None


def get_disk_temperatures():
    """采集各硬盘温度（并行执行，单盘超时10秒，DSM兼容 /dev/sata* 路径）"""
    temps = {}
    try:
        devices = _get_disk_device_list()
        if not devices:
            return temps

        with concurrent.futures.ThreadPoolExecutor(max_workers=min(4, len(devices))) as executor:
            future_to_dev = {executor.submit(_get_single_disk_temp, d): d for d in devices}
            for future in concurrent.futures.as_completed(future_to_dev):
                try:
                    dev, temp = future.result(timeout=10)
                    if dev and temp is not None:
                        temps[dev] = temp
                except concurrent.futures.TimeoutError:
                    logger.warning(f'硬盘温度采集超时: {future_to_dev[future]}')
                except Exception:
                    pass
    except Exception as e:
        logger.warning(f'硬盘温度采集失败: {e}')
    return temps


def _get_disk_device_list():
    """获取磁盘设备列表（DSM: /dev/sata* + /dev/nvme*; Linux: /dev/sd*,nvme*）"""
    if IS_DSM:
        # DSM: 使用 synodisk 获取磁盘列表，或直接枚举 /dev/sata*
        devices = []
        output = _run(['synodisk', '--list'])
        if output:
            for line in output.splitlines():
                m = re.search(r'/dev/(sata\w+)', line)
                if m:
                    devices.append(m.group(1))
        # fallback: 枚举 /dev/sata*（补充 synodisk 未发现的设备）
        for i in range(1, 16):
            dev = f'sata{i}'
            if os.path.exists(f'/dev/{dev}') and dev not in devices:
                devices.append(dev)
        # 追加NVMe设备（DSM 上 /dev/nvme0 控制器节点可能不存在，需同时检查命名空间 /dev/nvme0n1）
        nvme_devices = []
        nvme_list_out = _run(['nvme', 'list'])
        if nvme_list_out:
            seen = set()
            for line in nvme_list_out.splitlines():
                m = re.match(r'/dev/(nvme\d+)', line)
                if m:
                    base = m.group(1)  # nvme0, nvme1（相对设备名，不包含 /dev/ 前缀）
                    if base not in seen:
                        nvme_devices.append(base)
                        seen.add(base)
        else:
            # fallback: 枚举 /dev/nvme*（控制器 + 命名空间均检查）
            for i in range(10):
                for suffix in ['', 'n1']:
                    dev = f'nvme{i}{suffix}'
                    if os.path.exists(f'/dev/{dev}') and f'nvme{i}' not in nvme_devices:
                        nvme_devices.append(f'nvme{i}')
        return devices + nvme_devices
    else:
        output = _run(['lsblk', '-d', '-o', 'NAME,TYPE'])
        if output:
            return [d.strip().split()[0] for d in output.strip().splitlines()
                    if len(d.strip().split()) >= 2 and d.strip().split()[1] == 'disk']
        return []

def get_listening_ports():
    """采集系统监听端口列表（仅TCP，含进程信息）

    兼容性：
    - 优先 ss -tunlp（iproute2，大多数现代 Linux）
    - 降级 netstat -tunlp（net-tools，CentOS/旧系统）
    - 再降级 netstat -tunl（无进程信息）
    - ss/netstat 均不可用时，直接解析 /proc/net/tcp(/tcp6)

    已知问题修复：
    - ss 标题行含 "Netid" 关键字，需过滤
    - ss local_addr 列在不同版本/权限下可能偏移，用正则匹配而非固定列号
    - /proc/net/tcp 解析作为最终兜底，确保标准 Linux 都能获取端口数据
    - 仅采集 TCP 端口，UDP 端口不再采集
    """
    ports = []

    def parse_ss_output(output):
        """解析 ss -tunlp 输出，自动适配列偏移"""
        result = []
        if not output:
            return result
        for line in output.strip().splitlines():
            # 跳过标题行
            if re.match(r'\s*(Netid|State|Proto|Recv)', line, re.IGNORECASE):
                continue
            parts = line.split()
            if len(parts) < 4:
                continue

            proto = parts[0].lower()   # tcp/udp/tcp6/udp6/udplite...
            # 跳过 UDP 端口
            if proto.startswith('udp'):
                continue
            state = parts[1] if len(parts) > 1 else ''

            if state != 'LISTEN':
                continue

            # local_addr 从第4列开始，但有时会插入额外列（如 Recv-Q Send-Q），
            # 因此遍历所有列找第一个匹配 "地址:端口" 格式的列
            local_addr = ''
            addr_idx = -1
            for i, p in enumerate(parts[2:], start=2):
                # 匹配 *:port, 0.0.0.0:port, [::]:port, addr:port
                if re.search(r'(^\*:\d+$|:\d+$)', p) and not p.startswith('users:'):
                    local_addr = p
                    addr_idx = i
                    break
            if not local_addr:
                continue

            # 解析端口号
            m = re.search(r':(\d+)$', local_addr)
            if not m:
                continue
            port = int(m.group(1))
            listen_addr = local_addr[:m.start()].strip('[]') or '*'

            # 解析进程信息（users:(("nginx",pid=1234,fd=6))）
            pid_info = ''
            process_name = ''
            for p in parts[addr_idx+1:]:
                if p.startswith('users:'):
                    pm = re.search(r'pid=(\d+)', p)
                    nm = re.search(r'\("([^"]+)"', p)
                    if pm:
                        pid_info = pm.group(1)
                    if nm:
                        process_name = nm.group(1)
                    break

            if port > 0:
                result.append({
                    'protocol': proto,
                    'port': port,
                    'address': listen_addr,
                    'pid': pid_info,
                    'process': process_name,
                })
        return result

    def parse_netstat_output(output, has_process=True):
        """解析 netstat -tunlp 或 netstat -tunl 输出"""
        result = []
        if not output:
            return result
        for line in output.strip().splitlines():
            if re.match(r'\s*(Proto|Active|Recv)', line, re.IGNORECASE):
                continue
            parts = line.split()
            if len(parts) < 4:
                continue
            proto = parts[0].lower()
            # 跳过 UDP 端口
            if proto.startswith('udp'):
                continue
            local_addr = parts[3] if len(parts) > 3 else ''
            state = parts[5] if len(parts) > 5 else ''

            if state != 'LISTEN':
                continue

            m = re.search(r':(\d+)$', local_addr)
            if not m:
                continue
            port = int(m.group(1))
            listen_addr = local_addr[:m.start()] or '*'

            pid_info = ''
            process_name = ''
            if has_process and len(parts) > 6:
                pinfo = ' '.join(parts[6:])
                pm = re.search(r'(\d+)/', pinfo)
                nm = re.search(r'/([^,\s]+)', pinfo)
                if pm:
                    pid_info = pm.group(1)
                if nm:
                    process_name = nm.group(1).split('/')[-1]

            if port > 0:
                result.append({
                    'protocol': proto,
                    'port': port,
                    'address': listen_addr,
                    'pid': pid_info,
                    'process': process_name,
                })
        return result

    def parse_proc_net():
        """从 /proc/net/tcp(/tcp6/udp/udp6) 直接解析监听端口（无需 ss/netstat）"""
        result = []
        files = [
            ('/proc/net/tcp',  'tcp'),
            ('/proc/net/tcp6', 'tcp6'),
        ]
        for fpath, proto in files:
            try:
                if not os.path.exists(fpath):
                    continue
                with open(fpath) as f:
                    for line in f:
                        parts = line.split()
                        if len(parts) < 4 or parts[0] == 'sl':
                            continue
                        state_hex = parts[3]
                        # TCP：0x0A = LISTEN
                        if state_hex != '0A':
                            continue
                        local_hex = parts[1]   # e.g. "00000000:0050"
                        addr_hex, port_hex = local_hex.rsplit(':', 1)
                        port = int(port_hex, 16)
                        if port == 0:
                            continue
                        # 简单解析IPv4地址
                        try:
                            import socket
                            # addr_hex 是小端序
                            addr_bytes = bytes.fromhex(addr_hex)[::-1]
                            if len(addr_bytes) == 4:
                                listen_addr = socket.inet_ntoa(addr_bytes)
                            else:
                                listen_addr = '*'
                        except Exception:
                            listen_addr = '*'
                        result.append({
                            'protocol': proto,
                            'port': port,
                            'address': listen_addr,
                            'pid': '',
                            'process': '',
                        })
            except Exception:
                pass
        return result

    try:
        # 优先 ss（最准确，现代 Linux 标配）
        output = _run(['ss', '-tunlp'])
        if output and len(output.strip().splitlines()) > 1:
            ports = parse_ss_output(output)

        # 降级 netstat -p（CentOS/旧系统）
        if not ports:
            output = _run(['netstat', '-tunlp'])
            if output:
                ports = parse_netstat_output(output, has_process=True)

        # 再降级 netstat（无进程信息）
        if not ports:
            output = _run(['netstat', '-tunl'])
            if output:
                ports = parse_netstat_output(output, has_process=False)

        # 最终兜底：直接解析 /proc/net/tcp*（无任何外部命令依赖）
        if not ports:
            ports = parse_proc_net()

        # 去重（同协议+端口只保留第一条），按端口升序
        seen = set()
        unique = []
        for p in sorted(ports, key=lambda x: (x['protocol'], x['port'])):
            key = (p['protocol'], p['port'])
            if key not in seen:
                seen.add(key)
                unique.append(p)
        ports = unique
    except Exception as e:
        logger.warning(f'端口采集失败: {e}')
    return ports

def get_network_info():
    """采集各网卡实时流量速率（两次采样计算差值，过滤无流量虚拟接口）"""
    def read_net_stats():
        stats = {}
        try:
            with open('/proc/net/dev') as f:
                for line in f:
                    if ':' not in line:
                        continue
                    iface, data = line.split(':')
                    iface = iface.strip()
                    if iface in ('lo',):
                        continue
                    parts = data.split()
                    if len(parts) >= 10:
                        stats[iface] = {'rx': int(parts[0]), 'tx': int(parts[8])}
        except Exception:
            pass
        return stats

    s1 = read_net_stats()
    time.sleep(1)
    s2 = read_net_stats()

    # 已知的纯虚拟/隧道接口前缀（通常无实际流量）
    _virtual_prefixes = ('bond', 'ipddp', 'teql', 'tunl', 'gre', 'gretap', 'erspan',
                         'ip_vti', 'ip6_vti', 'sit', 'ip6tnl', 'ip6gre', 'dummy',
                         'veth', 'macvlan', 'macvtap', 'vlan', 'br-',
                         'docker', 'cali', 'flannel', 'cni', 'kube', 'lxc',
                         'tap', 'virbr', 'ovs-system')

    result = {}
    for iface in s1:
        if iface not in s2:
            continue
        rx_speed = max(0, s2[iface]['rx'] - s1[iface]['rx'])
        tx_speed = max(0, s2[iface]['tx'] - s1[iface]['tx'])
        rx_total = s2[iface]['rx']
        tx_total = s2[iface]['tx']

        # 过滤：纯虚拟接口且历史总流量也为 0 的才排除（保留有历史数据的虚拟接口）
        if any(iface.startswith(p) for p in _virtual_prefixes) and rx_total == 0 and tx_total == 0:
            continue

        result[iface] = {
            'rx_speed': rx_speed,  # bytes/s
            'tx_speed': tx_speed,  # bytes/s
            'rx_total': rx_total,
            'tx_total': tx_total,
        }
    return result


def get_system_logs(lines=50):
    """采集系统关键日志（兼容 DSM：无 journalctl，使用 synolog）"""
    logs = []

    def parse_log_line(text, source):
        """解析日志行，识别级别（优先匹配结构化级别前缀，再降级到关键字匹配）"""
        level = 'INFO'
        # 优先从消息中提取结构化日志级别（如 [INFO] [WARN] [ERROR]）
        lm = re.search(r'\[(INFO|WARN(?:ING)?|ERROR|CRIT(?:ICAL)?|ALERT|EMERG)\]', text, re.IGNORECASE)
        if lm:
            tag = lm.group(1).upper()
            if tag in ('ERROR', 'CRITICAL', 'CRIT', 'ALERT', 'EMERG'):
                level = 'ERROR'
            elif tag in ('WARN', 'WARNING', 'NOTICE'):
                level = 'WARN'
            else:
                level = 'INFO'
        else:
            # 降级：关键字匹配（避免匹配服务名中的关键字）
            lower = text.lower()
            if any(w in lower for w in ['error', 'err', 'failed', 'failure', 'crit', 'emerg']):
                level = 'ERROR'
            elif any(w in lower for w in ['warning', 'warn', 'notice']):
                level = 'WARN'
        # 尝试提取时间戳（使用UTC时间戳与系统时间戳结合）
        log_time = datetime.now(timezone.utc).isoformat()
        # syslog格式：Jan 01 12:00:00
        m = re.search(r'(\w{3}\s+\d+\s+\d+:\d+:\d+)', text)
        if m:
            try:
                utc_year = datetime.now(timezone.utc).year
                t = datetime.strptime(f'{utc_year} {m.group(1)}', '%Y %b %d %H:%M:%S')
                # syslog时间是本地时间，转为UTC
                log_time = _local_time_to_utc(t.strftime('%Y-%m-%dT%H:%M:%S'), log_time)
            except Exception:
                pass
        return {'level': level, 'time': log_time, 'source': source, 'message': text[:500]}

    if IS_DSM:
        # DSM: 优先从 /var/log/messages 和 synolog 获取日志
        for logfile in ['/var/log/messages', '/var/log/synolog/synolog.log',
                         '/var/log/synolog/web.log', '/var/log/syslog']:
            if os.path.exists(logfile):
                output = _run(['tail', '-n', str(lines), logfile])
                if output:
                    for line in output.strip().splitlines()[:lines]:
                        line = line[:500]  # 截断到500字符
                        if line.strip():
                            logs.append(parse_log_line(line, logfile))
                    break
        return logs

    # 标准 Linux: 优先 journalctl
    output = _run(['journalctl', '-n', str(lines), '--no-pager', '-o', 'short-iso'])
    if output:
        for line in output.strip().splitlines()[-lines:]:
            line = line[:500]  # 截断到500字符
            if line.strip():
                logs.append(parse_log_line(line, 'journalctl'))
        return logs

    # 降级：/var/log/messages
    for logfile in ['/var/log/messages', '/var/log/syslog']:
        if os.path.exists(logfile):
            output = _run(['tail', '-n', str(lines), logfile])
            if output:
                for line in output.strip().splitlines():
                    line = line[:500]  # 截断到500字符
                    if line.strip():
                        logs.append(parse_log_line(line, logfile))
            break

    # ── 日志去重：同一 source+message 组合最多保留 3 条，其余合并标记 ──
    if len(logs) > 5:
        groups = {}
        for entry in logs:
            key = (entry['source'], entry['message'][:200])  # 用前200字符做去重指纹
            if key not in groups:
                groups[key] = []
            groups[key].append(entry)
        deduped = []
        for key, entries in groups.items():
            keep = min(len(entries), 3)
            deduped.extend(entries[:keep])
            extra = len(entries) - keep
            if extra > 0:
                deduped.append({
                    'level': entries[0]['level'],
                    'time': entries[-1]['time'],
                    'source': entries[0]['source'],
                    'message': f'[重复 {extra} 条] {entries[0]["message"][:400]}',
                })
        logs = sorted(deduped, key=lambda x: x['time'], reverse=True)

    return logs


# ══════════════════════════════════════════
# 进程监控模块
# ══════════════════════════════════════════

def get_process_info():
    """采集进程信息：僵尸进程、异常进程、CPU Top5、内存 Top5、进程总数"""
    result = {'zombie': [], 'abnormal': [], 'cpu_top5': [], 'mem_top5': [], 'proc_count': 0}

    try:
        # 纯 Python 统计进程总数（遍历 /proc，无 shell 注入风险）
        total_count = 0
        try:
            total_count = len([d for d in os.listdir('/proc') if d.isdigit()])
        except Exception:
            pass

        # 使用无管道的 ps 命令获取进程列表（shell=False），head -250 由 Python 截断
        output = _run(['ps', 'aux'], timeout=15)
        if output:
            lines = output.strip().splitlines()
            if len(lines) > 251:
                lines = lines[:251]
            output = '\n'.join(lines)

        all_procs = []
        for line in output.strip().splitlines()[1:]:
            parts = line.split(None, 10)
            if len(parts) >= 11:
                cmd = parts[10]
                # 过滤掉 ps aux 自身（避免采集命令被列为 top 进程）
                if 'ps aux' in cmd:
                    continue
                cpu_val = float(parts[2]) if _is_float(parts[2]) else 0
                mem_val = float(parts[3]) if _is_float(parts[3]) else 0
                all_procs.append({
                    'pid': parts[1], 'name': parts[10][:100],
                    'cpu_pct': cpu_val, 'mem_pct': mem_val,
                    'status': parts[7],
                    '_raw_cmd': parts[10][:150],  # 用于异常检测
                })

        result['proc_count'] = total_count or len(all_procs)

        # CPU Top5（始终显示前5个进程，即使CPU为0也展示，方便了解系统运行了什么）
        cpu_sorted = sorted(all_procs, key=lambda p: p['cpu_pct'], reverse=True)
        for p in cpu_sorted[:5]:
            result['cpu_top5'].append({
                'pid': p['pid'], 'name': p['name'],
                'cpu_pct': p['cpu_pct'], 'mem_pct': p['mem_pct'],
            })

        # 内存 Top5
        mem_sorted = sorted(all_procs, key=lambda p: p['mem_pct'], reverse=True)
        for p in mem_sorted[:5]:
            if p['mem_pct'] > 0:
                result['mem_top5'].append({
                    'pid': p['pid'], 'name': p['name'],
                    'cpu_pct': p['cpu_pct'], 'mem_pct': p['mem_pct'],
                })

        # 僵尸进程
        for p in all_procs:
            if p['status'] == 'Z':
                result['zombie'].append({
                    'pid': p['pid'], 'name': p['name'],
                    'cpu_pct': 0, 'mem_pct': 0,
                })

        # 异常进程检测
        suspicious_patterns = [
            '(bash -i', 'nc -e', 'ncat', '/dev/tcp', 'python -c', 'perl -e',
            'base64 -d', 'curl|sh', 'wget|sh', './.', '/.tmp', '/.cache',
        ]
        for p in all_procs:
            cmd = p['_raw_cmd']
            for pattern in suspicious_patterns:
                if pattern.lower() in cmd.lower():
                    result['abnormal'].append({
                        'pid': p['pid'], 'name': cmd,
                        'reason': f'可疑特征: {pattern}',
                        'cpu_pct': 0, 'mem_pct': 0,
                    })
                    break

    except Exception as e:
        logger.warning(f'进程信息采集失败: {e}')

    return result


# ══════════════════════════════════════════
# SMART信息采集模块
# ══════════════════════════════════════════

def get_smart_info():
    """采集所有磁盘的SMART健康信息（并行采集，单盘超时10秒，DSM兼容 /dev/sata*）"""
    smart_list = []
    try:
        if IS_DSM:
            # DSM: 优先使用 synodisk 获取SMART信息（无需smartmontools，仅SATA）
            output = _run(['synodisk', '--get_smart'], timeout=15)
            if output:
                smart_list.extend(_parse_synodisk_smart(output))
            if not smart_list:
                # synodisk 无输出时，尝试 synohdparm --smart
                output = _run(['synohdparm', '--smart'], timeout=15)
                if output:
                    smart_list.extend(_parse_synodisk_smart(output))

            # ── 补充/fallback SATA 磁盘基本信息（型号/序列号/容量），synodisk 不提供这些字段 ──
            # DSM 的 smartctl 6.5 JSON 输出可能不完整，用文本解析兜底
            sata_seen = set()
            for smart_item in smart_list:
                disk_name = smart_item.get('disk', '')
                if disk_name and disk_name.startswith('sata'):
                    sata_seen.add(disk_name)
                    dev_path = f'/dev/{disk_name}'
                    sc_data = _parse_smartctl(dev_path, 'sata')
                    if sc_data:
                        if sc_data.get('model'):
                            smart_item['model'] = sc_data['model']
                        if sc_data.get('serial'):
                            smart_item['serial'] = sc_data['serial']
                        if sc_data.get('size'):
                            smart_item['size'] = sc_data['size']
                        if sc_data.get('rotation_rate') is not None:
                            smart_item['rotation_rate'] = sc_data['rotation_rate']
                        # smartctl 属性温度比 synodisk 信息段温度更精确
                        if sc_data.get('temperature') and sc_data['temperature'] > 0:
                            smart_item['temperature'] = sc_data['temperature']
                        if sc_data.get('power_on_hours') is not None:
                            smart_item['power_on_hours'] = sc_data['power_on_hours']
                        if sc_data.get('reallocated_sectors', 0) > 0:
                            smart_item['reallocated_sectors'] = sc_data['reallocated_sectors']

            # 如果 synodisk 遗漏了某些 SATA 盘（或完全无输出），通过枚举 /dev/sata* 补全
            for i in range(1, 16):
                dev_name = f'sata{i}'
                if dev_name in sata_seen:
                    continue
                dev_path = f'/dev/{dev_name}'
                if not os.path.exists(dev_path):
                    continue
                sc_data = _parse_smartctl(dev_path, 'sata')
                if sc_data:
                    sc_data['disk'] = dev_name
                    sc_data['type'] = 'sata'
                    smart_list.append(sc_data)
                    sata_seen.add(dev_name)

            # DSM also has NVMe devices - collect them separately
            nvme_devices = []
            nvme_list_out = _run(['nvme', 'list'], timeout=15)
            if nvme_list_out:
                seen = set()
                for line in nvme_list_out.splitlines():
                    m = re.match(r'/dev/(nvme\d+)', line)
                    if m:
                        base = m.group(1)  # nvme0, nvme1（相对设备名）
                        if base not in seen:
                            nvme_devices.append(base)
                            seen.add(base)
            else:
                # 仅当存在命名空间 /dev/nvme0n1 时才认为有 NVMe 盘
                # /dev/nvme0 控制器节点在 DSM 上可能始终存在（无盘也可见），不以此为判断依据
                for i in range(10):
                    ns_path = f'nvme{i}n1'
                    if os.path.exists(f'/dev/{ns_path}') and f'nvme{i}' not in nvme_devices:
                        nvme_devices.append(f'nvme{i}')

            if nvme_devices:
                # 获取NVMe设备型号/序列号信息（从 nvme list 输出）
                nvme_info = {}
                if nvme_list_out:
                    cur_dev = None
                    for line in nvme_list_out.splitlines():
                        m_dev = re.match(r'/dev/(nvme\d+)n\d+\s+(\S+)\s+(.+)', line)
                        if m_dev:
                            cur_dev = m_dev.group(1)  # nvme0, nvme1
                            nvme_info[cur_dev] = {'sn': m_dev.group(2), 'model': m_dev.group(3).strip()}
                        elif cur_dev and 'Namespace Usage' in line:
                            m_size = re.search(r'([\d.]+\s+[TGMK]B)\s*/\s*([\d.]+\s+[TGMK]B)', line)
                            if m_size:
                                nvme_info[cur_dev]['size'] = m_size.group(2).strip()

                with concurrent.futures.ThreadPoolExecutor(max_workers=min(4, len(nvme_devices))) as executor:
                    future_to_dev = {}
                    for dev in nvme_devices:
                        dev_path = f'/dev/{dev}'
                        future = executor.submit(_parse_nvme_smart_log, dev_path, dev, nvme_info.get(dev))
                        future_to_dev[future] = dev
                    for future in concurrent.futures.as_completed(future_to_dev):
                        dev = future_to_dev[future]
                        try:
                            smart_data = future.result(timeout=10)
                            if smart_data:
                                smart_list.append(smart_data)
                        except concurrent.futures.TimeoutError:
                            logger.warning(f'NVMe SMART采集超时: {dev}')
                        except Exception as e:
                            logger.warning(f'NVMe SMART采集失败 {dev}: {e}')

            return smart_list
        else:
            # 标准 Linux: lsblk 获取设备列表
            output = _run(['lsblk', '-d', '-o', 'NAME,TYPE,ROTA'])
            if not output:
                return smart_list

            disks = []
            for line in output.strip().splitlines():
                parts = line.split()
                if len(parts) < 2 or parts[1] != 'disk':
                    continue
                dev = parts[0]
                is_rotational = parts[2] == '1' if len(parts) >= 3 else True
                dev_path = f'/dev/{dev}'
                dev_type = 'nvme' if dev.startswith('nvme') else ('ssd' if not is_rotational else 'sata')
                disks.append((dev, dev_path, dev_type))

            # 并行采集（最多4线程，单盘超时10秒）
            with concurrent.futures.ThreadPoolExecutor(max_workers=min(4, len(disks))) as executor:
                future_to_disk = {}
                for dev, dev_path, dev_type in disks:
                    future = executor.submit(_parse_smartctl, dev_path, dev_type)
                    future_to_disk[future] = (dev, dev_type)

                for future in concurrent.futures.as_completed(future_to_disk):
                    dev, dev_type = future_to_disk[future]
                    try:
                        smart_data = future.result(timeout=10)
                        if smart_data:
                            smart_data['disk'] = dev
                            smart_data['type'] = dev_type
                            smart_list.append(smart_data)
                    except concurrent.futures.TimeoutError:
                        logger.warning(f'SMART采集超时: {dev}')
                    except Exception as e:
                        logger.warning(f'SMART采集失败 {dev}: {e}')

    except Exception as e:
        logger.warning(f'SMART信息采集失败: {e}')
    return smart_list


def _parse_nvme_smart_log(dev_path, dev, info=None):
    """使用 nvme smart-log 命令采集NVMe SMART信息（DSM兼容）
    dev_path: /dev/nvme0（控制器） 或 /dev/nvme0n1（命名空间）
    dev: nvme0
    info: 从 nvme list 提取的型号/序列号/容量信息

    兼容策略：
    1. nvme smart-log /dev/nvme0（控制器级别，最快）
    2. nvme smart-log /dev/nvme0n1（命名空间级别）
    3. smartctl -a -d nvme /dev/nvme0n1（DSM smartctl 6.5 可能需 -d nvme）
    4. smartctl -a /dev/nvme0n1（通用兜底）
    5. 即使所有工具失败也创建基本条目（确保 NVMe 盘不出现在 UI 中）
    """
    output = None
    # 尝试多种设备路径
    dev_paths_to_try = [dev_path]
    if dev_path.endswith(('0', '1', '2', '3', '4', '5', '6', '7', '8', '9')) and 'n' not in dev_path.split('/')[-1]:
        dev_paths_to_try.append(f'{dev_path}n1')  # 尝试命名空间路径

    for dp in dev_paths_to_try:
        if os.path.exists(dp):
            output = _run(['nvme', 'smart-log', dp], timeout=15)
            if output:
                break

    if not output:
        # fallback 1: smartctl -d nvme（DSM 6.5 可能需要显式指定设备类型）
        for dp in dev_paths_to_try:
            if os.path.exists(dp):
                smart_data = _parse_smartctl(dp, 'nvme')
                if smart_data:
                    smart_data['disk'] = dev
                    smart_data['type'] = 'nvme'
                    # 填补 smartctl 可能缺失的型号信息
                    if not smart_data.get('model') and info:
                        smart_data['model'] = info.get('model')
                    if not smart_data.get('serial') and info:
                        smart_data['serial'] = info.get('sn')
                    return smart_data

        # 所有采集方式均失败，且 nvme list 也未识别到该设备 → 无 NVMe 盘
        return None

    data = {
        'disk': dev, 'type': 'nvme',
        'health': 'PASSED', 'reallocated_sectors': 0,
        'power_on_hours': None, 'temperature': None,
        'wear_leveling': None, 'nvme_spare': None,
        'model': None, 'serial': None, 'size': None, 'rotation_rate': None,
    }

    # 从 nvme list 预填充基本信息
    if info:
        data['model'] = info.get('model')
        data['serial'] = info.get('sn')
        data['size'] = info.get('size')

    # 解析 nvme smart-log 输出
    for line in output.splitlines():
        line = line.strip()
        key_val = line.split(':', 1)
        if len(key_val) < 2:
            continue
        key = key_val[0].strip()
        val = key_val[1].strip()

        if key == 'critical_warning':
            try:
                cw = int(val)
                if cw > 0:
                    data['health'] = 'WARNING'
            except ValueError:
                pass
        elif key == 'temperature':
            m = re.match(r'(\d+)', val)
            if m:
                data['temperature'] = float(m.group(1))
        elif key == 'available_spare':
            m = re.match(r'(\d+)', val)
            if m:
                data['nvme_spare'] = int(m.group(1))
        elif key == 'percentage_used':
            m = re.match(r'(\d+)', val)
            if m:
                used = int(m.group(1))
                data['wear_leveling'] = max(0, 100 - used)
        elif key == 'power_on_hours':
            m = re.match(r'([\d,]+)', val)
            if m:
                data['power_on_hours'] = int(m.group(1).replace(',', ''))
        elif key == 'media_errors':
            m = re.match(r'(\d+)', val)
            if m and int(m.group(1)) > 0:
                data['reallocated_sectors'] = int(m.group(1))
                data['health'] = 'FAILED'

    return data


def _parse_synodisk_smart(output):
    """解析 synodisk --get_smart 的输出"""
    smart_list = []
    if not output:
        return smart_list
    # synodisk 输出格式不固定，尝试提取关键信息
    current_disk = {}
    for line in output.splitlines():
        line = line.strip()
        if not line:
            if current_disk:
                smart_list.append(current_disk)
                current_disk = {}
            continue
        m = re.search(r'/dev/(sata\w+)', line)
        if m:
            current_disk['disk'] = m.group(1)
            current_disk['type'] = 'sata'
        if 'SMART' in line and ('PASSED' in line or 'OK' in line):
            current_disk['health'] = 'PASSED'
        elif 'SMART' in line and ('FAILED' in line):
            current_disk['health'] = 'FAILED'
        m = re.search(r'Temperature[:\s]+(\d+)', line, re.IGNORECASE)
        if m:
            current_disk['temperature'] = float(m.group(1))
        m = re.search(r'Power\s+On\s+Hours[:\s]+([\d,]+)', line, re.IGNORECASE)
        if m:
            current_disk['power_on_hours'] = int(m.group(1).replace(',', ''))
    if current_disk:
        smart_list.append(current_disk)
    return smart_list


def _format_bytes(b):
    """将字节数转换为人类可读格式"""
    for unit in ('B', 'KB', 'MB', 'GB', 'TB', 'PB'):
        if abs(b) < 1024:
            return f"{b:.0f} {unit}" if unit == 'B' else f"{b:.1f} {unit}"
        b /= 1024
    return f"{b:.1f} EB"


def _parse_smartctl(dev_path, dev_type):
    """解析smartctl输出，提取关键SMART指标和磁盘基本信息（型号/SN/大小/温度）
    即使磁盘不支持 SMART（如 VMware 虚拟盘），也从 INFORMATION SECTION 提取基本磁盘信息"""
    # 初始化默认返回值
    data = {
        'health': 'UNKNOWN', 'reallocated_sectors': 0,
        'power_on_hours': None, 'temperature': None,
        'wear_leveling': None, 'nvme_spare': None,
        'model': None, 'serial': None, 'size': None, 'rotation_rate': None,
    }

    # 优先尝试JSON格式输出
    output = _run_safe(['smartctl', '-j', '-a', dev_path], timeout=15)
    json_parsed = False
    if output:
        try:
            smart_json = json.loads(output)
            json_parsed = True
            # ── 从 INFORMATION SECTION 提取磁盘基本信息（所有磁盘都有）──
            # 型号
            model_name = smart_json.get('model_name') or ''
            if not model_name:
                # 某些磁盘用 vendor + product 拼接
                vendor = smart_json.get('vendor', '')
                product = smart_json.get('product', '')
                if vendor and product:
                    model_name = f'{vendor} {product}'
            # JSON model_name 仍为空时，尝试从 json 的 messages 区域或直接从文本格式获取
            if not model_name:
                text_output = _run_safe(['smartctl', '-a', dev_path], timeout=15)
                if text_output:
                    m = re.search(r'Device Model:\s*(.+)', text_output)
                    if m:
                        model_name = m.group(1).strip()
                    else:
                        m = re.search(r'Product:\s*(.+)', text_output)
                        if m:
                            model_name = m.group(1).strip()
            data['model'] = model_name or None
            # 序列号
            data['serial'] = smart_json.get('serial_number') or None
            # 容量（字节转人类可读）
            user_capacity = smart_json.get('user_capacity', {})
            if isinstance(user_capacity, dict):
                bytes_val = user_capacity.get('bytes', 0)
                data['size'] = _format_bytes(bytes_val) if bytes_val else None
            elif isinstance(user_capacity, str):
                data['size'] = user_capacity or None
            # 转速
            rotation = smart_json.get('rotation_rate')
            if rotation is not None:
                data['rotation_rate'] = int(rotation)
            # 温度（仅信息段中的温度，可能值为 0 表示不可用）
            temp = smart_json.get('temperature', {}).get('current', None)
            if temp is not None and temp > 0:
                data['temperature'] = float(temp)

            # 健康状态
            if smart_json.get('smart_status', {}).get('passed', False):
                data['health'] = 'PASSED'
            elif smart_json.get('smart_status', {}).get('with_errors', False):
                data['health'] = 'FAILED'
            # 明确不支持 SMART 的磁盘
            if smart_json.get('smart_support', {}).get('available', True) is False:
                data['health'] = 'N/A'

            if dev_type == 'nvme':
                # NVMe JSON结构
                nvme = smart_json.get('nvme_smart_health_information_log', {})
                if nvme:
                    # Temperature
                    temp = nvme.get('temperature', 0)
                    if temp:
                        data['temperature'] = float(temp)
                    # Available Spare (百分比)
                    spare = nvme.get('available_spare', 0)
                    if spare:
                        data['nvme_spare'] = int(spare)
                    # Power On Hours
                    poh = nvme.get('power_on_hours', 0)
                    if poh:
                        data['power_on_hours'] = int(poh)
                    # Percentage Used (用于磨损计算)
                    used = nvme.get('percentage_used', 0)
                    if used:
                        data['wear_leveling'] = max(0, 100 - int(used))
            else:
                # SATA/SSD JSON结构
                atributes = smart_json.get('ata_smart_attributes', {}).get('table', [])
                for attr in atributes:
                    attr_id = attr.get('id', 0)
                    raw_val = attr.get('raw', {}).get('string', '')
                    value = attr.get('value', 0)

                    # 5 - Reallocated_Sector_Ct
                    if attr_id == 5:
                        data['reallocated_sectors'] = int(raw_val) if raw_val else 0
                    # 9 - Power_On_Hours
                    elif attr_id == 9:
                        data['power_on_hours'] = int(raw_val) if raw_val else None
                    # 177 - Wear_Leveling_Count (SSD)
                    elif attr_id == 177:
                        data['wear_leveling'] = value if value else None
                    # 190 / 194 - Temperature（ATA属性温度优先于信息段温度）
                    elif attr_id in (190, 194):
                        temp_val = attr.get('raw', {}).get('value', 0)
                        if temp_val and temp_val > 0:
                            data['temperature'] = float(temp_val)

            data['json_parsed'] = True
            return data
        except (json.JSONDecodeError, KeyError, ValueError):
            # JSON解析失败，使用文本fallback
            pass

    # Fallback: 使用文本解析
    if not json_parsed:
        output = _run_safe(['smartctl', '-a', dev_path], timeout=15)
        if not output:
            return None

        # ── 从 INFORMATION SECTION 提取磁盘基本信息（文本模式）──
        # 优先匹配 Device Model（大多数 SATA 磁盘的标准格式）
        m = re.search(r'Device Model:\s+(.+)', output)
        if m:
            data['model'] = m.group(1).strip()
        if not data.get('model'):
            m = re.search(r'Vendor:\s+(.+)', output)
            vendor_text = m.group(1).strip().rstrip(',') if m else ''
            m = re.search(r'Product:\s+(.+)', output)
            product_text = m.group(1).strip() if m else ''
            if vendor_text and product_text:
                data['model'] = f'{vendor_text} {product_text}'
            elif product_text:
                data['model'] = product_text
        m = re.search(r'Serial Number:\s+(\S+)', output)
        if m:
            data['serial'] = m.group(1).strip()
        m = re.search(r'User Capacity:\s+([\d,]+)\s+bytes', output)
        if m:
            data['size'] = _format_bytes(int(m.group(1).replace(',', '')))
        m = re.search(r'Rotation Rate:\s+(.+)', output)
        if m:
            rr = m.group(1).strip()
            data['rotation_rate'] = None if 'Solid State' in rr else (int(rr) if rr.isdigit() else rr)

        # 温度（INFORMATION SECTION，可能是 0）
        m = re.search(r'Current Drive Temperature:\s+(\d+)', output)
        if m:
            temp_val = int(m.group(1))
            if temp_val > 0:
                data['temperature'] = float(temp_val)

        # SMART 可用性
        if 'SMART support is:     Unavailable' in output:
            data['health'] = 'N/A'

        # 健康状态
        if 'SMART overall-health self-assessment test result: PASSED' in output:
            data['health'] = 'PASSED'
        elif 'SMART overall-health self-assessment test result: FAILED' in output:
            data['health'] = 'FAILED'

    # 文本模式下的 SMART 属性解析（仅当 JSON 解析未成功时）
    if not json_parsed:
        _output = output  # 确保变量存在
        if dev_type == 'nvme':
            # NVMe专用字段
            m = re.search(r'Percentage Used:\s+(\d+)%', _output)
            if m:
                data['wear_leveling'] = 100 - int(m.group(1))
            m = re.search(r'Available Spare:\s+(\d+)%', _output)
            if m:
                data['nvme_spare'] = int(m.group(1))
            m = re.search(r'Power On Hours:\s+([\d,]+)', _output)
            if m:
                data['power_on_hours'] = int(m.group(1).replace(',', ''))
            m = re.search(r'Temperature[:\s]+(\d+)(?:\s*(?:C|Celsius|°C))?', _output)
            if m:
                data['temperature'] = float(m.group(1))
        else:
            # SATA HDD/SSD 属性ID
            # 5  - Reallocated_Sector_Ct（坏道）
            m = re.search(r'\s+5\s+Reallocated_Sector_Ct\s+\S+\s+\d+\s+\d+\s+\d+\s+\S+\s+\S+\s+\S+\s+(\d+)', _output)
            if m:
                data['reallocated_sectors'] = int(m.group(1))
            # 9  - Power_On_Hours（通电时长）
            m = re.search(r'\s+9\s+Power_On_Hours\s+\S+\s+\d+\s+\d+\s+\d+\s+\S+\s+\S+\s+\S+\s+([\d,]+)', _output)
            if m:
                data['power_on_hours'] = int(m.group(1).replace(',', ''))
            # 194 / 190 - Temperature（ATA属性温度优先于信息段温度）
            m = re.search(r'\s+19[04]\s+\S+\s+\S+\s+\d+\s+\d+\s+\d+\s+\S+\s+\S+\s+\S+\s+(\d+)', _output)
            if m and int(m.group(1)) > 0:
                data['temperature'] = float(m.group(1))
            # 177 - Wear_Leveling_Count（SSD磨损）
            m = re.search(r'\s+177\s+Wear_Leveling_Count\s+\S+\s+(\d+)', _output)
            if m:
                data['wear_leveling'] = int(m.group(1))

        data['raw_output'] = _output[:2000]  # 保留前2000字符的原始输出

    return data


# ══════════════════════════════════════════
# 安全监控模块
# ══════════════════════════════════════════

# 监控的配置文件列表（MD5比对）
WATCHED_FILES = [
    '/etc/passwd', '/etc/shadow', '/etc/sudoers', '/etc/hosts',
    '/etc/ssh/sshd_config', '/etc/iptables/rules.v4',
    '/etc/nftables.conf', '/etc/hostname', '/etc/resolv.conf',
]

FILE_HASH_CACHE = os.path.join(CACHE_DIR, 'file_hashes.json')
LOGIN_HISTORY_CACHE = os.path.join(CACHE_DIR, 'login_history.json')


def md5_file(filepath):
    """计算文件MD5，文件超过 10MB 则跳过（防止阻塞）"""
    try:
        fsize = os.path.getsize(filepath)
        if fsize > 10 * 1024 * 1024:
            logger.warning(f'md5_file: 跳过超大文件 {filepath} ({fsize // 1024}KB)')
            return None
        h = hashlib.md5()
        with open(filepath, 'rb') as f:
            for chunk in iter(lambda: f.read(8192), b''):
                h.update(chunk)
        return h.hexdigest()
    except Exception:
        return None


def check_file_changes():
    """检测配置文件变更"""
    events = []
    # 读取历史哈希
    old_hashes = {}
    if os.path.exists(FILE_HASH_CACHE):
        try:
            with open(FILE_HASH_CACHE) as f:
                old_hashes = json.load(f)
        except Exception:
            pass

    new_hashes = {}
    for filepath in WATCHED_FILES:
        if not os.path.exists(filepath):
            continue
        current_hash = md5_file(filepath)
        if current_hash is None:
            continue
        new_hashes[filepath] = current_hash
        old_hash = old_hashes.get(filepath)
        if old_hash and old_hash != current_hash:
            events.append({
                'type': 'file_change',
                'severity': 'warning',
                'title': f'配置文件变更: {filepath}',
                'detail': {'file': filepath, 'old_md5': old_hash, 'new_md5': current_hash},
                'time': datetime.now(timezone.utc).isoformat(),
            })
            logger.warning(f'配置文件变更检测: {filepath}')

    # 保存最新哈希（原子写入，防止 SIGTERM 导致文件损坏）
    if not _terminating:
        tmp_hash = FILE_HASH_CACHE + '.tmp'
        try:
            with open(tmp_hash, 'w', encoding='utf-8') as f:
                json.dump(new_hashes, f)
                f.flush()
                os.fsync(f.fileno())
            os.chmod(tmp_hash, 0o600)
            os.rename(tmp_hash, FILE_HASH_CACHE)
        except Exception:
            try:
                os.unlink(tmp_hash)
            except Exception:
                pass

    return events


def _read_log_grep(logfile, keyword, tail_n=50):
    """安全读取日志文件的最后 tail_n 行中包含 keyword（不区分大小写）的行"""
    if not os.path.exists(logfile):
        return ''
    output = _run(['tail', '-n', str(tail_n), logfile])
    if not output:
        return ''
    return '\n'.join(l for l in output.splitlines() if keyword.lower() in l.lower())


def _read_log_grep_multi(logfile, keywords, tail_n=50):
    """安全读取日志文件的最后 tail_n 行中匹配任一 keyword 正则的行"""
    if not os.path.exists(logfile):
        return ''
    output = _run(['tail', '-n', str(tail_n), logfile])
    if not output:
        return ''
    pattern = re.compile('|'.join(keywords), re.IGNORECASE)
    return '\n'.join(l for l in output.splitlines() if pattern.search(l))


def get_login_records(cfg):
    """采集登录记录，检测异常登录"""
    records = []
    security_events = []

    try:
        # 读取最近50条登录记录
        # DSM: 使用 synolog 获取 SSH 登录日志（last 命令在 DSM 上行为不一致）
        if IS_DSM:
            # 方式1：从 synolog/synossh.log 直接提取
            output = _read_log_grep('/var/log/synolog/synossh.log', 'accepted', 200)
            if not output:
                # 方式2：grep /var/log/messages 中的 sshd accepted（增加 tail 行数）
                output = _read_log_grep_multi('/var/log/messages',
                    ['sshd.*accepted', 'sshd.*session opened'], tail_n=500)
            if not output:
                # 方式3：/var/log/auth.log（部分 DSM 版本有此路径）
                output = _read_log_grep('/var/log/auth.log', 'accepted', 200)
            if not output:
                # 方式4：journalctl（DSM7 部分版本可用）
                jout = _run(['journalctl', '-u', 'sshd', '--no-pager', '-n', '200'])
                if jout:
                    output = '\n'.join(l for l in jout.splitlines() if 'accepted' in l.lower())
            if not output:
                # 方式5：最后兜底 last 命令
                output = _run(['last', '-n', '50'])
        else:
            # 非 DSM 系统：多方式获取登录记录
            login_output = None
            # 方式1：last 命令（避免 -i 在不同发行版含义不同）
            for last_args in [['last', '-n', '50', '--dns=no', '-w'],
                              ['last', '-n', '50', '-w'],
                              ['last', '-n', '50']]:
                last_out = _run(last_args)
                if last_out:
                    login_output = last_out
                    break
            # 方式2：如果 last 无有效记录，从 auth 日志中提取 Accepted 行
            # 注意：CentOS 使用 /var/log/secure，Debian 使用 /var/log/auth.log
            # tail 行数增加到 500，避免被其他日志淹没 SSH 记录
            if not login_output or 'wtmp' in (login_output.strip().splitlines() or [''])[-1:]:
                auth_output = ''
                # 按优先级检查各日志路径（/var/log/secure 对 CentOS 最优先）
                auth_log_paths = ['/var/log/secure', '/var/log/auth.log']
                for auth_log in auth_log_paths:
                    auth_output = _read_log_grep(auth_log, 'accepted', tail_n=500)
                    if auth_output:
                        login_output = auth_output
                        break
                # 方式3：journalctl 兜底（CentOS 7+ / Debian 8+ 均支持）
                if not login_output:
                    jout = _run(['journalctl', '-u', 'sshd', '--no-pager', '-n', '200'])
                    if jout:
                        login_output = '\n'.join(l for l in jout.splitlines()
                                                 if 'accepted' in l.lower() or 'Accepted' in l)
            output = login_output or ''
        if not output:
            return records, security_events

        # 读取常用登录IP（历史记录）
        trusted_ips = set()
        if os.path.exists(LOGIN_HISTORY_CACHE):
            try:
                with open(LOGIN_HISTORY_CACHE) as f:
                    trusted_ips = set(json.load(f).get('trusted_ips', []))
            except Exception:
                pass

        # 匹配 IPv4 或 IPv6 地址
        _ip_re = re.compile(r'^\d{1,3}(\.\d{1,3}){3}$|^[0-9a-fA-F:]+$')
        # 匹配 weekday 名称（Mon/Tue/Wed/... 会被误解析为 IP）
        _weekday_re = re.compile(r'^(Mon|Tue|Wed|Thu|Fri|Sat|Sun)$')
        # 匹配 ISO 时间戳（会被误解析为 IP）
        _iso_ts_re = re.compile(r'^\d{4}-\d{2}-\d{2}')

        new_ips = set()

        # DSM syslog 格式预处理：从 "May 14 14:30:27 test sshd[1234]: Accepted password for root from 192.168.10.1" 提取结构化登录记录
        if IS_DSM and output:
            _syslog_login_re = re.compile(
                r'(\w{3}\s+\d{1,2}\s+\d{2}:\d{2}:\d{2})\s+\S+\s+sshd[\[\]]?\d*\]?:\s+'
                r'Accepted\s+(?:password|publickey)\s+for\s+(\S+)\s+from\s+(\d+\.\d+\.\d+\.\d+)'
            )
            syslog_matches = _syslog_login_re.findall(output)
            if syslog_matches:
                for time_str, user, ip in syslog_matches[:50]:
                    record = {
                        'username': user, 'ip': ip,
                        'time': time_str,
                        'is_abnormal': False, 'abnormal_reason': '',
                    }
                    records.append(record)
                    if ip not in ('localhost', '') and ip not in new_ips:
                        new_ips.add(ip)
                # DSM syslog 已提取到记录，跳过 last 格式解析
                return records, security_events

        # 非 DSM 系统：检测是否为 auth log 格式（"May 14 17:15:23 host sshd[123]: Accepted ..."）
        # 或 last 格式（"root pts/0 192.168.x.x ..."）
        _auth_log_login_re = re.compile(
            r'(\w{3}\s+\d{1,2}\s+\d{2}:\d{2}:\d{2})\s+\S+\s+sshd[\[\]]?\d*\]?:\s+'
            r'Accepted\s+(?:password|publickey|keyboard-interactive)\s+for\s+(\S+)\s+from\s+(\S+)'
        )
        # 如果第一行匹配 auth log 格式，整个 output 按 auth log 解析
        first_line = output.strip().splitlines()[0] if output.strip() else ''
        if _auth_log_login_re.search(first_line):
            auth_matches = _auth_log_login_re.findall(output)
            for time_str, user, ip in auth_matches[:50]:
                # 清理 IP（去除可能的端口后缀）
                ip = ip.strip()
                record = {
                    'username': user, 'ip': ip,
                    'time': _local_time_to_utc(time_str),
                    'is_abnormal': False, 'abnormal_reason': '',
                }
                records.append(record)
                if ip not in ('localhost', '') and ip not in new_ips:
                    new_ips.add(ip)
            # auth log 已提取到记录，跳过 last 格式解析
            return records, security_events

        # last 命令格式解析
        for line in output.strip().splitlines():
            parts = line.split()
            if len(parts) < 4:
                continue
            if parts[0] in ('wtmp', 'wtmpdb', 'reboot', 'runlevel', 'shutdown', 'boot'):
                continue

            username = parts[0]
            # parts[1] 是终端名 (pts/0, tty1, etc.)
            # parts[2] 可能是 IP、weekday 或 ISO 时间戳
            raw_ip = parts[2] if len(parts) > 2 else ''

            # 判断 parts[2] 是否是有效 IP 地址
            if _ip_re.match(raw_ip) and not _weekday_re.match(raw_ip) and not _iso_ts_re.match(raw_ip):
                ip = raw_ip
                # 时间字段在 parts[3] 之后，可能是 ISO、BSD 或传统格式
                login_time = ''
                # 尝试 BSD 时间格式：Wed May 14 02:11:25 2026
                _month_re = re.compile(r'^(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)$')
                for i in range(3, min(len(parts), 9)):
                    p = parts[i]
                    if _iso_ts_re.match(p):
                        login_time = p
                        break
                    elif _month_re.match(p) and i + 2 < len(parts):
                        # BSD 格式: May 14 02:11:25
                        login_time = f"{parts[i]} {parts[i+1]} {parts[i+2]}"
                        break
                    elif _weekday_re.match(p):
                        continue
                    elif ':' in p and not _ip_re.match(p):
                        # 纯时间 HH:MM 或 HH:MM:SS
                        login_time = p
                        break
            else:
                # 无远程 IP（本地 tty 登录或 IP 列被 weekday/时间戳占据）
                ip = ''
                # 尝试从剩余字段提取时间
                login_time = ''
                for p in parts[2:]:
                    if _iso_ts_re.match(p):
                        login_time = p
                        break
                    elif _weekday_re.match(p):
                        continue
                    else:
                        # 非 weekday 也非 ISO 时间戳，可能是传统时间格式
                        # 跳过 "still" "logged" "in" 等状态词
                        if p not in ('still', 'logged', 'in', 'gone', 'down', '-'):
                            login_time = p
                            break

            # 过滤本机登录
            if ip in ('0.0.0.0', ':0', ':0.0', '::1', '127.0.0.1'):
                ip = 'localhost'

            # 过滤完全无效的条目（IP和登录时间均为空）
            login_time_str = login_time[:19] if len(login_time) >= 10 else ''
            if not ip and not login_time_str:
                continue
            # 登录时间来自last命令（本地时间），转换为UTC
            login_time_utc = _local_time_to_utc(login_time_str)

            record = {
                'username': username, 'ip': ip,
                'time': login_time_utc,
                'is_abnormal': False, 'abnormal_reason': '',
            }

            # 异常检测：新IP登录
            if ip and ip != 'localhost' and ip not in trusted_ips and len(trusted_ips) > 5:
                record['is_abnormal'] = True
                record['abnormal_reason'] = f'新IP登录: {ip}'
                security_events.append({
                    'type': 'login_fail',
                    'severity': 'warning',
                    'title': f'异地登录检测: {username} 来自 {ip}',
                    'detail': record,
                    'time': datetime.now(timezone.utc).isoformat(),
                })

            if ip and ip != 'localhost':
                new_ips.add(ip)
            records.append(record)

        # 更新信任IP（最近常用）
        trusted_ips.update(new_ips)
        if len(trusted_ips) > 100:
            trusted_ips = set(list(trusted_ips)[-100:])
        try:
            if not _terminating:
                tmp_lh = LOGIN_HISTORY_CACHE + '.tmp'
                with open(tmp_lh, 'w', encoding='utf-8') as f:
                    json.dump({'trusted_ips': list(trusted_ips)}, f)
                    f.flush()
                    os.fsync(f.fileno())
                os.chmod(tmp_lh, 0o600)
                os.rename(tmp_lh, LOGIN_HISTORY_CACHE)
        except Exception:
            try:
                os.unlink(LOGIN_HISTORY_CACHE + '.tmp')
            except Exception:
                pass

        # 检测SSH暴力破解（auth.log / secure）
        # 核心逻辑：解析最近5000条日志中的Failed password记录，
        # 提取攻击IP和次数，通过与上次缓存对比判断是否有新增（增长率>0才告警）
        _ssh_fail_cache = os.path.join(CACHE_DIR, 'ssh_fail_count.json')
        _prev_fail_count = 0
        if os.path.exists(_ssh_fail_cache):
            try:
                with open(_ssh_fail_cache) as _fc:
                    _prev_fail_count = json.load(_fc).get('fail_count', 0)
            except Exception:
                pass

        for auth_log in ['/var/log/auth.log', '/var/log/secure',
                         '/var/log/synolog/synossh.log', '/var/log/messages',
                         '/var/log/syslog']:
            if os.path.exists(auth_log):
                # 安全预检：跳过超过 20MB 的日志文件（防止内存爆满）
                try:
                    if os.path.getsize(auth_log) > 20 * 1024 * 1024:
                        logger.warning(f'日志文件过大({os.path.getsize(auth_log)//1024//1024}MB)，跳过: {auth_log}')
                        continue
                except OSError:
                    continue
                # 获取最近2000条中的Failed password行
                fail_output = _run(['tail', '-2000', auth_log])
                if fail_output:
                    fail_lines = [l for l in fail_output.strip().splitlines() if 'Failed password' in l]
                    current_fail_count = len(fail_lines)

                    # 提取攻击IP来源统计（从日志中解析 "from <IP>" 字段）
                    ip_stats = {}
                    sample_lines = []
                    for line in fail_lines:
                        m = re.search(r'from\s+([\d.:a-fA-F]+)', line)
                        if m:
                            src_ip = m.group(1)
                            ip_stats[src_ip] = ip_stats.get(src_ip, 0) + 1

                        # 保留最近的日志样例
                        sample_lines.append(line.strip())
                        if len(sample_lines) > 5:
                            sample_lines.pop(0)

                    # 按攻击次数排序IP
                    top_ips = sorted(ip_stats.items(), key=lambda x: -x[1])[:5]

                    # 只有当前失败次数 >= 5 且相比上次有增长时才判定为暴力破解
                    new_fails = current_fail_count - _prev_fail_count
                    if current_fail_count >= 5 and new_fails > 0:
                        severity_level = 'critical' if current_fail_count >= 20 else 'warning'
                        security_events.append({
                            'type': 'login_fail',
                            'severity': severity_level,
                            'title': f'SSH暴力破解检测（共 {current_fail_count} 次失败，新增 {new_fails} 次）',
                            'detail': {
                                'fail_count': current_fail_count,
                                'new_fails': new_fails,
                                'attack_ips': [{'ip': ip, 'count': cnt} for ip, cnt in top_ips],
                                'log': sample_lines,
                            },
                            'time': datetime.now(timezone.utc).isoformat(),
                        })
                    elif current_fail_count >= 5 and new_fails == 0:
                        logger.info(f'SSH登录失败次数维持 {current_fail_count} 次（无增长），跳过重复告警')

                    # 更新缓存（始终更新，用于下次增量比对）
                    try:
                        if not _terminating:
                            tmp_sf = _ssh_fail_cache + '.tmp'
                            with open(tmp_sf, 'w') as _fc:
                                json.dump({'fail_count': current_fail_count}, _fc)
                                _fc.flush()
                                os.fsync(_fc.fileno())
                            os.chmod(tmp_sf, 0o600)
                            os.rename(tmp_sf, _ssh_fail_cache)
                    except Exception:
                        try:
                            os.unlink(_ssh_fail_cache + '.tmp')
                        except Exception:
                            pass
                break

    except Exception as e:
        logger.warning(f'登录记录采集失败: {e}')

    return records, security_events


def check_intrusion():
    """入侵检测：可疑进程、异常网络连接、敏感命令"""
    events = []

    # 检测可疑网络连接（反弹shell特征端口）
    try:
        output = _run(['ss', '-tunp']) or _run(['netstat', '-tunp'])
        if output:
            suspicious_ports = {4444, 5555, 6666, 7777, 8888, 9999, 1234, 31337}
            for line in output.splitlines():
                for port in suspicious_ports:
                    if f':{port} ' in line and 'ESTABLISHED' in line:
                        events.append({
                            'type': 'intrusion',
                            'severity': 'critical',
                            'title': f'可疑网络连接（端口 {port}）',
                            'detail': {'connection': line.strip()},
                            'time': datetime.now(timezone.utc).isoformat(),
                        })
    except Exception:
        pass

    # 检测 /tmp /dev/shm 下的可执行文件（兼容 busybox find）
    try:
        for check_dir in ['/tmp', '/dev/shm', '/var/tmp']:
            if not os.path.isdir(check_dir):
                continue
            if IS_DSM:
                # DSM busybox find 不支持 -perm /111，改用 -executable（busybox 支持）
                output = _run(['find', check_dir, '-maxdepth', '2', '-type', 'f', '-executable'])
            else:
                output = _run(['find', check_dir, '-maxdepth', '2', '-type', 'f', '-perm', '/111'])
            if output:
                # 白名单：排除已知安全的临时文件模式
                whitelist_patterns = [
                    '/tmp/ks-script-',     # Anaconda/kickstart 安装脚本
                    '/tmp/systemd-',       # systemd 临时文件
                    '/tmp/pip-',           # pip 临时文件
                    '/tmp/npm-',           # npm 临时文件
                    '/tmp/go-build',       # Go 编译临时文件
                    '/tmp/makepkg',        # makepkg 临时文件
                ]
                # 扩展名白名单：SCP传输的压缩包/日志等自带执行权限，非可疑
                safe_extensions = {'.tar.gz', '.tgz', '.tar', '.zip', '.gz', '.bz2',
                                   '.xz', '.7z', '.rar', '.log', '.json', '.xml',
                                   '.yaml', '.yml', '.txt', '.csv', '.md', '.conf',
                                   '.cfg', '.ini', '.properties', '.deb', '.rpm',
                                   '.apk', '.iso', '.img', '.sha256', '.sum', '.sig'}
                exe_files = [f for f in output.strip().splitlines() if f.strip()
                             and not any(f.startswith(p) for p in whitelist_patterns)]
                # 排除已知安全扩展名的文件
                exe_files = [f for f in exe_files
                             if not any(f.endswith(ext) for ext in safe_extensions)]
                # 排除源码编译产物（子目录中的可执行文件，如 Python-*/python）
                exe_files = [f for f in exe_files
                             if not re.search(r'/tmp/[^/]+/[^/]+\.\w+$', f)
                             and not re.search(r'/tmp/\S+-\d+\.\d+', f)]
                if exe_files:
                    events.append({
                        'type': 'intrusion',
                        'severity': 'warning',
                        'title': f'发现可疑可执行文件于 {check_dir}',
                        'detail': {'files': exe_files[:10]},
                        'time': datetime.now(timezone.utc).isoformat(),
                    })
    except Exception:
        pass

    return events


def check_firewall():
    """防火墙状态检测（兼容 DSM 自有防火墙）"""
    events = []
    FIREWALL_CACHE = os.path.join(CACHE_DIR, 'firewall_rules.json')

    def _normalize_iptables(raw):
        """规范化 iptables-save 输出，去除 [packets:bytes] 计数器和注释行，
        避免因连接数/包计数变化导致误报"""
        lines = raw.strip().splitlines()
        cleaned = []
        for line in lines:
            line = line.strip()
            if not line or line.startswith('#') or line.startswith('COMMIT'):
                continue
            # 去除 [packets:bytes] 计数器，如 "-A INPUT -s 1.2.3.4 [0:0]" → "-A INPUT -s 1.2.3.4"
            line = re.sub(r'\s*\[\d+:\d+\]', '', line)
            cleaned.append(line)
        return '\n'.join(sorted(cleaned))

    def _normalize_nftables(raw):
        """规范化 nft list ruleset 输出，去除动态计数器、handle、注释和空白行"""
        lines = raw.strip().splitlines()
        cleaned = []
        for line in lines:
            line = line.strip()
            if not line or line.startswith('#'):
                continue
            # 去除行首的 table/chain 数量和 flags (如 "table inet filter {")
            # 去除每个规则末尾的 handle 编号 (如 "# handle 42")
            line = re.sub(r'\s*#\s*handle\s+\d+', '', line)
            # 去除 packets/counter 计数 (如 "counter packets 12345 bytes 67890")
            line = re.sub(r'\bcounter\s+packets\s+\d+\s+bytes\s+\d+', '', line)
            line = line.strip()
            if not line:
                continue
            cleaned.append(line)
        return '\n'.join(sorted(cleaned))

    def _normalize_firewalld(raw):
        """规范化 firewall-cmd --list-all 输出，去除时间戳等动态内容"""
        lines = raw.strip().splitlines()
        cleaned = []
        for line in lines:
            line = line.strip()
            if not line or line.startswith('#'):
                continue
            cleaned.append(line)
        return '\n'.join(sorted(cleaned))

    def get_fw_rules():
        rules = {}
        if IS_DSM:
            out = _run(['iptables-save'])
            if out:
                rules['iptables'] = hashlib.md5(_normalize_iptables(out).encode()).hexdigest()
        else:
            out = _run(['iptables-save'])
            if out:
                rules['iptables'] = hashlib.md5(_normalize_iptables(out).encode()).hexdigest()
            out = _run(['nft', 'list', 'ruleset'])
            if out:
                rules['nftables'] = hashlib.md5(_normalize_nftables(out).encode()).hexdigest()
            out = _run(['firewall-cmd', '--list-all'])
            if out:
                rules['firewalld'] = hashlib.md5(_normalize_firewalld(out).encode()).hexdigest()
        return rules

    current_rules = get_fw_rules()
    if not current_rules:
        return events

    old_rules = {}
    if os.path.exists(FIREWALL_CACHE):
        try:
            with open(FIREWALL_CACHE) as f:
                old_rules = json.load(f)
        except Exception:
            pass

    for fw_type, current_hash in current_rules.items():
        old_hash = old_rules.get(fw_type)
        if old_hash and old_hash != current_hash:
            events.append({
                'type': 'firewall',
                'severity': 'warning',
                'title': f'防火墙规则变更: {fw_type}',
                'detail': {'fw_type': fw_type},
                'time': datetime.now(timezone.utc).isoformat(),
            })
            logger.warning(f'防火墙规则变更检测: {fw_type}')

    try:
        if not _terminating:
            tmp_fw = FIREWALL_CACHE + '.tmp'
            with open(tmp_fw, 'w', encoding='utf-8') as f:
                json.dump(current_rules, f)
                f.flush()
                os.fsync(f.fileno())
            os.chmod(tmp_fw, 0o600)
            os.rename(tmp_fw, FIREWALL_CACHE)
    except Exception:
        try:
            os.unlink(FIREWALL_CACHE + '.tmp')
        except Exception:
            pass

    return events


# ══════════════════════════════════════════
# 资产采集模块
# ══════════════════════════════════════════

def get_asset_info():
    """采集硬件信息（已移除软件清单采集，减少执行时间和 payload 体积）"""
    assets = {'hardware': {}}

    # CPU信息
    try:
        with open('/proc/cpuinfo') as f:
            for line in f:
                if 'model name' in line:
                    assets['hardware']['cpu_model'] = line.split(':', 1)[1].strip()
                    break
    except Exception:
        pass

    # 内存总量
    try:
        with open('/proc/meminfo') as f:
            for line in f:
                if line.startswith('MemTotal:'):
                    kb = int(line.split()[1])
                    assets['hardware']['mem_total'] = f'{kb // 1024} MB'
                    break
    except Exception:
        pass

    # 磁盘列表
    try:
        if IS_DSM:
            # DSM: 使用 synodisk 或枚举 /dev/sata*
            disks = []
            output = _run(['synodisk', '--list'])
            if output:
                for line in output.splitlines():
                    m = re.search(r'/dev/(sata\w+)', line)
                    if m:
                        disks.append(m.group(1))
            if not disks:
                for i in range(1, 16):
                    if os.path.exists(f'/dev/sata{i}'):
                        disks.append(f'sata{i}')
            if disks:
                assets['hardware']['disks'] = disks
        else:
            output = _run(['lsblk', '-d', '-o', 'NAME,SIZE,MODEL'])
            if output:
                disk_list = []
                for line in output.strip().splitlines()[1:]:  # 跳过头部 "NAME SIZE MODEL"
                    parts = line.split(None, 2)
                    if len(parts) >= 2:
                        disk_info = f'{parts[0]} ({parts[1]})'
                        if len(parts) >= 3:
                            disk_info += f' - {parts[2].strip()}'
                        disk_list.append(disk_info)
                assets['hardware']['disks'] = disk_list
    except Exception:
        pass

    # 主板信息
    if not IS_DSM:
        for dmi_path in ['/sys/class/dmi/id/board_name', '/sys/class/dmi/id/product_name']:
            try:
                if os.path.exists(dmi_path):
                    with open(dmi_path) as f:
                        assets['hardware']['motherboard'] = f.read().strip()
                    break
            except Exception:
                pass
    else:
        # DSM: 尝试读取型号信息
        try:
            synoinfo = '/etc/default/synoinfo.conf'
            if os.path.exists(synoinfo):
                with open(synoinfo, errors='ignore') as f:
                    for line in f:
                        if 'unique=' in line:
                            assets['hardware']['motherboard'] = 'Synology ' + line.split('=', 1)[1].strip().strip('"')
                            break
        except Exception:
            pass

    # 内存模块（DIMM）信息
    try:
        mem_modules = []
        if IS_DSM:
            out = _run(['synodmidecode', '-t', 'memory'], timeout=10)
        else:
            out = _run(['dmidecode', '-t', 'memory'], timeout=10)
        if out:
            current = {}
            for line in out.splitlines():
                line = line.strip()
                if not line and current:
                    if current.get('size') and 'No Module' not in current.get('size', ''):
                        mem_modules.append({
                            'locator': current.get('locator', ''),
                            'size': current.get('size', ''),
                            'type': current.get('type', ''),
                            'speed': current.get('speed', ''),
                            'manufacturer': current.get('manufacturer', ''),
                            'serial': current.get('serial', ''),
                        })
                    current = {}
                    continue
                if ':' in line:
                    key, val = line.split(':', 1)
                    key, val = key.strip().lower().replace(' ', '_'), val.strip()
                    if key in ('size', 'type', 'speed', 'manufacturer', 'serial_number', 'locator'):
                        if key == 'serial_number':
                            key = 'serial'
                        current[key] = val
            # 处理最后一条
            if current and current.get('size') and 'No Module' not in current.get('size', ''):
                mem_modules.append({
                    'locator': current.get('locator', ''),
                    'size': current.get('size', ''),
                    'type': current.get('type', ''),
                    'speed': current.get('speed', ''),
                    'manufacturer': current.get('manufacturer', ''),
                    'serial': current.get('serial', ''),
                })
        if mem_modules:
            assets['hardware']['memory_modules'] = mem_modules
    except Exception:
        pass

    # 网卡列表（过滤纯虚拟接口，减少数据冗余）
    try:
        output = _run(['ip', 'link', 'show'])
        if output:
            # 虚拟接口前缀（与 get_network_info 保持一致）
            _virtual_nic_prefixes = ('bond', 'ipddp', 'teql', 'tunl', 'gre', 'gretap',
                                     'erspan', 'ip_vti', 'ip6_vti', 'sit', 'ip6tnl',
                                     'ip6gre', 'dummy', 'veth', 'macvlan', 'macvtap',
                                     'docker', 'cali', 'flannel', 'cni', 'kube', 'lxc',
                                     'tap', 'virbr', 'ovs-system')
            cards = []
            for line in output.splitlines():
                m = re.match(r'^\d+:\s+(\S+):', line)
                if m:
                    name = m.group(1).split('@')[0]
                    if name == 'lo':
                        continue
                    # 过滤纯虚拟接口
                    if any(name.startswith(p) for p in _virtual_nic_prefixes):
                        continue
                    cards.append(name)
            if cards:
                assets['hardware']['network_cards'] = cards
    except Exception:
        pass

    return assets


# ─────────────── Token 管理 ───────────────
TOKEN_FILE = os.path.join(CACHE_DIR, '.node_token')

def load_token():
    """加载本地保存的节点 token"""
    if os.path.exists(TOKEN_FILE):
        try:
            with open(TOKEN_FILE, 'r') as f:
                return f.read().strip()
        except Exception:
            pass
    return None

def save_token(token):
    """保存服务端下发的 token 到本地（原子写入，防止 SIGTERM 导致文件损坏）"""
    if _terminating:
        return
    try:
        tmp_file = TOKEN_FILE + '.tmp'
        with open(tmp_file, 'w') as f:
            f.write(token)
            f.flush()
            os.fsync(f.fileno())
        os.chmod(tmp_file, 0o600)
        os.rename(tmp_file, TOKEN_FILE)
    except Exception as e:
        logger.warning(f'保存 token 失败: {e}')
        try:
            os.unlink(TOKEN_FILE + '.tmp')
        except Exception:
            pass


# ══════════════════════════════════════════
# HTTP上报模块
# ══════════════════════════════════════════

def _truncate_large_fields(data):
    """截断 payload 中的大字段，防止内存溢出"""
    if isinstance(data.get('sys_logs'), list) and len(data['sys_logs']) > 50:
        data['sys_logs'] = data['sys_logs'][:50]
    proc = data.get('processes', {})
    for key in ('cpu_top5', 'mem_top5', 'cpu_top10', 'mem_top10', 'zombie', 'abnormal'):
        if isinstance(proc.get(key), list) and len(proc[key]) > 20:
            proc[key] = proc[key][:20]
    if isinstance(data.get('listening_ports'), list) and len(data['listening_ports']) > 50:
        data['listening_ports'] = data['listening_ports'][:50]


def http_post(url, data, node_id, timeout=30, retry=3):
    """发送HTTP POST请求（支持gzip压缩，自动携带token，失败时缓存）"""
    body = json.dumps(data, ensure_ascii=False).encode('utf-8')

    # 防止大 payload 导致 OOM：超过 5MB 时截断大字段
    MAX_PAYLOAD_BYTES = 5 * 1024 * 1024  # 5MB
    if len(body) > MAX_PAYLOAD_BYTES:
        logger.warning(f'上报数据过大 ({len(body)} bytes)，截断大字段...')
        _truncate_large_fields(data)
        body = json.dumps(data, ensure_ascii=False).encode('utf-8')
        if len(body) > MAX_PAYLOAD_BYTES:
            logger.error(f'截断后仍超过 {MAX_PAYLOAD_BYTES} bytes，跳过本次上报')
            return False

    compressed = gzip.compress(body)

    headers = {
        'Content-Type': 'application/json',
        'Content-Encoding': 'gzip',
        'X-Node-ID': node_id,
    }

    # 携带已保存的 token
    saved_token = load_token()
    if saved_token:
        headers['X-Node-Token'] = saved_token

    for attempt in range(retry):
        try:
            req = urllib.request.Request(url, data=compressed, headers=headers, method='POST')
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                resp_data = json.loads(resp.read().decode('utf-8'))
                if resp_data.get('code') == 0:
                    # 首次注册时保存服务端下发的 token
                    if resp_data.get('registered') and resp_data.get('token'):
                        save_token(resp_data['token'])
                        logger.info(f'节点注册成功，token 已保存')
                    logger.info(f'上报成功: {url}')
                    return True
                else:
                    logger.warning(f'服务端返回错误: {resp_data}')
                    return False
        except urllib.error.URLError as e:
            logger.warning(f'上报失败（尝试 {attempt+1}/{retry}）: {e}')
            if attempt < retry - 1:
                time.sleep(5 * (attempt + 1))
        except Exception as e:
            logger.error(f'上报异常: {e}')
            break

    # 失败时缓存到本地
    _cache_failed_report(data, node_id)
    return False


def _cache_failed_report(data, node_id):
    """缓存上报失败的数据（原子写入：先写临时文件再 rename，防止 SIGTERM 导致文件损坏）"""
    if _terminating:
        logger.warning('正在终止，跳过缓存写入')
        return
    cache_file = os.path.join(CACHE_DIR, f'pending_{int(time.time())}.json')
    tmp_file = cache_file + '.tmp'
    try:
        with open(tmp_file, 'w', encoding='utf-8') as f:
            json.dump({'data': data, 'node_id': node_id, 'cached_at': time.time()}, f)
            f.flush()
            os.fsync(f.fileno())
        os.chmod(tmp_file, 0o600)
        os.rename(tmp_file, cache_file)  # 原子操作
        logger.info(f'已缓存未上报数据: {cache_file}')
    except Exception as e:
        logger.error(f'缓存失败: {e}')
        try:
            os.unlink(tmp_file)
        except Exception:
            pass


def retry_cached_reports(server_url, node_id):
    """重试发送缓存的失败上报"""
    cache_files = sorted(Path(CACHE_DIR).glob('pending_*.json'))
    for cache_file in cache_files:
        try:
            with open(cache_file) as f:
                cached = json.load(f)
            # 超过24小时的缓存丢弃
            if time.time() - cached.get('cached_at', 0) > 86400:
                cache_file.unlink()
                continue
            ok = http_post(f'{server_url}/api/report/metrics', cached['data'], node_id)
            if ok:
                cache_file.unlink()
                logger.info(f'缓存数据重传成功: {cache_file}')
        except Exception as e:
            logger.warning(f'重试缓存失败: {e}')


# ══════════════════════════════════════════
# RAID信息采集模块（DSM专用）
# ══════════════════════════════════════════

def get_raid_info():
    """采集DSM RAID阵列信息（mdadm + /proc/mdstat 交叉验证）

    交叉验证策略：
    - 优先使用 mdadm --detail 的详细输出（设备状态、成员盘）
    - 同时解析 /proc/mdstat 获取内核视角的阵列状态
    - 当 mdadm 报告 degraded 但 failed=0 时，交叉检查 mdstat 确认
    - 如果 mdstat 显示 [U_U] 等降级模式则确认真实降级，否则标记为疑似误报
    """
    raid = {}

    # ── 先解析 /proc/mdstat 作为交叉验证基准 ──
    mdstat_info = {}
    try:
        if os.path.exists('/proc/mdstat'):
            with open('/proc/mdstat') as f:
                mdstat_raw = f.read()
            # 按 md 设备分段解析
            for block in re.split(r'\n\s*\n', mdstat_raw):
                m = re.match(r'(md\d+)\s*:\s*', block)
                if not m:
                    continue
                md_name = m.group(1)
                # 提取状态：active raid1 / active raid5 / inactive / etc.
                state_m = re.search(r'(active|inactive|clean)(?:\s+\((\w+)\))?', block)
                mdstat_info[md_name] = {
                    'kernel_state': state_m.group(0) if state_m else 'unknown',
                    'degraded': 'degraded' in block.lower(),
                    'recovery': 'recovery' in block.lower() or 'resync' in block.lower(),
                }
                # 提取设备模式，如 [UUUU] [U_U_] [UU__]
                dev_m = re.search(r'\[([U_]+)\]', block)
                if dev_m:
                    up_count = dev_m.group(1).count('U')
                    total_count = len(dev_m.group(1))
                    mdstat_info[md_name]['devices_up'] = up_count
                    mdstat_info[md_name]['devices_total'] = total_count
    except Exception:
        pass

    try:
        # 尝试常见的 md 设备：md0, md1, md2 ...
        for md_num in range(0, 16):
            md_dev = f'/dev/md{md_num}'
            if not os.path.exists(md_dev):
                continue
            output = _run_safe(['mdadm', '--detail', md_dev])
            if not output:
                continue
            info = {'device': md_dev}
            # 解析关键信息
            m = re.search(r'Array Size\s*:\s*(\d+)', output)
            if m:
                info['size_kb'] = int(m.group(1))
            m = re.search(r'Raid Level\s*:\s*(\S+)', output)
            if m:
                info['level'] = m.group(1)
            m = re.search(r'State\s*:\s*(.+)', output)
            if m:
                info['state'] = m.group(1).strip()
            m = re.search(r'Active Devices\s*:\s*(\d+)', output)
            if m:
                info['active'] = int(m.group(1))
            m = re.search(r'Working Devices\s*:\s*(\d+)', output)
            if m:
                info['working'] = int(m.group(1))
            m = re.search(r'Failed Devices\s*:\s*(\d+)', output)
            if m:
                info['failed'] = int(m.group(1))
            m = re.search(r'Spare Devices\s*:\s*(\d+)', output)
            if m:
                info['spare'] = int(m.group(1))

            # ── DSM 系统盘 md0/md1 特殊处理 ──
            # DSM 的 md0 (系统分区) 和 md1 (swap分区) 配置了热备盘，
            # 状态永远显示 "clean, degraded" 但 failed=0 / active==working，
            # 这是 DSM 正常设计，不是真正的降级。
            md_key = f'md{md_num}'
            state_lower = info.get('state', '').lower()
            is_degraded = 'degraded' in state_lower
            has_no_failures = info.get('failed', 0) == 0
            is_dsm_system = IS_DSM and (md_num == 0 or md_num == 1)
            all_working = info.get('active', 0) == info.get('working', 0)
            if is_dsm_system and is_degraded and has_no_failures and all_working:
                info['state'] = 'clean (DSM系统盘正常)'

            # ── 交叉验证：degraded + failed=0 时检查 mdstat ──
            elif is_degraded and has_no_failures and mdstat_info.get(md_key):
                ms = mdstat_info[md_key]
                if not ms.get('degraded'):
                    # mdadm 报告 degraded 但 mdstat 不认为 degraded，疑似误报
                    info['state'] = info.get('state', '') + ' [mdstat:clean,疑误报]'
                elif ms.get('devices_up', 0) < ms.get('devices_total', 0):
                    # mdstat 确认降级（如 [U_U_]），标记为真实降级
                    info['state'] = info.get('state', '') + ' [mdstat确认降级]'

            # 解析各磁盘状态
            disks = []
            # 匹配 "   N   /dev/sataX  ..." 行
            for line in output.splitlines():
                dm = re.match(r'\s+(\d+)\s+(\S+)\s+(\S+)\s+(\S+)', line)
                if dm:
                    disks.append({
                        'number': int(dm.group(1)),
                        'device': dm.group(2),
                        'state': dm.group(4),
                    })
            info['disks'] = disks
            raid[f'md{md_num}'] = info
    except Exception as e:
        logger.warning(f'RAID信息采集失败: {e}')
    return raid


# ══════════════════════════════════════════
# NTP 时间同步（上报前对时，确保时间准确一致）
# ══════════════════════════════════════════

_NTP_SYNCED = False          # 本进程生命周期内仅同步一次
_NTP_MIN_INTERVAL = 600      # 两次同步最小间隔（秒）
_NTP_LAST_SYNC = 0

def _sync_ntp():
    """通过 NTP 同步系统时间（尽力而为，失败不阻塞采集）。

    按优先级尝试：chronyd makestep → ntpdate → timedatectl
    同一进程内最多每 10 分钟执行一次，避免频繁同步。
    """
    global _NTP_SYNCED, _NTP_LAST_SYNC
    now = time.time()
    if _NTP_SYNCED or (now - _NTP_LAST_SYNC) < _NTP_MIN_INTERVAL:
        return

    _NTP_LAST_SYNC = now
    methods = []

    # 方法1：chronyd 一步对时（需 chronyd 正在运行且有 makestep 权限）
    if os.path.exists('/usr/bin/chronyc') or os.path.exists('/usr/sbin/chronyc') \
       or os.path.exists('/bin/chronyc'):
        methods.append(['chronyc', '-a', 'makestep'])
        # 备选：直接 ntpdate 风格的 chronyd -q
        if os.path.exists('/usr/sbin/chronyd'):
            methods.append(['chronyd', '-q', '-t', '3'])

    # 方法2：ntpdate（部分旧系统 / DSM 可用）
    ntp_servers = ['ntp.aliyun.com', 'ntp.ntsc.ac.cn', 'pool.ntp.org']
    for srv in ntp_servers:
        methods.append(['ntpdate', '-s', srv])

    # 方法3：systemd timedatectl
    if os.path.exists('/usr/bin/timedatectl') or os.path.exists('/bin/timedatectl'):
        methods.append(['timedatectl', 'set-ntp', 'true'])

    for cmd_list in methods:
        try:
            bin_path = None
            for p in ['/usr/sbin', '/usr/bin', '/sbin', '/bin']:
                candidate = os.path.join(p, cmd_list[0])
                if os.path.exists(candidate):
                    bin_path = candidate
                    break
            if not bin_path:
                continue
            actual_cmd = [bin_path] + cmd_list[1:]
            ret = subprocess.run(actual_cmd, shell=False,
                                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                                timeout=8)
            if ret.returncode == 0:
                logger.info(f'NTP 时间同步成功: {" ".join(cmd_list)}')
                _NTP_SYNCED = True
                return
        except Exception:
            continue

    logger.debug('NTP 时间同步：无可用的 NTP 工具或全部失败（不影响采集）')


def collect_and_report(cfg, mode='full'):
    """
    采集系统数据并上报
    mode: 'full'   - 完整数据上报（每3小时）
          'alert'  - 仅告警数据上报（实时）
          'heartbeat' - 仅心跳（每5分钟）
    """
    # 清理超过24小时的过期缓存（同时限制缓存文件总数，防止堆积）
    try:
        cache_dir = Path(CACHE_DIR)
        if cache_dir.exists():
            for cf in cache_dir.glob('pending_*.json'):
                if time.time() - cf.stat().st_mtime > 86400:
                    try:
                        cf.unlink()
                    except Exception:
                        pass
            # 超出最大缓存数量时，删除最旧的文件
            pending_files = sorted(cache_dir.glob('pending_*.json'), key=lambda f: f.stat().st_mtime)
            while len(pending_files) > MAX_PENDING_CACHE:
                try:
                    pending_files[0].unlink()
                    logger.info(f'缓存文件数量超限({MAX_PENDING_CACHE})，删除最旧: {pending_files[0]}')
                    pending_files.pop(0)
                except Exception:
                    break
    except Exception:
        pass

    server_url = cfg.get('SERVER_URL', 'http://127.0.0.1:8080').rstrip('/')
    node_id    = cfg.get('NODE_ID', get_hostname())
    node_name  = cfg.get('NODE_NAME', get_hostname())  # 部署时用户填写的节点名称

    # 上报前 NTP 对时（确保采集时间准确，同一进程内仅首次执行）
    _sync_ntp()

    # 所有模式均尝试重传之前缓存的失败数据
    retry_cached_reports(server_url, node_id)

    if mode == 'heartbeat':
        # 心跳上报：仅更新在线状态
        data = {
            'node_id': node_id,
            'node_name': node_name,
            'hostname': get_hostname(),
            'ip': get_ip(),
        }
        return http_post(f'{server_url}/api/report/heartbeat', data, node_id)

    if mode == 'alert':
        # 告警模式：只采集安全相关信息
        logger.info('开始采集安全告警数据...')
        security_events = []
        security_events.extend(check_file_changes())
        security_events.extend(check_intrusion())
        security_events.extend(check_firewall())
        _, login_events = get_login_records(cfg)
        security_events.extend(login_events)

        if not security_events:
            logger.info('无安全告警事件')
            return True

        alerts = []
        for ev in security_events:
            alerts.append({
                'type': ev['type'],
                'severity': ev.get('severity', 'warning'),
                'title': ev.get('title', ''),
                'message': ev.get('title', ''),
                'detail': ev.get('detail', {}),
            })

        data = {
            'node_id': node_id,
            'node_name': node_name,
            'hostname': get_hostname(),
            'collected_at': datetime.now(timezone.utc).isoformat(),
            'agent_version': __version__,
            'security_events': security_events,
            'alerts': alerts,
        }
        return http_post(f'{server_url}/api/report/alert', data, node_id)

    # ─── 完整数据采集模式 ───
    logger.info('开始采集完整系统信息...')
    start_time = time.time()

    # 并行采集（I/O密集型任务使用线程池并行化）
    # 注意：已有个别函数内部使用ThreadPoolExecutor（磁盘温度、SMART）
    # 这里对剩余的串行采集任务进行并行化
    # CPU 采样策略：在所有重操作（ps aux等）之前取第一次样本，完成后再取第二次，
    # 这样测量窗口覆盖整个采集期（通常10+秒），ps aux 等瞬时峰值被充分稀释
    def _collect_all():
        """并行采集所有系统信息"""
        results = {}
        def safe_call(fn, *args, **kwargs):
            """安全调用采集函数，捕获异常返回空值"""
            try:
                return fn(*args, **kwargs)
            except Exception as e:
                logger.warning(f'{fn.__name__} 采集失败: {e}')
                return None

        # ── CPU 第一次采样（在所有重操作之前）──
        cpu_stat_before = _read_cpu_stat_raw()

        # ── 并行执行除 CPU 和进程信息外的采集任务 ──
        # 注意：get_process_info 调用 ps aux 会瞬间飙高 CPU，必须在 CPU 采样窗口之外执行
        with concurrent.futures.ThreadPoolExecutor(max_workers=8) as executor:
            future_to_key = {
                executor.submit(safe_call, get_cpu_info): 'cpu_info',
                executor.submit(safe_call, get_memory_info): 'mem_info',
                executor.submit(safe_call, get_disk_info): 'disk_info',
                executor.submit(safe_call, get_cpu_temperature): 'cpu_temp',
                executor.submit(safe_call, get_network_info): 'net_info',
                executor.submit(safe_call, get_system_logs): 'sys_logs',
                # get_process_info 不在此处并行执行，避免 ps aux 干扰 CPU 采样
                executor.submit(safe_call, get_smart_info): 'smart_info',
                executor.submit(safe_call, get_asset_info): 'asset_info',
            }
            for future in concurrent.futures.as_completed(future_to_key):
                key = future_to_key[future]
                try:
                    results[key] = future.result(timeout=60)
                except concurrent.futures.TimeoutError:
                    logger.warning(f'{key} 采集超时')
                    results[key] = None
                except Exception as e:
                    logger.warning(f'{key} 采集异常: {e}')
                    results[key] = None

        # ── CPU 第二次采样（等所有重操作完成后再取）──
        cpu_stat_after = _read_cpu_stat_raw()

        # 计算真实 CPU 使用率（窗口为整个采集期，不受 ps aux 等瞬时峰值干扰）
        cpu_usage, cpu_cores = _compute_cpu_from_stats(cpu_stat_before, cpu_stat_after)
        # 将计算结果合并到 cpu_info 中
        if results.get('cpu_info'):
            results['cpu_info']['cpu_usage'] = cpu_usage
            results['cpu_info']['cpu_cores'] = cpu_cores
        else:
            results['cpu_info'] = {'cpu_usage': cpu_usage, 'cpu_cores': cpu_cores}

        # ── 进程信息采集（ps aux 必须在 CPU 采样之后执行）──
        results['proc_info'] = safe_call(get_process_info)

        # 单独采集（依赖其他结果或不适用并行）
        disk_temps = safe_call(get_disk_temperatures)
        login_records, login_events = safe_call(get_login_records, cfg) or ([], [])
        listening_ports = safe_call(get_listening_ports)
        # DSM专用：RAID信息采集
        raid_info = safe_call(get_raid_info) if IS_DSM else {}
        return results, disk_temps, login_records, login_events, listening_ports, raid_info

    results, disk_temps, login_records, login_events, listening_ports, raid_info = _collect_all()
    cpu_info = results.get('cpu_info') or {}
    mem_info = results.get('mem_info') or {}
    disk_info = results.get('disk_info') or []
    cpu_temp = results.get('cpu_temp')
    net_info = results.get('net_info') or {}
    sys_logs = results.get('sys_logs') or []
    proc_info = results.get('proc_info') or {}
    smart_info = results.get('smart_info') or []
    asset_info = results.get('asset_info') or {}

    # 安全检测
    security_events = []
    security_events.extend(check_file_changes())
    security_events.extend(check_intrusion())
    security_events.extend(check_firewall())
    security_events.extend(login_events)

    # 组装上报数据
    sysinfo = {
        **cpu_info,
        **mem_info,
        'disk_info': disk_info,
        'cpu_temp': cpu_temp,
        'disk_temps': disk_temps,
        'net_info': net_info,
        'uptime': get_uptime(),
    }

    data = {
        'node_id': node_id,
        'node_name': node_name,
        'hostname': get_hostname(),
        'ip': get_ip(),
        'os_info': get_os_info(),
        'system_type': SYSTEM_TYPE,
        'collected_at': datetime.now(timezone.utc).isoformat(),
        'sysinfo': sysinfo,
        'processes': proc_info,
        'smart': smart_info,
        'login_records': login_records,
        'sys_logs': sys_logs,
        'security_events': security_events,
        'assets': asset_info,
        'listening_ports': listening_ports,
        'raid_info': raid_info,
        'agent_version': __version__,
        'alerts': [
            {'type': ev['type'], 'severity': ev.get('severity', 'warning'),
             'title': ev.get('title', ''), 'message': ev.get('title', ''),
             'detail': ev.get('detail', {})}
            for ev in security_events
        ],
    }

    elapsed = time.time() - start_time
    logger.info(f'数据采集完成，耗时 {elapsed:.1f}秒，开始上报...')

    if elapsed > 120:
        logger.warning(f'采集耗时超过120秒: {elapsed:.1f}秒')

    # 总执行时间保护：超时则跳过本次上报，避免长时间占用系统资源
    if elapsed > MAX_WALL_TIME:
        logger.error(f'采集总耗时超过上限 {MAX_WALL_TIME}s，跳过本次上报以保护节点')
        return False

    return http_post(f'{server_url}/api/report/metrics', data, node_id)


# ══════════════════════════════════════════
# 工具函数
# ══════════════════════════════════════════

def _run(cmd_list, timeout=30):
    """安全执行命令（shell=False，无注入风险）。

    参数:
        cmd_list: 命令及参数列表，如 ['df', '-h']
        timeout: 超时秒数
    返回:
        stdout 字符串（成功时），空字符串（失败时）
    """
    if not cmd_list:
        return ''
    if isinstance(cmd_list, str):
        cmd_list = [cmd_list]

    # 自动查找系统工具的绝对路径（处理 PATH 不含 /usr/sbin 的情况）
    _cmd = cmd_list[0]
    if not os.path.isabs(_cmd):
        for sbin in ['/usr/sbin', '/sbin', '/usr/local/sbin']:
            candidate = os.path.join(sbin, _cmd)
            if os.path.isfile(candidate) and os.access(candidate, os.X_OK):
                cmd_list = [candidate] + list(cmd_list[1:])
                break

    try:
        # 同时也扩展 PATH 环境变量作为兜底
        env = os.environ.copy()
        extra_paths = ['/usr/sbin', '/sbin', '/usr/local/sbin']
        existing = env.get('PATH', '').split(':')
        for p in extra_paths:
            if p not in existing:
                existing.append(p)
        env['PATH'] = ':'.join(existing)

        result = subprocess.run(
            cmd_list, shell=False, capture_output=True, text=True, timeout=timeout, env=env
        )
        if result.returncode != 0:
            return ''
        stdout = result.stdout
        if len(stdout.encode('utf-8', errors='replace')) > MAX_CAPTURE_BYTES:
            logger.warning(f'命令输出超过 {MAX_CAPTURE_BYTES} bytes，截断: {cmd_list[0]}')
            stdout = stdout[:MAX_CAPTURE_BYTES]
        return stdout.strip()
    except (subprocess.TimeoutExpired, FileNotFoundError, OSError) as e:
        logger.warning(f'命令执行失败: {cmd_list[0]} - {e}')
        return ''
    except Exception:
        return ''


# _run_safe 已合并到 _run()（现在 _run 默认 shell=False），保留别名以兼容
_run_safe = _run


def _is_float(s):
    """判断字符串是否可转为浮点数"""
    try:
        float(s)
        return True
    except Exception:
        return False


# ══════════════════════════════════════════
# 命令行入口
# ══════════════════════════════════════════

if __name__ == '__main__':
    try:
        parser = argparse.ArgumentParser(description='运维监控系统 Agent')
        parser.add_argument('--mode', choices=['full', 'alert', 'heartbeat'],
                            default='full', help='上报模式: full=完整 alert=告警 heartbeat=心跳')
        parser.add_argument('--config', default=CONFIG_FILE, help='配置文件路径')
        args = parser.parse_args()

        # 若传入了自定义 --config，同步更新全局路径变量
        CONFIG_FILE = args.config
        _conf_dir = os.path.dirname(os.path.abspath(CONFIG_FILE))
        CACHE_DIR = os.path.join(_conf_dir, '.cache')
        LOG_FILE  = os.path.join(_conf_dir, 'agent.log')
        TOKEN_FILE = os.path.join(CACHE_DIR, '.node_token')
        FILE_HASH_CACHE = os.path.join(CACHE_DIR, 'file_hashes.json')
        LOGIN_HISTORY_CACHE = os.path.join(CACHE_DIR, 'login_history.json')

        os.makedirs(CACHE_DIR, exist_ok=True, mode=0o700)

        # 重新配置日志到正确路径（使用RotatingFileHandler防止日志撑满磁盘）
        for h in logging.root.handlers[:]:
            logging.root.removeHandler(h)
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s [%(levelname)s] %(message)s',
            handlers=[
                logging.StreamHandler(),
                RotatingFileHandler(LOG_FILE, encoding='utf-8',
                                    maxBytes=LOG_MAX_BYTES, backupCount=LOG_BACKUP_COUNT),
            ]
        )

        cfg = load_config()
        logger.info(f'Agent启动，节点ID: {cfg.get("NODE_ID", get_hostname())}，模式: {args.mode}')

        # 设置硬性 wall-clock 超时保护（SIGALRM），防止采集卡死影响节点
        signal.alarm(MAX_WALL_TIME)
        ok = collect_and_report(cfg, mode=args.mode)
        signal.alarm(0)  # 采集完成，取消 alarm
        sys.exit(0 if ok else 1)
    except Exception as e:
        try:
            logger.error(f'Agent 异常退出: {e}', exc_info=True)
        except Exception:
            import sys, traceback
            sys.stderr.write(f'Agent 异常退出: {e}\n')
            traceback.print_exc(file=sys.stderr)
        sys.exit(1)
