#!/bin/bash
# ================================================================
# 运维监控系统 - Agent 重新上报脚本
# 用法：
#   bash re-report.sh              # 完整上报（默认）
#   bash re-report.sh full         # 完整上报
#   bash re-report.sh alert        # 仅安全告警上报
#   bash re-report.sh heartbeat    # 仅心跳上报
# ================================================================

AGENT_DIR="$(cd "$(dirname "$0")" && pwd)"
AGENT_PY="${AGENT_DIR}/agent.py"
CONF="${AGENT_DIR}/agent.conf"

# 查找 Python3（优先 venv，其次系统）
PYTHON=""
for candidate in \
    "${AGENT_DIR}/../venv/bin/python3" \
    "${AGENT_DIR}/../venv/bin/python" \
    /usr/local/bin/python3.11 \
    /usr/local/bin/python3 \
    /usr/bin/python3.11 \
    /usr/bin/python3 \
    python3; do
    if command -v "$candidate" &>/dev/null; then
        PYTHON="$candidate"
        break
    fi
done

if [ -z "$PYTHON" ]; then
    echo "[ERROR] 未找到 Python3，请确认已安装 Python 3.8+"
    exit 1
fi

if [ ! -f "$AGENT_PY" ]; then
    echo "[ERROR] 未找到 agent.py: ${AGENT_PY}"
    exit 1
fi

if [ ! -f "$CONF" ]; then
    echo "[ERROR] 未找到配置文件: ${CONF}"
    echo "请确认已运行 deploy.sh agent 完成部署"
    exit 1
fi

MODE="${1:-full}"
case "$MODE" in
    full|alert|heartbeat) ;;
    *)
        echo "用法: bash re-report.sh [full|alert|heartbeat]"
        echo "  full      - 完整数据采集与上报（默认）"
        echo "  alert     - 仅安全告警检测与上报"
        echo "  heartbeat - 仅心跳上报"
        exit 1
        ;;
esac

echo "========================================"
echo "  运维监控系统 - Agent 重新上报"
echo "========================================"
echo "  节点ID: $(grep '^NODE_ID=' "$CONF" 2>/dev/null | cut -d= -f2)"
echo "  服务端: $(grep '^SERVER_URL=' "$CONF" 2>/dev/null | cut -d= -f2)"
echo "  模式:   $MODE"
echo "  Python: $PYTHON"
echo "========================================"

cd "$AGENT_DIR"
"$PYTHON" "$AGENT_PY" --mode "$MODE" --config "$CONF"

EXIT_CODE=$?
if [ $EXIT_CODE -eq 0 ]; then
    echo ""
    echo "[OK] 上报完成"
else
    echo ""
    echo "[ERROR] 上报失败（退出码: $EXIT_CODE），请查看 ${AGENT_DIR}/agent.log"
fi

exit $EXIT_CODE
