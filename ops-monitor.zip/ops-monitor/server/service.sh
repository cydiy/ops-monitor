#!/bin/bash
# ================================================================
# 运维监控系统 - Server 服务管理脚本
# 用法: bash service.sh {start|stop|restart|status|uninstall}
#
# 管理对象: ops-monitor-web (systemd 服务)
# 支持环境: Debian / CentOS / Rocky 等有 systemd 的 Linux 发行版
# ================================================================
set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m'

info()    { echo -e "${CYAN}[INFO]${NC}  $1"; }
success() { echo -e "${GREEN}[OK]${NC}    $1"; }
warn()    { echo -e "${YELLOW}[WARN]${NC}  $1"; }
error()   { echo -e "${RED}[ERROR]${NC} $1"; exit 1; }

# ─────────── 路径检测 ───────────
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# server/service.sh → 上级是部署根目录
DEPLOY_DIR="$(dirname "${SCRIPT_DIR}")"
SERVER_DIR="${SCRIPT_DIR}"
LOG_DIR="/var/log/ops-monitor"
SVC_NAME="ops-monitor-web"
UNIT_FILE="/etc/systemd/system/${SVC_NAME}.service"

# ─────────── 检查 systemd ───────────
_require_systemd() {
    if ! command -v systemctl &>/dev/null; then
        error "此脚本需要 systemd，当前系统不支持。请手动管理服务。"
    fi
}

# ─────────── 状态 ───────────
cmd_status() {
    echo ""
    echo -e "${CYAN}═══ Server 状态 ═══${NC}"

    # systemd 服务状态
    if systemctl list-unit-files 2>/dev/null | grep -q "${SVC_NAME}.service"; then
        if systemctl is-active --quiet "$SVC_NAME" 2>/dev/null; then
            echo -e "  ${GREEN}●${NC} ${SVC_NAME}  - 运行中"
        else
            echo -e "  ${RED}●${NC} ${SVC_NAME}  - 已停止"
        fi

        if systemctl is-enabled --quiet "$SVC_NAME" 2>/dev/null; then
            echo -e "  ${GREEN}●${NC} 开机自启        - 已启用"
        else
            echo -e "  ${YELLOW}○${NC} 开机自启        - 未启用"
        fi
    else
        echo -e "  ${YELLOW}○${NC} ${SVC_NAME}  - 未安装（systemd 服务不存在）"
    fi

    # 部署文件
    echo ""
    echo -e "${CYAN}  文件路径：${NC}"
    for f in "${SERVER_DIR}/main.py" "${SERVER_DIR}/app.py" "${DEPLOY_DIR}/data/monitor.db"; do
        if [ -f "$f" ]; then
            echo -e "  ${GREEN}●${NC} $f"
        else
            echo -e "  ${YELLOW}○${NC} $f  (不存在)"
        fi
    done

    # 端口监听
    echo ""
    echo -e "${CYAN}  监听端口：${NC}"
    if command -v ss &>/dev/null; then
        ss -tunlp 2>/dev/null | grep -E 'LISTEN.*python|LISTEN.*ops' | sed 's/^/    /' || \
            echo "    （无监听端口或 ss 无权限）"
    elif command -v netstat &>/dev/null; then
        netstat -tunlp 2>/dev/null | grep -E 'LISTEN.*python|LISTEN.*ops' | sed 's/^/    /' || \
            echo "    （无监听端口）"
    fi

    # 最近日志
    local LOG_FILE="${LOG_DIR}/web.log"
    if [ -f "$LOG_FILE" ]; then
        echo ""
        echo -e "${CYAN}  最近日志（${LOG_FILE}）：${NC}"
        tail -15 "$LOG_FILE" | sed 's/^/    /'
    fi
    echo ""
}

# ─────────── 启动 ───────────
cmd_start() {
    _require_systemd
    if ! systemctl list-unit-files 2>/dev/null | grep -q "${SVC_NAME}.service"; then
        error "服务未安装，请先运行 deploy.sh 部署服务端"
    fi
    info "启动 ${SVC_NAME}..."
    systemctl start "$SVC_NAME" && \
        success "${SVC_NAME} 已启动" || \
        error "启动失败，查看日志: journalctl -u ${SVC_NAME} -n 50"
}

# ─────────── 停止 ───────────
cmd_stop() {
    _require_systemd
    info "停止 ${SVC_NAME}..."
    systemctl stop "$SVC_NAME" 2>/dev/null && \
        success "${SVC_NAME} 已停止" || warn "${SVC_NAME} 停止失败（可能未运行）"
}

# ─────────── 重启 ───────────
cmd_restart() {
    _require_systemd
    info "重启 ${SVC_NAME}..."
    systemctl restart "$SVC_NAME" && \
        success "${SVC_NAME} 已重启" || \
        error "重启失败，查看日志: journalctl -u ${SVC_NAME} -n 50"
}

# ─────────── 启用/禁用开机自启 ───────────
cmd_enable() {
    _require_systemd
    systemctl enable "$SVC_NAME" && success "开机自启已启用" || warn "启用失败"
}

cmd_disable() {
    _require_systemd
    systemctl disable "$SVC_NAME" && success "开机自启已禁用" || warn "禁用失败"
}

# ─────────── 查看实时日志 ───────────
cmd_log() {
    if command -v journalctl &>/dev/null; then
        info "实时日志（Ctrl+C 退出）..."
        journalctl -u "$SVC_NAME" -f --no-pager
    elif [ -f "${LOG_DIR}/web.log" ]; then
        tail -f "${LOG_DIR}/web.log"
    else
        warn "无法找到日志文件"
    fi
}

# ─────────── 卸载 ───────────
cmd_uninstall() {
    echo ""
    echo -e "${RED}⚠  即将卸载 Server，此操作将：${NC}"
    echo "   1. 停止并禁用 ${SVC_NAME} 服务"
    echo "   2. 删除 systemd 单元文件"
    echo "   3. 删除部署目录: ${DEPLOY_DIR}"
    echo "   4. 删除日志目录: ${LOG_DIR}"
    echo ""
    echo -e "${YELLOW}  数据库文件(monitor.db)也会被删除，请提前备份！${NC}"
    echo ""
    printf "确认卸载？(输入 yes 继续): "
    read -r CONFIRM
    [ "$CONFIRM" != "yes" ] && { info "已取消"; exit 0; }

    # 停止并禁用服务
    if command -v systemctl &>/dev/null; then
        systemctl stop "$SVC_NAME" 2>/dev/null || true
        systemctl disable "$SVC_NAME" 2>/dev/null || true
        systemctl daemon-reload 2>/dev/null || true
    fi

    # 删除 unit 文件
    rm -f "$UNIT_FILE" 2>/dev/null || true

    # 删除部署目录（保留备份提示）
    if [ -d "$DEPLOY_DIR" ]; then
        info "备份数据库到 /tmp/ops-monitor-db-backup.db..."
        cp "${DEPLOY_DIR}/data/monitor.db" "/tmp/ops-monitor-db-backup.db" 2>/dev/null || true
        rm -rf "$DEPLOY_DIR"
    fi

    # 删除日志目录
    rm -rf "$LOG_DIR" 2>/dev/null || true

    success "Server 已完全卸载"
    warn "数据库备份位置: /tmp/ops-monitor-db-backup.db"
}

# ─────────── 帮助 ───────────
cmd_help() {
    echo ""
    echo -e "${CYAN}用法: bash $(basename "$0") {start|stop|restart|status|enable|disable|log|uninstall}${NC}"
    echo ""
    echo "  start     启动 Web 服务"
    echo "  stop      停止 Web 服务"
    echo "  restart   重启 Web 服务"
    echo "  status    查看服务状态、监听端口及最近日志"
    echo "  enable    启用开机自启"
    echo "  disable   禁用开机自启"
    echo "  log       实时查看服务日志（journalctl -f）"
    echo "  uninstall 完全卸载（停服 + 删文件 + 删数据库）"
    echo ""
}

# ─────────── 主入口 ───────────
COMMAND="${1:-status}"
case "$COMMAND" in
    start)     cmd_start     ;;
    stop)      cmd_stop      ;;
    restart)   cmd_restart   ;;
    status)    cmd_status    ;;
    enable)    cmd_enable    ;;
    disable)   cmd_disable   ;;
    log)       cmd_log       ;;
    uninstall) cmd_uninstall ;;
    *)         cmd_help      ;;
esac
