"""
加密工具模块
使用 Fernet 对称加密保护敏感配置项（如 SMTP 密码）。
密钥从应用 SECRET_KEY 派生，不额外存储密钥文件。
"""
import base64
import hashlib
from cryptography.fernet import Fernet


def _derive_key(secret_key: str) -> bytes:
    """从 SECRET_KEY 派生出 Fernet 所需的 32 字节 URL-safe base64 密钥"""
    # 使用 SHA-256 将任意长度的密钥固定为 32 字节
    digest = hashlib.sha256(secret_key.encode('utf-8')).digest()
    return base64.urlsafe_b64encode(digest)


def encrypt_value(plaintext: str, secret_key: str) -> str:
    """加密明文字符串，返回 base64 密文字符串"""
    if not plaintext:
        return ''
    key = _derive_key(secret_key)
    f = Fernet(key)
    return f.encrypt(plaintext.encode('utf-8')).decode('utf-8')


def decrypt_value(ciphertext: str, secret_key: str) -> str:
    """解密 base64 密文字符串，返回明文"""
    if not ciphertext:
        return ''
    try:
        key = _derive_key(secret_key)
        f = Fernet(key)
        return f.decrypt(ciphertext.encode('utf-8')).decode('utf-8')
    except Exception:
        # 如果解密失败（可能是旧版明文数据），返回原值
        return ciphertext
