"""
告警服务
负责：
1. 定期扫描未发送的告警并发送邮件
2. 告警阈值检查（CPU/内存/磁盘/温度）
3. 告警抑制（相同类型一定时间内不重复发送）
4. SMTP邮件发送
"""
import json
import time
import smtplib
import logging
from datetime import datetime, timedelta, timezone as _tz
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from html import escape as html_escape
from database import db, Node, MetricsSnapshot, AlertRecord, SystemConfig, SmartRecord, ProcessRecord

logger = logging.getLogger('alert-service')

# SMTP未配置警告抑制（避免每30秒刷屏日志）
_last_smtp_warn_time = 0
_SMTP_WARN_INTERVAL = 3600  # 每小时最多警告一次


def _fmt_local_time(naive_utc_dt):
    """将数据库 naive UTC datetime 转为服务器本地时间字符串（Asia/Shanghai）"""
    if not naive_utc_dt:
        return '-'
    try:
        from datetime import timezone as _tz, timedelta as _td
        # 将 naive UTC 附加 UTC 时区，再转为本地时区
        utc_dt = naive_utc_dt.replace(tzinfo=_tz.utc)
        # 尝试使用 zoneinfo（Python 3.9+），否则用固定偏移
        try:
            from zoneinfo import ZoneInfo
            local_dt = utc_dt.astimezone(ZoneInfo('Asia/Shanghai'))
        except Exception:
            local_dt = utc_dt.astimezone(_tz(_td(hours=8)))
        return local_dt.strftime('%Y-%m-%d %H:%M:%S')
    except Exception:
        return naive_utc_dt.strftime('%Y-%m-%d %H:%M:%S')


# ─────────────────────────────────────────
# 加密工具（延迟导入，避免循环依赖）
# ─────────────────────────────────────────

def _decrypt_smtp_pass(ciphertext, app):
    """解密 SMTP 密码，解密失败时返回原值（兼容旧版明文）"""
    if not ciphertext or ciphertext == '******':
        return ciphertext
    try:
        from crypto_utils import decrypt_value
        return decrypt_value(ciphertext, app.secret_key)
    except Exception:
        return ciphertext


# ─────────────────────────────────────────
# SMTP邮件发送
# ─────────────────────────────────────────

def test_smtp_config(host, port, user, password, ssl, to):
    """测试SMTP连接并发送测试邮件"""
    try:
        msg = MIMEText('这是一封来自运维监控系统的测试邮件，SMTP配置正常。', 'plain', 'utf-8')
        msg['Subject'] = '【运维监控】SMTP配置测试'
        msg['From'] = user
        msg['To'] = to or user
        _send_email(host, port, user, password, ssl, [to or user], msg)
        return True, '发送成功，请检查邮箱'
    except Exception as e:
        return False, f'发送失败: {str(e)}'


def _send_email(host, port, user, password, ssl, recipients, msg):
    """底层发送邮件"""
    server = None
    try:
        if ssl:
            server = smtplib.SMTP_SSL(host, port, timeout=15)
        else:
            server = smtplib.SMTP(host, port, timeout=15)
            server.starttls()
        server.login(user, password)
        server.sendmail(user, recipients, msg.as_string())
    finally:
        if server:
            try:
                server.quit()
            except Exception:
                pass


def send_alert_email(app, alert: AlertRecord, node: Node):
    """发送告警邮件"""
    smtp_host = _get_cfg(app, 'smtp_host', '')
    smtp_port = int(_get_cfg(app, 'smtp_port', '465'))
    smtp_user = _get_cfg(app, 'smtp_user', '')
    smtp_pass = _decrypt_smtp_pass(_get_cfg(app, 'smtp_pass', ''), app)
    smtp_ssl = _get_cfg(app, 'smtp_ssl', 'true').lower() == 'true'
    recipients_str = _get_cfg(app, 'alert_recipients', '[]')
    try:
        recipients = json.loads(recipients_str)
    except Exception:
        recipients = [smtp_user] if smtp_user else []

    if not smtp_host or not smtp_user or not recipients:
        global _last_smtp_warn_time
        now_ts = time.time()
        if now_ts - _last_smtp_warn_time > _SMTP_WARN_INTERVAL:
            logger.warning(f'SMTP未配置或收件人为空，跳过告警邮件发送（后续同样警告将抑制{_SMTP_WARN_INTERVAL}秒）')
            _last_smtp_warn_time = now_ts
        return False

    # 告警级别颜色
    color = '#f56c6c' if alert.severity == 'critical' else '#e6a23c'
    level_text = '严重' if alert.severity == 'critical' else '警告'

    # HTML邮件模板
    html_body = f"""
<!DOCTYPE html>
<html>
<head><meta charset="utf-8"><title>运维告警</title></head>
<body style="font-family:Arial,sans-serif;background:#f5f5f5;padding:20px;">
  <div style="max-width:600px;margin:0 auto;background:#fff;border-radius:8px;overflow:hidden;box-shadow:0 2px 8px rgba(0,0,0,0.1);">
    <div style="background:{color};padding:16px 24px;color:#fff;">
      <h2 style="margin:0;">⚠️ 运维监控告警 [{level_text}]</h2>
    </div>
    <div style="padding:24px;">
      <table style="width:100%;border-collapse:collapse;">
        <tr><td style="padding:8px;color:#666;width:120px;">告警标题</td>
            <td style="padding:8px;font-weight:bold;color:#333;">{html_escape(alert.title)}</td></tr>
        <tr style="background:#f9f9f9;"><td style="padding:8px;color:#666;">告警级别</td>
            <td style="padding:8px;color:{color};font-weight:bold;">{level_text}</td></tr>
        <tr><td style="padding:8px;color:#666;">节点名称</td>
            <td style="padding:8px;">{html_escape(node.name) if node else html_escape(alert.node_id)}</td></tr>
        <tr style="background:#f9f9f9;"><td style="padding:8px;color:#666;">节点IP</td>
            <td style="padding:8px;">{html_escape(node.ip) if node else '-'}</td></tr>
        <tr><td style="padding:8px;color:#666;">告警内容</td>
            <td style="padding:8px;">{html_escape(alert.message)}</td></tr>
        <tr style="background:#f9f9f9;"><td style="padding:8px;color:#666;">告警时间</td>
            <td style="padding:8px;">{_fmt_local_time(alert.created_at)}</td></tr>
      </table>
    </div>
    <div style="padding:12px 24px;background:#f9f9f9;color:#999;font-size:12px;text-align:center;">
      本邮件由运维监控系统自动发送，请勿回复
    </div>
  </div>
</body>
</html>
"""
    msg = MIMEMultipart('alternative')
    msg['Subject'] = f'【运维告警-{level_text}】{html_escape(alert.title)}'
    msg['From'] = smtp_user
    msg['To'] = ', '.join(recipients)
    msg.attach(MIMEText(html_body, 'html', 'utf-8'))

    try:
        _send_email(smtp_host, smtp_port, smtp_user, smtp_pass, smtp_ssl, recipients, msg)
        logger.info(f'告警邮件已发送: {alert.title} -> {recipients}')
        return True
    except Exception as e:
        logger.error(f'告警邮件发送失败: {e}')
        return False


# ─────────────────────────────────────────
# 阈值检查
# ─────────────────────────────────────────

def check_thresholds(app, node_id, default_cfgs=None):
    """检查节点最新指标是否超过阈值，超过则创建告警"""
    node = Node.query.filter_by(node_id=node_id).first()
    if not node:
        return
    latest = MetricsSnapshot.query.filter_by(node_id=node_id) \
        .order_by(MetricsSnapshot.collected_at.desc()).first()
    if not latest:
        return

    thresholds = node.get_thresholds()
    if default_cfgs:
        cpu_th = float(thresholds.get('cpu', default_cfgs.get('default_cpu_threshold', '90')))
        mem_th = float(thresholds.get('mem', default_cfgs.get('default_mem_threshold', '90')))
        disk_th = float(thresholds.get('disk', default_cfgs.get('default_disk_threshold', '85')))
        cpu_temp_th = float(thresholds.get('cpu_temp', default_cfgs.get('default_cpu_temp_threshold', '80')))
        disk_temp_th = float(thresholds.get('disk_temp', default_cfgs.get('default_disk_temp_threshold', '55')))
    else:
        cpu_th = float(thresholds.get('cpu', _get_cfg(app, 'default_cpu_threshold', '90')))
        mem_th = float(thresholds.get('mem', _get_cfg(app, 'default_mem_threshold', '90')))
        disk_th = float(thresholds.get('disk', _get_cfg(app, 'default_disk_threshold', '85')))
        cpu_temp_th = float(thresholds.get('cpu_temp', _get_cfg(app, 'default_cpu_temp_threshold', '80')))
        disk_temp_th = float(thresholds.get('disk_temp', _get_cfg(app, 'default_disk_temp_threshold', '55')))

    alerts_to_create = []

    # CPU告警
    if latest.cpu_usage and latest.cpu_usage >= cpu_th:
        alerts_to_create.append({
            'type': 'cpu_high', 'severity': 'warning' if latest.cpu_usage < 95 else 'critical',
            'title': f'CPU使用率过高: {html_escape(node.name)}',
            'message': f'CPU使用率 {latest.cpu_usage:.1f}% 超过阈值 {cpu_th:.0f}%',
        })

    # 内存告警
    if latest.mem_usage and latest.mem_usage >= mem_th:
        alerts_to_create.append({
            'type': 'mem_high', 'severity': 'warning' if latest.mem_usage < 95 else 'critical',
            'title': f'内存使用率过高: {html_escape(node.name)}',
            'message': f'内存使用率 {latest.mem_usage:.1f}% 超过阈值 {mem_th:.0f}%',
        })

    # 磁盘告警
    try:
        disks = json.loads(latest.disk_info or '[]')
        for disk in disks:
            use_pct = disk.get('use_percent', 0)
            if use_pct >= disk_th:
                alerts_to_create.append({
                    'type': 'disk_high', 'severity': 'warning' if use_pct < 95 else 'critical',
                    'title': f'磁盘使用率过高: {html_escape(node.name)} {html_escape(disk.get("mount", ""))}',
                    'message': f'磁盘分区 {html_escape(disk.get("mount", ""))} 使用率 {use_pct:.1f}% 超过阈值 {disk_th:.0f}%，'
                               f'剩余 {html_escape(disk.get("avail", "?"))}',
                })
    except Exception as e:
        logger.warning(f'磁盘信息JSON解析失败（跳过磁盘告警检测）: {e}')

    # CPU温度告警
    if latest.cpu_temp and latest.cpu_temp >= cpu_temp_th:
        alerts_to_create.append({
            'type': 'cpu_temp_high', 'severity': 'warning' if latest.cpu_temp < 90 else 'critical',
            'title': f'CPU温度过高: {html_escape(node.name)}',
            'message': f'CPU温度 {latest.cpu_temp:.1f}℃ 超过阈值 {cpu_temp_th:.0f}℃',
        })

    # 硬盘温度告警
    try:
        disk_temps = json.loads(latest.disk_temps or '{}')
        for disk_dev, temp in disk_temps.items():
            if isinstance(temp, (int, float)) and temp >= disk_temp_th:
                alerts_to_create.append({
                    'type': 'disk_temp_high', 'severity': 'warning',
                    'title': f'硬盘温度过高: {html_escape(node.name)} {html_escape(disk_dev)}',
                    'message': f'硬盘 {disk_dev} 温度 {temp:.1f}℃ 超过阈值 {disk_temp_th:.0f}℃',
                })
    except Exception as e:
        logger.warning(f'磁盘温度信息解析失败: {e}')

    # ── 硬件故障告警：SMART 磁盘健康状态 FAILED ──
    try:
        latest_smart = SmartRecord.query.filter_by(node_id=node_id) \
            .order_by(SmartRecord.collected_at.desc()).first()
        if latest_smart:
            # 查询该节点最新一批SMART记录（同一次采集可能有多块盘）
            latest_smarts = SmartRecord.query.filter_by(node_id=node_id) \
                .filter(SmartRecord.collected_at == latest_smart.collected_at).all()
            for sm in latest_smarts:
                disk_label = sm.disk_name or 'unknown'
                # 磁盘健康状态 FAILED
                if sm.health_status and sm.health_status.upper() in ('FAILED', 'FAILING'):
                    alerts_to_create.append({
                        'type': 'smart_failed', 'severity': 'critical',
                        'title': f'磁盘SMART故障: {html_escape(node.name)} {html_escape(disk_label)}',
                        'message': f'磁盘 {disk_label} SMART健康状态为 {sm.health_status}，磁盘可能即将或已经损坏',
                    })
                # 坏道检测：重新分配扇区数 > 50（避免单次偶发误报）
                if sm.reallocated_sectors and sm.reallocated_sectors > 50:
                    alerts_to_create.append({
                        'type': 'bad_sector', 'severity': 'warning' if sm.reallocated_sectors < 200 else 'critical',
                        'title': f'磁盘坏道: {html_escape(node.name)} {html_escape(disk_label)}',
                        'message': f'磁盘 {disk_label} 检测到 {sm.reallocated_sectors} 个重新分配扇区（坏道），建议尽快更换',
                    })
                # SSD 磨损告警 (wear_leveling: 0-100, 值越低磨损越严重)
                if sm.wear_leveling is not None:
                    ssd_wear_th = int(default_cfgs.get('default_ssd_wear_threshold', '5') if default_cfgs else '5')
                    if sm.wear_leveling <= ssd_wear_th:
                        alerts_to_create.append({
                            'type': 'ssd_wear', 'severity': 'warning',
                            'title': f'SSD寿命即将耗尽: {html_escape(node.name)} {html_escape(disk_label)}',
                            'message': f'SSD {disk_label} 磨损值仅剩 {sm.wear_leveling}%（阈值 {ssd_wear_th}%），建议尽快更换',
                        })
                # NVMe 备用空间告警
                if sm.nvme_spare is not None:
                    nvme_spare_th = int(default_cfgs.get('default_nvme_spare_threshold', '5') if default_cfgs else '5')
                    if sm.nvme_spare <= nvme_spare_th:
                        alerts_to_create.append({
                            'type': 'nvme_spare_low', 'severity': 'warning' if sm.nvme_spare > 2 else 'critical',
                            'title': f'NVMe备用空间不足: {html_escape(node.name)} {html_escape(disk_label)}',
                            'message': f'NVMe {disk_label} 可用备用空间仅 {sm.nvme_spare}%（阈值 {nvme_spare_th}%），建议检查',
                        })
    except Exception as e:
        logger.warning(f'SMART告警检查失败: {e}')

    # ── 硬件故障告警：RAID 阵列降级/损坏 ──
    try:
        if latest.raid_info:
            raid_data = json.loads(latest.raid_info)
            for md_name, md_info in raid_data.items():
                if isinstance(md_info, dict):
                    state = md_info.get('state', '').lower()
                    failed = md_info.get('failed', 0)
                    active = md_info.get('active', 0)
                    working = md_info.get('working', 0)

                    # 跳过 DSM 系统盘 md0/md1 的假阳性（热备盘导致的状态）
                    is_dsm_system = md_name in ('md0', 'md1')
                    all_working = active > 0 and active == working
                    if is_dsm_system and failed == 0 and all_working and 'degraded' in state:
                        continue

                    if failed > 0:
                        alerts_to_create.append({
                            'type': 'raid_failed', 'severity': 'critical',
                            'title': f'RAID阵列故障盘: {html_escape(node.name)} {md_name}',
                            'message': f'RAID阵列 {md_name} 有 {failed} 块磁盘故障（活跃={active} 正常={working}）',
                        })
                    elif 'degraded' in state:
                        severity = 'critical' if '确认降级' in md_info.get('state', '') else 'warning'
                        alerts_to_create.append({
                            'type': 'raid_degraded', 'severity': severity,
                            'title': f'RAID阵列降级: {html_escape(node.name)} {md_name}',
                            'message': f'RAID阵列 {md_name} 状态异常（活跃={active} 正常={working} 故障={failed}），冗余可能已失效',
                        })
    except Exception as e:
        logger.warning(f'RAID告警检查失败: {e}')

    # ── 进程异常：僵尸进程 ──
    try:
        latest_proc = ProcessRecord.query.filter_by(node_id=node_id) \
            .order_by(ProcessRecord.collected_at.desc()).first()
        if latest_proc:
            zombies = json.loads(latest_proc.zombie_procs or '[]')
            if zombies:
                zombie_names = ', '.join(
                    f"{z.get('name', '?')[:30]}(PID:{z.get('pid', '?')})" for z in zombies[:5]
                )
                alerts_to_create.append({
                    'type': 'zombie_process', 'severity': 'warning',
                    'title': f'检测到僵尸进程: {html_escape(node.name)}',
                    'message': f'发现 {len(zombies)} 个僵尸进程: {zombie_names}',
                })

            # 单进程 CPU 占用过高（>95% 持续）
            cpu_top = json.loads(latest_proc.cpu_top10 or '[]')
            for p in cpu_top[:5]:
                cpu_pct = p.get('cpu_pct', 0)
                if isinstance(cpu_pct, (int, float)) and cpu_pct >= 95:
                    alerts_to_create.append({
                        'type': 'process_cpu_high', 'severity': 'warning',
                        'title': f'进程CPU占用异常: {html_escape(node.name)}',
                        'message': f'进程 {html_escape(p.get("name", "?")[:50])} (PID:{p.get("pid","?")}) '
                                   f'CPU占用率 {cpu_pct:.1f}%，可能异常',
                    })

            # 单进程内存占用过高（>80%）
            mem_top = json.loads(latest_proc.mem_top10 or '[]')
            for p in mem_top[:5]:
                mem_pct = p.get('mem_pct', 0)
                if isinstance(mem_pct, (int, float)) and mem_pct >= 80:
                    alerts_to_create.append({
                        'type': 'process_mem_high', 'severity': 'warning',
                        'title': f'进程内存占用异常: {html_escape(node.name)}',
                        'message': f'进程 {html_escape(p.get("name", "?")[:50])} (PID:{p.get("pid","?")}) '
                                   f'内存占用率 {mem_pct:.1f}%，可能内存泄漏',
                    })
    except Exception as e:
        logger.warning(f'进程告警检查失败: {e}')

    # ── 批量创建告警（带抑制逻辑）──
    suppress_minutes = int(default_cfgs.get('alert_suppress_minutes', '120') if default_cfgs else _get_cfg(app, 'alert_suppress_minutes', '120'))
    suppress_since = datetime.now(_tz.utc).replace(tzinfo=None) - timedelta(minutes=suppress_minutes)

    for alert_info in alerts_to_create:
        # 检查抑制：近N分钟内是否已有相同类型告警
        existing = AlertRecord.query.filter(
            AlertRecord.node_id == node_id,
            AlertRecord.alert_type == alert_info['type'],
            AlertRecord.created_at >= suppress_since,
        ).first()
        if not existing:
            alert = AlertRecord(
                node_id=node_id,
                alert_type=alert_info['type'],
                severity=alert_info['severity'],
                title=alert_info['title'],
                message=alert_info['message'],
            )
            db.session.add(alert)

    db.session.commit()


# ─────────────────────────────────────────
# 主循环
# ─────────────────────────────────────────

def run_alert_service(app):
    """告警服务主循环：扫描未发送的告警并逐个发送邮件"""
    logger.info('告警服务已启动')
    while True:
        try:
            with app.app_context():
                # 预查询默认配置避免重复查询
                default_cfgs = {}
                for cfg_key in ['default_cpu_threshold', 'default_mem_threshold', 'default_disk_threshold',
                               'default_cpu_temp_threshold', 'default_disk_temp_threshold',
                               'alert_suppress_minutes',
                               'default_ssd_wear_threshold', 'default_nvme_spare_threshold']:
                    c = SystemConfig.query.filter_by(key=cfg_key).first()
                    default_cfgs[cfg_key] = c.value if c else None

                # 先进行阈值检查
                nodes = Node.query.filter(Node.status != 'offline').all()
                for node in nodes:
                    try:
                        check_thresholds(app, node.node_id, default_cfgs)
                    except Exception as e:
                        logger.error(f'节点 {node.node_id} 阈值检查异常: {e}')

                # 查找未发送的告警
                unsent = AlertRecord.query.filter_by(is_sent=False).order_by(AlertRecord.created_at.asc()).limit(10).all()
                for alert in unsent:
                    try:
                        node = Node.query.filter_by(node_id=alert.node_id).first()
                        ok = send_alert_email(app, alert, node)
                        alert.is_sent = ok
                        if ok:
                            alert.sent_at = datetime.now(_tz.utc).replace(tzinfo=None)
                        db.session.commit()
                    except Exception as e:
                        logger.error(f'更新告警状态失败(告警ID={alert.id}): {e}')
                        db.session.rollback()

        except Exception as e:
            logger.error(f'告警服务异常: {e}', exc_info=True)

        time.sleep(30)  # 每30秒检查一次


def _get_cfg(app, key, default):
    cfg = SystemConfig.query.filter_by(key=key).first()
    return cfg.value if cfg else default
