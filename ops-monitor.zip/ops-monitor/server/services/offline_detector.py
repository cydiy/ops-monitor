"""
离线检测服务
每60秒扫描所有节点，若最后上报时间超过阈值（默认900秒=15分钟，即3个心跳周期），
标记为离线；上报恢复后自动恢复在线。
"""
import time
import logging
from datetime import datetime, timedelta, timezone as _tz
from database import db, Node, SystemConfig, AlertRecord

logger = logging.getLogger('offline-detector')


def run_offline_detector(app):
    """离线检测主循环"""
    logger.info('离线检测服务已启动（3次心跳无上报=离线，无ICMP探测）')
    default_interval = 60
    default_timeout  = 900  # 15分钟 = 3个心跳周期（5min×3）

    while True:
        try:
            interval = default_interval
            timeout  = default_timeout

            with app.app_context():
                cfg_interval = SystemConfig.query.filter_by(key='offline_check_interval').first()
                cfg_timeout  = SystemConfig.query.filter_by(key='offline_timeout_seconds').first()

                if cfg_interval:
                    try:
                        interval = int(cfg_interval.value)
                    except (ValueError, TypeError):
                        pass
                if cfg_timeout:
                    try:
                        timeout = int(cfg_timeout.value)
                    except (ValueError, TypeError):
                        pass

                deadline = datetime.now(_tz.utc).replace(tzinfo=None) - timedelta(seconds=timeout)
                nodes = Node.query.all()

                for node in nodes:
                    if node.last_seen is None:
                        continue

                    last_seen_naive = node.last_seen.replace(tzinfo=None) \
                        if node.last_seen.tzinfo else node.last_seen

                    # 跳过已离线超过7天的节点，避免持续创建告警和日志刷屏
                    long_offline_deadline = datetime.now(_tz.utc).replace(tzinfo=None) - timedelta(days=7)
                    if node.status == 'offline' and last_seen_naive < long_offline_deadline:
                        continue

                    if last_seen_naive < deadline:
                        # ── 上报超时，直接标记离线 ──
                        if node.status != 'offline':
                            logger.warning(
                                f'节点 {node.name}({node.node_id}) 已离线，'
                                f'最后上报: {node.last_seen}'
                            )
                            node.status = 'offline'
                            _create_offline_alert(node)
                    else:
                        # 上报时间正常，确保在线状态
                        if node.status == 'offline':
                            logger.info(f'节点 {node.name}({node.node_id}) 已恢复在线')
                            node.status = 'online'
                            _resolve_offline_alert(node)

                db.session.commit()

        except Exception as e:
            logger.error(f'离线检测异常: {e}', exc_info=True)

        time.sleep(interval)


def _create_offline_alert(node):
    """创建节点离线告警记录"""
    existing = AlertRecord.query.filter_by(
        node_id=node.node_id,
        alert_type='node_offline',
        resolved=False
    ).first()
    if not existing:
        alert = AlertRecord(
            node_id=node.node_id,
            alert_type='node_offline',
            severity='critical',
            title=f'节点离线告警: {node.name}',
            message=(
                f'节点 {node.name}({node.ip or node.node_id}) 已离线，'
                f'最后上报时间: '
                f'{node.last_seen.strftime("%Y-%m-%d %H:%M:%S") if node.last_seen else "未知"}'
            ),
        )
        db.session.add(alert)


def _resolve_offline_alert(node):
    """恢复节点离线告警"""
    alerts = AlertRecord.query.filter_by(
        node_id=node.node_id,
        alert_type='node_offline',
        resolved=False
    ).all()
    for alert in alerts:
        alert.resolved = True
        alert.resolved_at = datetime.now(_tz.utc).replace(tzinfo=None)
