"""
报表生成服务
支持周报、月报、自定义报表，可导出为HTML/PDF格式
"""
import json
import logging
import statistics
from datetime import datetime, timedelta, timezone as _tz
from collections import defaultdict
from html import escape as html_escape
from database import db, Node, MetricsSnapshot, AlertRecord, SmartRecord

logger = logging.getLogger('report-service')

# 真实物理网卡匹配（与前端一致）
REAL_NIC_RE = r'^(ens|eth|bond|enp|enx|eno)\w*\d*$'


def generate_period_report(app, days=7, node_ids=None, title=None):
    """生成周期汇总报表（HTML格式）"""
    with app.app_context():
        since = datetime.now(_tz.utc) - timedelta(days=days)
        title = title or f'运维监控报告（最近{days}天）'

        # 获取节点列表
        if node_ids:
            nodes = Node.query.filter(Node.node_id.in_(node_ids)).all()
        else:
            nodes = Node.query.all()

        node_stats = []
        for node in nodes:
            snapshots = MetricsSnapshot.query.filter(
                MetricsSnapshot.node_id == node.node_id,
                MetricsSnapshot.collected_at >= since,
            ).order_by(MetricsSnapshot.collected_at.asc()).limit(5000).all()

            if not snapshots:
                node_stats.append({'node': node, 'empty': True})
                continue

            cpu_vals = [s.cpu_usage for s in snapshots if s.cpu_usage is not None]
            mem_vals = [s.mem_usage for s in snapshots if s.mem_usage is not None]

            stats = {
                'node': node,
                'empty': False,
                'data_points': len(snapshots),
                'cpu_avg': round(statistics.mean(cpu_vals), 1) if cpu_vals else 0,
                'cpu_max': round(max(cpu_vals), 1) if cpu_vals else 0,
                'mem_avg': round(statistics.mean(mem_vals), 1) if mem_vals else 0,
                'mem_max': round(max(mem_vals), 1) if mem_vals else 0,
                'alert_count': AlertRecord.query.filter(
                    AlertRecord.node_id == node.node_id,
                    AlertRecord.created_at >= since,
                ).count(),
                # 时序数据（用于生成图表）
                'times': [s.collected_at.strftime('%m-%d %H:%M') for s in snapshots],
                'cpu_series': [round(s.cpu_usage or 0, 1) for s in snapshots],
                'mem_series': [round(s.mem_usage or 0, 1) for s in snapshots],
            }
            # SMART健康
            smarts = SmartRecord.query.filter(
                SmartRecord.node_id == node.node_id,
                SmartRecord.collected_at >= since,
            ).order_by(SmartRecord.collected_at.desc()).limit(20).all()
            seen_disks = set()
            smart_summary = []
            for s in smarts:
                if s.disk_name not in seen_disks:
                    seen_disks.add(s.disk_name)
                    smart_summary.append(f'{s.disk_name}: {s.health_status}')
            stats['smart_summary'] = smart_summary
            node_stats.append(stats)

        # 生成HTML报告
        html = _render_report_html(title, since, datetime.now(_tz.utc), days, node_stats)
        return html


def _render_report_html(title, since, to_time, days, node_stats):
    """渲染HTML报表"""
    rows = ''
    charts_js = ''
    chart_divs = ''
    for i, stat in enumerate(node_stats):
        node = stat['node']
        if stat.get('empty'):
            rows += f'''
            <tr>
              <td>{html_escape(node.name)}</td><td>{html_escape(node.ip) or '-'}</td><td>{html_escape(node.status)}</td>
              <td colspan="5" style="color:#999;">本周期内无采集数据</td>
            </tr>'''
            continue

        status_color = {'online': '#67c23a', 'offline': '#909399', 'warning': '#e6a23c', 'alarm': '#f56c6c'}.get(node.status, '#909399')
        rows += f'''
        <tr>
          <td><a href="#node-{html_escape(str(node.node_id))}">{html_escape(node.name)}</a></td>
          <td>{html_escape(node.ip) or '-'}</td>
          <td><span style="color:{status_color};">●</span> {html_escape(node.status)}</td>
          <td>{stat['data_points']}</td>
          <td>{stat['cpu_avg']}% / {stat['cpu_max']}%</td>
          <td>{stat['mem_avg']}% / {stat['mem_max']}%</td>
          <td>{stat['alert_count']}</td>
          <td>{'<br>'.join(stat.get('smart_summary', ['-']))}</td>
        </tr>'''

        chart_divs += f'<div id="node-{html_escape(str(node.node_id))}" class="node-section">'
        chart_divs += f'<h3>{html_escape(node.name)} ({html_escape(node.ip) or "-"})</h3>'
        chart_divs += f'<div id="chart-{i}" style="height:260px;"></div></div>'

        times_json = json.dumps(stat['times'])
        cpu_json = json.dumps(stat['cpu_series'])
        mem_json = json.dumps(stat['mem_series'])
        charts_js += f'''
        var c{i} = echarts.init(document.getElementById('chart-{i}'));
        c{i}.setOption({{
            tooltip: {{trigger:'axis'}},
            legend: {{data:['CPU使用率','内存使用率']}},
            xAxis: {{type:'category', data:{times_json}, axisLabel:{{rotate:30,fontSize:10}}}},
            yAxis: {{type:'value', max:100, axisLabel:{{formatter:function(v){{return v+'%'}}}}}},
            series: [
                {{name:'CPU使用率', type:'line', smooth:true, data:{cpu_json}, itemStyle:{{color:'#5470c6'}}}},
                {{name:'内存使用率', type:'line', smooth:true, data:{mem_json}, itemStyle:{{color:'#91cc75'}}}}
            ]
        }});
        '''

    return f'''<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<title>{title}</title>
<script src="https://cdn.jsdelivr.net/npm/echarts@5/dist/echarts.min.js"></script>
<style>
  body{{font-family:'Microsoft YaHei',sans-serif;background:#f5f5f5;margin:0;padding:20px;color:#333;}}
  .container{{max-width:1100px;margin:0 auto;}}
  .report-header{{background:linear-gradient(135deg,#1a3a5c,#2d6a9f);color:#fff;padding:24px 32px;border-radius:8px;margin-bottom:24px;}}
  .report-header h1{{margin:0 0 8px;font-size:24px;}}
  .report-header p{{margin:0;opacity:.8;font-size:13px;}}
  table{{width:100%;border-collapse:collapse;background:#fff;border-radius:8px;overflow:hidden;box-shadow:0 2px 6px rgba(0,0,0,.08);margin-bottom:24px;}}
  th{{background:#1a3a5c;color:#fff;padding:10px 12px;font-size:13px;text-align:left;}}
  td{{padding:9px 12px;border-bottom:1px solid #eee;font-size:13px;}}
  tr:hover td{{background:#f0f7ff;}}
  .node-section{{background:#fff;border-radius:8px;padding:16px 20px;margin-bottom:16px;box-shadow:0 2px 6px rgba(0,0,0,.08);}}
  .node-section h3{{margin:0 0 12px;color:#1a3a5c;font-size:15px;}}
</style>
</head>
<body>
<div class="container">
  <div class="report-header">
    <h1>📊 {title}</h1>
    <p>统计范围：{since.strftime('%Y-%m-%d %H:%M')} ~ {to_time.strftime('%Y-%m-%d %H:%M')} UTC &nbsp;|&nbsp; 共 {days} 天 &nbsp;|&nbsp; 节点数量：{len(node_stats)}</p>
  </div>

  <h2 style="color:#1a3a5c;">节点汇总</h2>
  <table>
    <thead>
      <tr>
        <th>节点名称</th><th>IP地址</th><th>在线状态</th><th>采集点数</th>
        <th>CPU 均值/峰值</th><th>内存 均值/峰值</th><th>告警次数</th><th>磁盘健康</th>
      </tr>
    </thead>
    <tbody>{rows}</tbody>
  </table>

  <h2 style="color:#1a3a5c;">历史趋势图</h2>
  {chart_divs}
</div>
<script>
window.addEventListener('load', function() {{
  {charts_js}
}});
</script>
</body>
</html>'''


def get_dashboard_data(app, days=7, node_ids=None):
    """
    生成报表仪表盘数据（JSON格式），供 Web 前端渲染
    包含：CPU/内存趋势、磁盘使用率、网卡流量、离线统计、告警排行
    """
    import re
    _nic_re = re.compile(REAL_NIC_RE)

    with app.app_context():
        since = datetime.now(_tz.utc) - timedelta(days=days)
        since_naive = since.replace(tzinfo=None)

        # 获取节点列表
        if node_ids:
            nodes = Node.query.filter(Node.node_id.in_(node_ids)).all()
        else:
            nodes = Node.query.all()

        if not nodes:
            return {'period_days': days, 'nodes': [], 'summary': {}}

        all_cpu_vals = []
        all_mem_vals = []
        all_disk_vals = []
        total_offlines = 0
        total_alerts = 0
        node_alert_counts = []

        result_nodes = []
        for node in nodes:
            # ── 历史快照（CPU/内存/磁盘/网卡） ──
            snapshots = MetricsSnapshot.query.filter(
                MetricsSnapshot.node_id == node.node_id,
                MetricsSnapshot.collected_at >= since_naive,
            ).order_by(MetricsSnapshot.collected_at.asc()).limit(2000).all()

            cpu_times, cpu_values = [], []
            mem_times, mem_values = [], []
            disk_max_series = []  # 每个时间点的最大磁盘使用率
            net_primary = None   # 主网卡流量数据

            for s in snapshots:
                t = s.collected_at.strftime('%m-%d %H:%M') if s.collected_at else ''
                # CPU
                if s.cpu_usage is not None:
                    cpu_times.append(t); cpu_values.append(round(s.cpu_usage, 1))
                    all_cpu_vals.append(s.cpu_usage)
                # 内存
                if s.mem_usage is not None:
                    mem_times.append(t); mem_values.append(round(s.mem_usage, 1))
                    all_mem_vals.append(s.mem_usage)
                # 磁盘最大使用率
                if s.disk_info:
                    try:
                        disks = json.loads(s.disk_info) if isinstance(s.disk_info, str) else s.disk_info
                        if isinstance(disks, list):
                            max_d = max((d.get('use_percent', 0) or 0) for d in disks) if disks else 0
                            disk_max_series.append({'time': t, 'value': round(max_d, 1)})
                            all_disk_vals.append(max_d)
                    except (json.JSONDecodeError, TypeError):
                        pass
                # 网卡（取第一个匹配真实物理网卡的）
                if s.net_info and net_primary is None:
                    try:
                        net = json.loads(s.net_info) if isinstance(s.net_info, str) else s.net_info
                        if isinstance(net, dict):
                            for iface_name, stats in net.items():
                                if _nic_re.match(iface_name):
                                    net_primary = {'iface': iface_name}
                                    break
                    except (json.JSONDecodeError, TypeError):
                        pass

            # 网卡时序数据（需要单独查）
            net_tx_times, net_tx_vals = [], []
            net_rx_times, net_rx_vals = [], []
            if net_primary:
                primary_iface = net_primary['iface']
                for s in snapshots:
                    if s.net_info:
                        try:
                            net = json.loads(s.net_info) if isinstance(s.net_info, str) else s.net_info
                            if isinstance(net, dict) and primary_iface in net:
                                st = net[primary_iface]
                                t = s.collected_at.strftime('%m-%d %H:%M') if s.collected_at else ''
                                net_tx_times.append(t)
                                net_tx_vals.append(st.get('tx_speed', 0) or 0)
                                net_rx_times.append(t)
                                net_rx_vals.append(st.get('rx_speed', 0) or 0)
                        except (json.JSONDecodeError, TypeError):
                            pass

            # ── 离线次数统计（通过 status 变更估算）──
            # 统计该节点在此期间产生的 node_offline 类型告警数作为离线次数
            offline_count = AlertRecord.query.filter(
                AlertRecord.node_id == node.node_id,
                AlertRecord.alert_type == 'node_offline',
                AlertRecord.created_at >= since_naive,
            ).count()
            total_offlines += offline_count

            # ── CPU温度趋势 ──
            cpu_temp_series = []
            for s in snapshots:
                if s.cpu_temp is not None:
                    t = s.collected_at.strftime('%m-%d %H:%M') if s.collected_at else ''
                    cpu_temp_series.append({'time': t, 'value': float(s.cpu_temp)})

            # ── 硬盘温度趋势（取最高值）──
            disk_temp_series = []
            for s in snapshots:
                if s.disk_temps:
                    try:
                        temps = json.loads(s.disk_temps) if isinstance(s.disk_temps, str) else s.disk_temps
                        if temps:
                            max_t = max(float(v) for v in temps.values() if v is not None)
                            t = s.collected_at.strftime('%m-%d %H:%M') if s.collected_at else ''
                            disk_temp_series.append({'time': t, 'value': max_t})
                    except (json.JSONDecodeError, TypeError, ValueError):
                        pass

            # ── 在线率趋势（按天统计，1=在线，0=离线）──
            from sqlalchemy import func as sa_func, cast as sa_cast, Date as sa_Date
            online_snapshots = db.session.query(
                sa_func.date(MetricsSnapshot.collected_at).label('day'),
                sa_func.count().label('cnt')
            ).filter(
                MetricsSnapshot.node_id == node.node_id,
                MetricsSnapshot.collected_at >= since_naive,
            ).group_by(sa_func.date(MetricsSnapshot.collected_at)).all()
            online_map = {str(r.day): r.cnt for r in online_snapshots}
            online_times = []
            online_values = []
            current_date = since_naive.date()
            today = datetime.now(_tz.utc).replace(tzinfo=None).date()
            while current_date <= today:
                t_str = current_date.strftime('%m-%d')
                online_times.append(t_str)
                online_values.append(1 if str(current_date) in online_map else 0)
                current_date += timedelta(days=1)

            # ── 告警统计 ──
            alert_records = AlertRecord.query.filter(
                AlertRecord.node_id == node.node_id,
                AlertRecord.created_at >= since_naive,
            ).all()
            alert_count = len(alert_records)
            total_alerts += alert_count

            # 按类型聚合告警
            type_counts = defaultdict(int)
            severity_counts = defaultdict(int)
            latest_alert_time = None
            for ar in alert_records:
                type_counts[ar.alert_type] += 1
                severity_counts[ar.severity] += 1
                if ar.created_at and (latest_alert_time is None or ar.created_at > latest_alert_time):
                    latest_alert_time = ar.created_at

            top_alerts = sorted([{'type': t, 'count': c} for t, c in type_counts.items()],
                               key=lambda x: -x['count'])[:5]

            node_alert_counts.append({
                'name': node.name,
                'node_id': node.node_id,
                'alert_count': alert_count,
                'top_alert_type': top_alerts[0]['type'] if top_alerts else '-',
                'top_alert_count': top_alerts[0]['count'] if top_alerts else 0,
                'latest_alert': latest_alert_time.isoformat() if latest_alert_time else None,
            })

            result_nodes.append({
                'node_id': node.node_id,
                'name': node.name,
                'ip': node.ip,
                'status': node.status,
                'cpu': {'times': cpu_times, 'values': cpu_values},
                'mem': {'times': mem_times, 'values': mem_values},
                'disk_max_pct': [d['value'] for d in disk_max_series],
                'disk_times': [d['time'] for d in disk_max_series],
                'cpu_temp_times': [d['time'] for d in cpu_temp_series] if cpu_temp_series else [],
                'cpu_temp_values': [d['value'] for d in cpu_temp_series] if cpu_temp_series else [],
                'disk_temp_times': [d['time'] for d in disk_temp_series] if disk_temp_series else [],
                'disk_temp_values': [d['value'] for d in disk_temp_series] if disk_temp_series else [],
                'online_times': online_times,
                'online_values': online_values,
                'net_primary': {
                    'iface': net_primary['iface'] if net_primary else '',
                    'tx': net_tx_vals, 'rx': net_rx_vals,
                    'times': net_tx_times,
                } if net_primary else None,
                'offline_count': offline_count,
                'alert_count': alert_count,
                'top_alerts': top_alerts,
            })

        # 全局汇总
        summary = {
            'total_nodes': len(nodes),
            'avg_cpu': round(statistics.mean(all_cpu_vals), 1) if all_cpu_vals else 0,
            'avg_mem': round(statistics.mean(all_mem_vals), 1) if all_mem_vals else 0,
            'avg_disk': round(statistics.mean(all_disk_vals), 1) if all_disk_vals else 0,
            'total_offlines': total_offlines,
            'total_alerts': total_alerts,
            'top_alert_nodes': sorted(node_alert_counts, key=lambda x: -x['alert_count'])[:10],
        }

        return {
            'period_days': days,
            'nodes': result_nodes,
            'summary': summary,
        }
