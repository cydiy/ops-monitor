"""
服务端主入口 - 启动所有服务
包括：Web服务、离线检测服务、告警服务
支持单独启动某个服务 / 重置密码
"""
import sys
import os
import secrets
import threading
import argparse
import logging

# 确保当前目录在path中
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# 仅在未被app.py初始化时才配置日志
if not logging.getLogger('ops-monitor').handlers:
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s [%(levelname)s] %(name)s: %(message)s',
        handlers=[
            logging.StreamHandler(),
            logging.FileHandler('server.log', encoding='utf-8'),
        ]
    )
logger = logging.getLogger('main')


def reset_password(username):
    """重置指定用户密码（命令行模式）"""
    from app import create_app
    app = create_app()
    with app.app_context():
        from database import db, User
        user = User.query.filter_by(username=username).first()
        if not user:
            print(f'[ERROR] 用户 "{username}" 不存在', file=sys.stderr)
            sys.exit(1)

        new_pwd = secrets.token_urlsafe(12)
        user.set_password(new_pwd)
        db.session.commit()

        # 写入密码文件
        os.makedirs(app.instance_path, exist_ok=True)
        pwd_file = os.path.join(app.instance_path, 'password_reset.txt')
        with open(pwd_file, 'w') as f:
            f.write(f'{username}:{new_pwd}\n')
            f.write(f'time: {__import__("datetime").datetime.now().isoformat()}\n')
        os.chmod(pwd_file, 0o600)

        print(f'=' * 50)
        print(f'  密码重置成功')
        print(f'=' * 50)
        print(f'  用户名: {username}')
        print(f'  新密码: {new_pwd}')
        print(f'  请登录后立即修改密码！')
        print(f'  密码已保存至: {pwd_file}')
        print(f'=' * 50)


def start_web(app, host='0.0.0.0', port=8080, debug=False):
    """启动Web服务"""
    logger.info(f'启动Web服务，监听 {host}:{port}')
    app.run(host=host, port=port, debug=debug, use_reloader=False)


def start_offline_detector(app):
    """启动离线检测服务（后台线程）"""
    from services.offline_detector import run_offline_detector
    t = threading.Thread(target=run_offline_detector, args=(app,), daemon=True, name='offline-detector')
    t.start()
    logger.info('离线检测服务线程已启动')
    return t


def start_alert_service(app):
    """启动告警服务（后台线程）"""
    from services.alert_service import run_alert_service
    t = threading.Thread(target=run_alert_service, args=(app,), daemon=True, name='alert-service')
    t.start()
    logger.info('告警服务线程已启动')
    return t


def main():
    parser = argparse.ArgumentParser(description='运维监控系统服务端启动器')
    parser.add_argument('--port', type=int, default=8080, help='Web服务监听端口（默认8080）')
    parser.add_argument('--host', default='0.0.0.0', help='Web服务监听地址（默认0.0.0.0）')
    parser.add_argument('--debug', action='store_true', help='开启调试模式')
    parser.add_argument('--service', choices=['all', 'web', 'offline', 'alert'],
                        default='all', help='启动指定服务（默认all=全部）')
    parser.add_argument('--reset-password', nargs='?', const='admin',
                        help='重置指定用户密码（默认admin），重置后退出不启动服务')
    args = parser.parse_args()

    # ── 密码重置模式 ──
    if args.reset_password:
        reset_password(args.reset_password)
        return

    from app import create_app
    app = create_app()

    # 启动时清理超过24小时的密码重置文件
    try:
        _pwd_reset_file = os.path.join(app.instance_path, 'password_reset.txt')
        if os.path.exists(_pwd_reset_file):
            import time as _time
            if _time.time() - os.path.getmtime(_pwd_reset_file) > 86400:
                os.unlink(_pwd_reset_file)
                logger.info('已删除超过24小时的密码重置文件')
    except Exception as e:
        logger.warning(f'清理密码重置文件失败: {e}')

    if args.service in ('all', 'offline'):
        start_offline_detector(app)

    if args.service in ('all', 'alert'):
        start_alert_service(app)

    if args.service in ('all', 'web'):
        start_web(app, host=args.host, port=args.port, debug=args.debug)
    else:
        # 不启动Web时，主线程保持阻塞
        import time
        logger.info(f'后台服务已启动（{args.service}）')
        while True:
            time.sleep(60)


if __name__ == '__main__':
    main()
