"""
数据库模型定义与初始化模块
使用 SQLite + SQLAlchemy ORM
"""
import os
import json
from datetime import datetime, timezone


def _utcnow():
    """返回 UTC naive datetime（兼容 SQLite，替代 datetime.utcnow）"""
    return datetime.now(timezone.utc).replace(tzinfo=None)
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash

db = SQLAlchemy()


class Node(db.Model):
    """监控节点信息"""
    __tablename__ = 'nodes'

    id = db.Column(db.Integer, primary_key=True)
    node_id = db.Column(db.String(64), unique=True, nullable=False, comment='节点唯一标识')
    name = db.Column(db.String(128), nullable=False, comment='节点名称')
    ip = db.Column(db.String(64), comment='节点IP地址')
    os_info = db.Column(db.String(256), comment='操作系统信息')
    description = db.Column(db.String(512), comment='节点描述')
    # 告警阈值（JSON格式存储）
    thresholds = db.Column(db.Text, default='{}', comment='告警阈值配置')
    status = db.Column(db.String(16), default='offline', comment='节点状态: online/offline/warning/alarm')
    token = db.Column(db.String(128), comment='节点API认证令牌')
    agent_version = db.Column(db.String(32), comment='Agent版本号')
    last_seen = db.Column(db.DateTime, comment='最后上报时间')
    created_at = db.Column(db.DateTime, default=_utcnow)
    updated_at = db.Column(db.DateTime, default=_utcnow, onupdate=_utcnow)

    def get_thresholds(self):
        """获取告警阈值配置"""
        try:
            return json.loads(self.thresholds or '{}')
        except Exception:
            return {}

    def set_thresholds(self, data):
        """设置告警阈值配置"""
        self.thresholds = json.dumps(data)

    def to_dict(self):
        return {
            'id': self.id,
            'node_id': self.node_id,
            'name': self.name,
            'ip': self.ip,
            'os_info': self.os_info,
            'description': self.description,
            'thresholds': self.get_thresholds(),
            'status': self.status,
            'has_token': bool(self.token),
            'agent_version': self.agent_version or '',
            'last_seen': self.last_seen.isoformat() if self.last_seen else None,
            'created_at': self.created_at.isoformat() if self.created_at else None,
        }


class MetricsSnapshot(db.Model):
    """系统指标快照（每次上报一条记录）"""
    __tablename__ = 'metrics_snapshots'

    id = db.Column(db.Integer, primary_key=True)
    node_id = db.Column(db.String(64), db.ForeignKey('nodes.node_id'), nullable=False, index=True)
    collected_at = db.Column(db.DateTime, nullable=False, index=True, comment='采集时间')
    # 基础指标
    cpu_usage = db.Column(db.Float, comment='CPU整体使用率(%)')
    cpu_cores = db.Column(db.Text, comment='各核心使用率(JSON)')
    load_1 = db.Column(db.Float, comment='1分钟平均负载')
    load_5 = db.Column(db.Float, comment='5分钟平均负载')
    load_15 = db.Column(db.Float, comment='15分钟平均负载')
    mem_total = db.Column(db.BigInteger, comment='内存总量(MB)')
    mem_used = db.Column(db.BigInteger, comment='已用内存(MB)')
    mem_free = db.Column(db.BigInteger, comment='可用内存(MB)')
    mem_usage = db.Column(db.Float, comment='内存使用率(%)')
    swap_total = db.Column(db.BigInteger, comment='Swap总量(MB)')
    swap_used = db.Column(db.BigInteger, comment='已用Swap(MB)')
    swap_free = db.Column(db.BigInteger, comment='可用Swap(MB)')
    # 磁盘使用
    disk_info = db.Column(db.Text, comment='磁盘分区信息(JSON)')
    # 温度
    cpu_temp = db.Column(db.Float, comment='CPU温度(℃)')
    disk_temps = db.Column(db.Text, comment='硬盘温度(JSON)')
    # 网卡流量
    net_info = db.Column(db.Text, comment='网卡流量信息(JSON)')
    # 开机时间
    uptime = db.Column(db.BigInteger, comment='开机时长(秒)')
    # RAID信息
    raid_info = db.Column(db.Text, comment='RAID阵列信息(JSON)')
    # 完整原始数据
    raw_data = db.Column(db.Text, comment='完整原始JSON数据')

    created_at = db.Column(db.DateTime, default=_utcnow, index=True)

    __table_args__ = (
        db.Index('idx_snapshot_node_time', 'node_id', 'collected_at'),
    )

    def to_dict(self):
        return {
            'id': self.id,
            'node_id': self.node_id,
            'collected_at': self.collected_at.isoformat() if self.collected_at else None,
            'cpu_usage': self.cpu_usage,
            'load_1': self.load_1,
            'load_5': self.load_5,
            'load_15': self.load_15,
            'mem_total': self.mem_total,
            'mem_used': self.mem_used,
            'mem_usage': self.mem_usage,
            'cpu_temp': self.cpu_temp,
            'uptime': self.uptime,
        }


class ProcessRecord(db.Model):
    """进程监控记录"""
    __tablename__ = 'process_records'

    id = db.Column(db.Integer, primary_key=True)
    node_id = db.Column(db.String(64), db.ForeignKey('nodes.node_id'), nullable=False, index=True)
    collected_at = db.Column(db.DateTime, nullable=False)
    cpu_top10 = db.Column(db.Text, comment='CPU占用TOP10进程(JSON)')
    mem_top10 = db.Column(db.Text, comment='内存占用TOP10进程(JSON)')
    zombie_procs = db.Column(db.Text, comment='僵尸进程列表(JSON)')
    abnormal_procs = db.Column(db.Text, comment='异常进程列表(JSON)')
    proc_count = db.Column(db.Integer, default=0, comment='进程总数')
    created_at = db.Column(db.DateTime, default=_utcnow, index=True)


class SmartRecord(db.Model):
    """磁盘SMART信息记录"""
    __tablename__ = 'smart_records'

    id = db.Column(db.Integer, primary_key=True)
    node_id = db.Column(db.String(64), db.ForeignKey('nodes.node_id'), nullable=False, index=True)
    collected_at = db.Column(db.DateTime, nullable=False)
    disk_name = db.Column(db.String(64), comment='磁盘设备名')
    disk_type = db.Column(db.String(16), comment='磁盘类型: sata/ssd/nvme')
    health_status = db.Column(db.String(16), comment='健康状态: PASSED/FAILED/UNKNOWN/N/A')
    reallocated_sectors = db.Column(db.Integer, comment='重新分配扇区数(坏道)')
    power_on_hours = db.Column(db.Integer, comment='通电时长(小时)')
    temperature = db.Column(db.Float, comment='硬盘温度(℃)')
    wear_leveling = db.Column(db.Integer, comment='SSD磨损均衡值')
    nvme_spare = db.Column(db.Integer, comment='NVMe可用备用空间(%)')
    disk_model = db.Column(db.String(256), comment='磁盘型号')
    disk_serial = db.Column(db.String(128), comment='磁盘序列号')
    disk_size = db.Column(db.String(32), comment='磁盘容量(人类可读)')
    raw_data = db.Column(db.Text, comment='原始SMART数据(JSON)')
    created_at = db.Column(db.DateTime, default=_utcnow, index=True)


class LoginRecord(db.Model):
    """登录记录"""
    __tablename__ = 'login_records'

    id = db.Column(db.Integer, primary_key=True)
    node_id = db.Column(db.String(64), db.ForeignKey('nodes.node_id'), nullable=False, index=True)
    username = db.Column(db.String(64), comment='登录用户名')
    ip_address = db.Column(db.String(64), comment='登录来源IP')
    login_time = db.Column(db.DateTime, index=True, comment='登录时间')
    is_abnormal = db.Column(db.Boolean, default=False, comment='是否异常登录')
    abnormal_reason = db.Column(db.String(256), comment='异常原因')
    created_at = db.Column(db.DateTime, default=_utcnow)


class SecurityEvent(db.Model):
    """安全事件记录"""
    __tablename__ = 'security_events'

    id = db.Column(db.Integer, primary_key=True)
    node_id = db.Column(db.String(64), db.ForeignKey('nodes.node_id'), nullable=False, index=True)
    event_type = db.Column(db.String(64), nullable=False, comment='事件类型: login_fail/file_change/intrusion/firewall')
    severity = db.Column(db.String(16), default='warning', comment='严重级别: info/warning/critical')
    title = db.Column(db.String(256), comment='事件标题')
    detail = db.Column(db.Text, comment='事件详情(JSON)')
    occurred_at = db.Column(db.DateTime, nullable=False, index=True, comment='事件发生时间')
    is_alerted = db.Column(db.Boolean, default=False, comment='是否已告警')
    created_at = db.Column(db.DateTime, default=_utcnow, index=True)

    def to_dict(self):
        return {
            'id': self.id,
            'node_id': self.node_id,
            'event_type': self.event_type,
            'severity': self.severity,
            'title': self.title,
            'detail': json.loads(self.detail) if self.detail else {},
            'occurred_at': self.occurred_at.isoformat() if self.occurred_at else None,
        }


class AlertRecord(db.Model):
    """告警记录"""
    __tablename__ = 'alert_records'

    id = db.Column(db.Integer, primary_key=True)
    node_id = db.Column(db.String(64), db.ForeignKey('nodes.node_id'), nullable=False, index=True)
    alert_type = db.Column(db.String(64), nullable=False, comment='告警类型')
    severity = db.Column(db.String(16), default='warning', comment='严重级别: warning/critical')
    title = db.Column(db.String(256), comment='告警标题')
    message = db.Column(db.Text, comment='告警内容')
    detail = db.Column(db.Text, comment='告警详情(JSON)')
    is_sent = db.Column(db.Boolean, default=False, index=True, comment='是否已发送邮件')
    sent_at = db.Column(db.DateTime, comment='发送时间')
    resolved = db.Column(db.Boolean, default=False, index=True, comment='是否已恢复')
    resolved_at = db.Column(db.DateTime, comment='恢复时间')
    created_at = db.Column(db.DateTime, default=_utcnow, index=True)

    def to_dict(self):
        return {
            'id': self.id,
            'node_id': self.node_id,
            'alert_type': self.alert_type,
            'severity': self.severity,
            'title': self.title,
            'message': self.message,
            'is_sent': self.is_sent,
            'resolved': self.resolved,
            'created_at': self.created_at.isoformat() if self.created_at else None,
        }


class AssetRecord(db.Model):
    """资产台账"""
    __tablename__ = 'asset_records'

    id = db.Column(db.Integer, primary_key=True)
    node_id = db.Column(db.String(64), db.ForeignKey('nodes.node_id'), nullable=False, index=True)
    hardware_info = db.Column(db.Text, comment='硬件信息(JSON)')
    software_list = db.Column(db.Text, comment='软件清单(JSON)')
    hardware_changes = db.Column(db.Text, comment='硬件变更记录(JSON)')
    software_changes = db.Column(db.Text, comment='软件变更记录(JSON)')
    updated_at = db.Column(db.DateTime, default=_utcnow, onupdate=_utcnow)


class SysLog(db.Model):
    """系统日志记录"""
    __tablename__ = 'sys_logs'

    id = db.Column(db.Integer, primary_key=True)
    node_id = db.Column(db.String(64), db.ForeignKey('nodes.node_id'), nullable=False, index=True)
    log_level = db.Column(db.String(16), comment='日志级别: INFO/WARN/ERROR/CRIT')
    log_time = db.Column(db.DateTime, index=True, comment='日志时间')
    source = db.Column(db.String(128), comment='日志来源')
    message = db.Column(db.Text, comment='日志内容')
    created_at = db.Column(db.DateTime, default=_utcnow)


class User(db.Model):
    """管理员用户"""
    __tablename__ = 'users'

    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(64), unique=True, nullable=False)
    password_hash = db.Column(db.String(256), nullable=False)
    email = db.Column(db.String(128), comment='邮箱')
    role = db.Column(db.String(16), default='admin', comment='角色: admin/viewer')
    last_login = db.Column(db.DateTime)
    created_at = db.Column(db.DateTime, default=_utcnow)

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)


class SystemConfig(db.Model):
    """系统配置（SMTP、告警等全局配置）"""
    __tablename__ = 'system_config'

    id = db.Column(db.Integer, primary_key=True)
    key = db.Column(db.String(128), unique=True, nullable=False)
    value = db.Column(db.Text, comment='配置值')
    description = db.Column(db.String(256), comment='配置说明')
    updated_at = db.Column(db.DateTime, default=_utcnow, onupdate=_utcnow)


class PortRecord(db.Model):
    """节点监听端口记录"""
    __tablename__ = 'port_records'

    id = db.Column(db.Integer, primary_key=True)
    node_id = db.Column(db.String(64), db.ForeignKey('nodes.node_id'), nullable=False, index=True)
    collected_at = db.Column(db.DateTime, nullable=False, index=True, comment='采集时间')
    protocol = db.Column(db.String(16), comment='协议: tcp/tcp6/udp/udp6')
    port = db.Column(db.Integer, nullable=False, comment='端口号')
    address = db.Column(db.String(64), comment='监听地址')
    pid = db.Column(db.String(32), comment='进程PID')
    process = db.Column(db.String(128), comment='进程名')
    created_at = db.Column(db.DateTime, default=_utcnow)

    __table_args__ = (
        db.Index('idx_port_node_time', 'node_id', 'collected_at'),
    )


def init_db(app):
    """初始化数据库，创建表并插入默认数据"""
    with app.app_context():
        db.create_all()

        # ── 简单 schema 迁移：为已有数据库补充新增列 ──
        # 不引入 Alembic，仅检测并添加缺失的列
        # 用法：在 _migrations 列表中添加 (表名, 列名, SQL类型)
        _migrations = [
            ('nodes', 'agent_version', 'VARCHAR(32)'),
            ('metrics_snapshots', 'swap_total', 'BIGINT'),
            ('metrics_snapshots', 'swap_used', 'BIGINT'),
            ('metrics_snapshots', 'swap_free', 'BIGINT'),
        ]
        try:
            from sqlalchemy import inspect as _sa_inspect, text as _sa_text
            inspector = _sa_inspect(db.engine)
            for tbl, col, col_type in _migrations:
                if tbl in inspector.get_table_names():
                    existing_cols = {c['name'] for c in inspector.get_columns(tbl)}
                    if col not in existing_cols:
                        db.session.execute(_sa_text(f'ALTER TABLE {tbl} ADD COLUMN {col} {col_type}'))
                        db.session.commit()
                        app.logger.info(f'数据库迁移: {tbl}.{col} 已添加')
        except Exception as mig_err:
            app.logger.warning(f'数据库迁移检查失败（可忽略）: {mig_err}')
            db.session.rollback()

        # 获取数据库文件路径
        db_uri = app.config.get('SQLALCHEMY_DATABASE_URI', '')
        if db_uri.startswith('sqlite:///'):
            db_path = db_uri.replace('sqlite:///', '')
            if not db_path:
                db_path = 'instance/app.db'
        else:
            db_path = 'instance/app.db'
        # 创建默认管理员账户
        if not User.query.filter_by(username='admin').first():
            import secrets
            import string
            # 生成满足复杂度要求的随机密码（至少16位，含大小写+数字+特殊字符）
            alphabet = string.ascii_letters + string.digits + '!@#$%^&*'
            default_pwd = ''.join(secrets.choice(alphabet) for _ in range(16))
            admin = User(username='admin', email='admin@localhost', role='admin')
            admin.set_password(default_pwd)
            db.session.add(admin)
            # 将默认密码写入文件（仅首次）
            pwd_file = os.path.join(os.path.dirname(db_path), 'default_admin_password.txt')
            if not os.path.exists(pwd_file):
                with open(pwd_file, 'w') as f:
                    f.write(f'admin:{default_pwd}\n')
                os.chmod(pwd_file, 0o600)
                # 注意：此文件将在管理员首次登录后被自动删除（见 app.py web_login）
                print(f'[重要] 默认管理员密码已生成: {default_pwd}')
                print(f'密码保存在: {pwd_file}')
                print(f'登录后请立即修改密码！')
        # 插入默认系统配置
        default_configs = [
            ('smtp_host', '', 'SMTP服务器地址'),
            ('smtp_port', '465', 'SMTP端口'),
            ('smtp_user', '', 'SMTP用户名'),
            ('smtp_pass', '', 'SMTP密码'),
            ('smtp_ssl', 'true', '是否启用SSL'),
            ('alert_recipients', '[]', '告警收件人列表(JSON数组)'),
            ('alert_suppress_minutes', '120', '告警抑制时间(分钟)，同类型同节点在此时间内不重复发送'),
            ('offline_timeout_seconds', '900', '离线判定超时时间(秒)，默认900=3个心跳周期'),
            ('offline_check_interval', '60', '离线检测间隔(秒)'),
            ('default_cpu_threshold', '90', '默认CPU告警阈值(%)'),
            ('default_mem_threshold', '90', '默认内存告警阈值(%)'),
            ('default_disk_threshold', '85', '默认磁盘告警阈值(%)'),
            ('default_cpu_temp_threshold', '80', '默认CPU温度告警阈值(℃)'),
            ('default_disk_temp_threshold', '55', '默认硬盘温度告警阈值(℃)'),
            ('default_ssd_wear_threshold', '5', '默认SSD磨损告警阈值(%)，低于此值触发告警'),
            ('default_nvme_spare_threshold', '5', '默认NVMe备用空间告警阈值(%)，低于此值触发告警'),
            ('force_password_change', 'true', '是否强制修改默认密码'),
        ]
        for key, value, desc in default_configs:
            if not SystemConfig.query.filter_by(key=key).first():
                cfg = SystemConfig(key=key, value=value, description=desc)
                db.session.add(cfg)
        db.session.commit()
