"""
服务端主应用 - Flask API + Web仪表盘
提供子节点数据接收、查询API、用户认证等功能
"""
import os
import re
import gzip
import json
import logging
from logging.handlers import RotatingFileHandler
from datetime import datetime, timedelta, timezone
from functools import wraps
from flask import Flask, request, jsonify, session, redirect, url_for, render_template, abort
from flask_session import Session
from database import db, init_db, Node, MetricsSnapshot, ProcessRecord, SmartRecord, \
    LoginRecord, SecurityEvent, AlertRecord, AssetRecord, SysLog, User, SystemConfig, PortRecord
from crypto_utils import encrypt_value, decrypt_value

__version__ = '1.9.9'

# ─────────────── 日志配置 ───────────────
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(name)s: %(message)s',
    handlers=[
        logging.StreamHandler(),
        RotatingFileHandler('server.log', encoding='utf-8', maxBytes=10*1024*1024, backupCount=5),
    ]
)
logger = logging.getLogger('ops-monitor')


def create_app(config_path=None):
    """创建并配置Flask应用"""
    app = Flask(__name__, template_folder='templates', static_folder='static')

    # 登录暴力破解防护（线程安全）
    import threading
    _login_attempts = {}  # {ip: {'count': int, 'locked_until': datetime}}
    _login_attempts_lock = threading.Lock()

    # ─────────────── 基础配置 ───────────────
    base_dir = os.path.dirname(os.path.abspath(__file__))
    db_path = os.path.join(base_dir, '..', 'data', 'monitor.db')
    os.makedirs(os.path.dirname(db_path), exist_ok=True)

    # SECRET_KEY: 优先环境变量 > 持久化文件 > 自动生成
    secret_key = os.environ.get('SECRET_KEY')
    secret_key_file = os.path.join(base_dir, '..', 'data', 'secret_key.txt')
    if not secret_key:
        if os.path.exists(secret_key_file):
            with open(secret_key_file, 'r') as f:
                secret_key = f.read().strip()
        if not secret_key:
            import secrets
            secret_key = secrets.token_hex(32)
            os.makedirs(os.path.dirname(secret_key_file), exist_ok=True)
            with open(secret_key_file, 'w') as f:
                f.write(secret_key)
            os.chmod(secret_key_file, 0o600)
            logger.info('已生成新的SECRET_KEY并保存')
    app.config['SECRET_KEY'] = secret_key
    app.config['SQLALCHEMY_DATABASE_URI'] = f'sqlite:///{os.path.abspath(db_path)}'
    app.config['SQLALCHEMY_ENGINE_OPTIONS'] = {'connect_args': {'check_same_thread': False}}
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    app.config['SESSION_TYPE'] = 'filesystem'
    app.config['SESSION_FILE_DIR'] = os.path.join(base_dir, '..', 'data', 'sessions')
    app.config['PERMANENT_SESSION_LIFETIME'] = timedelta(hours=4)
    app.config['SESSION_COOKIE_HTTPONLY'] = True
    app.config['SESSION_COOKIE_SECURE'] = False  # 生产环境若启用 HTTPS 请改为 True
    app.config['SESSION_COOKIE_SAMESITE'] = 'Lax'
    os.makedirs(app.config['SESSION_FILE_DIR'], exist_ok=True)

    # 初始化扩展
    db.init_app(app)

    # 配置 SQLite WAL 模式提升并发性能
    with app.app_context():
        from sqlalchemy import event, text
        # 兼容 Flask-SQLAlchemy 3.x: 使用 engine 绑定方式获取引擎
        try:
            engine = db.get_engine(app)
        except (KeyError, AttributeError):
            engine = db.engine
        with engine.connect() as conn:
            conn.execute(text('PRAGMA journal_mode=WAL'))
            conn.execute(text('PRAGMA synchronous=NORMAL'))
            conn.commit()
        logger.info('SQLite WAL 模式已启用')

    Session(app)
    init_db(app)

    # ─────────────── 模板上下文 ───────────────
    @app.context_processor
    def inject_csrf_token():
        """向所有模板注入 csrf_token 变量（基于 session）
        加 try-except 保护：flask-session filesystem 模式下 session 访问可能
        因文件权限/损坏/并发问题抛异常，不应阻塞整个页面渲染。"""
        import hashlib
        try:
            token = session.get('_csrf_token')
            if not token:
                token = hashlib.sha256(os.urandom(32)).hexdigest()[:48]
                try:
                    session['_csrf_token'] = token
                except Exception:
                    pass  # session 写入失败时仅本次不持久化，不影响渲染
        except Exception:
            token = hashlib.sha256(os.urandom(32)).hexdigest()[:48]
        return dict(csrf_token=lambda: token, server_version=__version__)

    # ─────────────── 认证装饰器 ───────────────
    def _parse_iso(s):
        """兼容性ISO时间解析（支持Z后缀和任意时区）
        始终返回 naive UTC datetime（先转UTC再移除时区）
        """
        if not s:
            return datetime.now(timezone.utc).replace(tzinfo=None)
        try:
            s = str(s).replace('Z', '+00:00')
            dt = datetime.fromisoformat(s)
            if dt.tzinfo:
                dt = dt.astimezone(timezone.utc).replace(tzinfo=None)
            return dt
        except (ValueError, AttributeError):
            return datetime.now(timezone.utc).replace(tzinfo=None)

    def login_required(f):
        @wraps(f)
        def decorated(*args, **kwargs):
            if 'user_id' not in session:
                if request.path.startswith('/api/'):
                    return jsonify({'code': 401, 'msg': '请先登录'}), 401
                return redirect(url_for('web_login'))
            # 强制修改密码检查（允许修改密码、获取用户信息和设置页通过）
            if (get_config('force_password_change', 'false') == 'true'
                    and request.path not in ('/api/users/change_password', '/api/users/me', '/settings', '/login')):
                if request.path.startswith('/api/'):
                    return jsonify({'code': 403, 'msg': '请先修改默认密码'}), 403
                return redirect(url_for('web_settings'))
            return f(*args, **kwargs)
        return decorated

    def admin_required(f):
        """管理员权限校验"""
        @wraps(f)
        def decorated(*args, **kwargs):
            if session.get('role') != 'admin':
                return jsonify({'code': 403, 'msg': '权限不足，需要管理员角色'}), 403
            return f(*args, **kwargs)
        return decorated

    def node_api_auth(f):
        """子节点API认证（首次上报自动注册，后续验证token）"""
        @wraps(f)
        def decorated(*args, **kwargs):
            token = request.headers.get('X-Node-Token', '')
            # 优先从 Header 取 node_id，若无则解析 body（注意 gzip 时 get_json 失效）
            node_id = request.headers.get('X-Node-ID', '')
            if not node_id:
                try:
                    body = parse_request_data()
                    node_id = body.get('node_id', '')
                    # 把解析好的 body 缓存到 request，避免后续视图再次读取（流只能读一次）
                    request._cached_body = body
                except Exception:
                    node_id = ''

            if not node_id:
                return jsonify({'code': 401, 'msg': '缺少认证信息'}), 401

            node = Node.query.filter_by(node_id=node_id).first()

            if not node:
                # 首次上报：自动注册节点，生成 token
                import secrets as _secrets
                new_token = _secrets.token_urlsafe(32)
                # 使用已缓存的 body，避免重复读流
                if not hasattr(request, '_cached_body'):
                    request._cached_body = parse_request_data()
                data = request._cached_body
                # 优先使用部署时填写的节点名称（node_name），否则回退 hostname
                display_name = data.get('node_name') or data.get('hostname') or node_id
                node = Node(
                    node_id=node_id,
                    name=display_name,
                    token=new_token,
                    status='online',
                    last_seen=datetime.now(timezone.utc).replace(tzinfo=None),
                )
                db.session.add(node)
                db.session.commit()
                logger.info(f'新节点自动注册: {node_id}')
                request._auto_registered = True
                request._node_token = new_token
                request._node_obj = node
                return f(*args, **kwargs)

            # 已有节点：验证 token
            if not token or node.token != token:
                # 容错：节点已注册但请求无token（可能是首次注册时服务端500导致agent未拿到token）
                # 此时允许请求通过，并在响应中补发token
                if not token and node.token:
                    # 仅当请求来源IP与节点记录IP匹配时才放行（防止外部冒充）
                    # 注意：若部署在反向代理后，请配置 Flask ProxyFix 而非信任 X-Real-IP header
                    request_ip = request.remote_addr or ''
                    if node.ip and node.ip != request_ip and request_ip:
                        logger.warning(f'无token且IP不匹配: node_id={node_id}, ip={request_ip} != {node.ip}')
                        return jsonify({'error': 'unauthorized', 'message': '需要有效的认证token'}), 401
                    logger.warning(f'节点{node_id}缺少token但IP匹配({request_ip})，临时放行')
                    request._auto_registered = False
                    request._node_token = node.token
                    request._need_token = True
                    request._node_obj = node
                    return f(*args, **kwargs)
                logger.warning(f'节点Token验证失败: node_id={node_id}, ip={request.remote_addr}')
                return jsonify({'code': 401, 'msg': '认证失败，请检查节点配置或删除本地token文件重试'}), 401
            request._auto_registered = False
            request._node_obj = node
            return f(*args, **kwargs)
        return decorated

    def _csrf_validate():
        """验证POST请求的CSRF token"""
        if request.method not in ('POST', 'PUT', 'DELETE'):
            return True
        # AJAX请求从header取token
        token = request.headers.get('X-CSRF-Token', '')
        if not token:
            # 表单请求从表单取token
            token = request.form.get('csrf_token', '')
        session_token = session.get('_csrf_token', '')
        if not session_token or not token or token != session_token:
            logger.warning(f'CSRF验证失败: path={request.path}, remote={request.remote_addr}')
            return False
        return True

    @app.before_request
    def _csrf_protect():
        """对需要认证的POST/PUT/DELETE请求进行CSRF验证"""
        if request.method not in ('POST', 'PUT', 'DELETE'):
            return
        # 跳过不需要CSRF的路由（登录页面、节点API等）
        skip_paths = ('/login', '/api/report/', '/api/heartbeat')
        if any(request.path.startswith(p) for p in skip_paths):
            return
        # 仅对已认证用户的写操作校验CSRF
        if 'user_id' in session and not _csrf_validate():
            if request.path.startswith('/api/'):
                return jsonify({'code': 403, 'msg': 'CSRF验证失败'}), 403
            abort(403)

    # ─────────────── 辅助函数 ───────────────
    def get_config(key, default=None):
        """获取系统配置"""
        cfg = SystemConfig.query.filter_by(key=key).first()
        return cfg.value if cfg else default

    def parse_request_data():
        """解析请求数据（支持gzip压缩）。
        若 request._cached_body 已有缓存（由 node_api_auth 设置）则直接返回。"""
        if hasattr(request, '_cached_body'):
            return request._cached_body
        content_encoding = request.headers.get('Content-Encoding', '')
        if 'gzip' in content_encoding.lower():
            data = gzip.decompress(request.data)
            return json.loads(data.decode('utf-8'))
        return request.get_json(force=True) or {}

    # ══════════════════════════════════════════
    #  Web 页面路由
    # ══════════════════════════════════════════

    @app.route('/login', methods=['GET', 'POST'])
    def web_login():
        """登录页面（含暴力破解防护）"""
        if request.method == 'POST':
            client_ip = request.remote_addr or 'unknown'
            now = datetime.now(timezone.utc).replace(tzinfo=None)

            # 检查IP是否被锁定
            with _login_attempts_lock:
                rec = _login_attempts.get(client_ip)
            if rec and rec.get('locked_until') and now < rec['locked_until']:
                remaining = int((rec['locked_until'] - now).total_seconds())
                return render_template('login.html', error=f'登录尝试过于频繁，请{remaining}秒后重试')

            username = (request.form.get('username') or '').strip()
            password = request.form.get('password', '')

            user = User.query.filter_by(username=username).first()
            if user and user.check_password(password):
                # 登录成功，清除计数
                with _login_attempts_lock:
                    _login_attempts.pop(client_ip, None)
                # 防止会话固定攻击：清除旧 session 数据并重新生成 session ID
                session.clear()
                if hasattr(session, 'regenerate_id'):
                    session.regenerate_id()
                session['user_id'] = user.id
                session['username'] = user.username
                session['role'] = user.role
                user.last_login = now
                db.session.commit()
                logger.info(f'用户 {username} 从 {client_ip} 登录成功')
                # 首次登录后删除默认密码文件
                try:
                    _pwd_file = os.path.join(os.path.dirname(db_path), 'default_admin_password.txt')
                    if os.path.exists(_pwd_file):
                        os.unlink(_pwd_file)
                        logger.info('已删除默认管理员密码文件')
                except Exception as e:
                    logger.warning(f'删除默认密码文件失败: {e}')
                return redirect(url_for('web_index'))

            # 登录失败
            with _login_attempts_lock:
                rec = _login_attempts.get(client_ip)
                if not rec:
                    rec = {'count': 0, 'locked_until': None}
                    _login_attempts[client_ip] = rec
                rec['count'] += 1
                count = rec['count']
            logger.warning(f'用户 {username} 从 {client_ip} 登录失败(第{count}次)')

            # 连续5次失败锁定15分钟，连续3次显示警告
            if count >= 5:
                with _login_attempts_lock:
                    rec['locked_until'] = now + timedelta(minutes=15)
                    rec['count'] = 0
                logger.error(f'IP {client_ip} 因暴力破解被锁定15分钟')
                return render_template('login.html', error='登录尝试过于频繁，账号已临时锁定15分钟')

            msg = '用户名或密码错误'
            if count >= 3:
                msg += f'（已失败{count}次，剩余{5-count}次后将临时锁定）'
            return render_template('login.html', error=msg)

        return render_template('login.html')

    @app.route('/logout')
    def web_logout():
        """退出登录"""
        session.clear()
        return redirect(url_for('web_login'))

    @app.route('/')
    @login_required
    def web_index():
        """首页 - 节点列表"""
        return render_template('index.html')

    @app.route('/node/<node_id>')
    @login_required
    def web_node_detail(node_id):
        """节点详情页"""
        node = Node.query.filter_by(node_id=node_id).first_or_404()
        return render_template('node_detail.html', node=node)

    @app.route('/alerts')
    @login_required
    def web_alerts():
        """告警列表页"""
        return render_template('alerts.html')

    @app.route('/settings')
    @login_required
    def web_settings():
        """系统设置页"""
        return render_template('settings.html')

    @app.route('/reports')
    @login_required
    def web_reports():
        """报表页面"""
        return render_template('reports.html')

    @app.route('/assets')
    @login_required
    def web_assets():
        """资产管理页面"""
        return render_template('assets.html')

    # ══════════════════════════════════════════
    #  子节点数据上报 API
    # ══════════════════════════════════════════

    def _get_or_create_node(node_id, node_name=None):
        """查找或创建节点（统一逻辑，避免多处重复）"""
        node = Node.query.filter_by(node_id=node_id).first()
        if not node:
            import secrets as _secrets
            display_name = node_name or node_id
            node = Node(node_id=node_id, name=display_name,
                        token=_secrets.token_urlsafe(32))
            db.session.add(node)
            logger.info(f'_get_or_create_node 创建新节点 {node_id}（含token）')
        node.last_seen = datetime.now(timezone.utc).replace(tzinfo=None)
        node.status = 'online'
        return node

    @app.route('/api/report/metrics', methods=['POST'])
    @node_api_auth
    def api_report_metrics():
        """接收子节点上报的系统指标数据"""
        try:
            data = parse_request_data()
            node_id = data.get('node_id') or request.headers.get('X-Node-ID')
            if not node_id:
                return jsonify({'code': 400, 'msg': '缺少node_id'}), 400

            # 更新或创建节点
            node = _get_or_create_node(node_id, data.get('node_name') or data.get('hostname'))

            node.ip = data.get('ip', node.ip)
            node.os_info = data.get('os_info', node.os_info)
            # 优先使用部署时填写的节点名称，否则回退 hostname
            node.name = data.get('node_name') or data.get('hostname') or node.name
            av = data.get('agent_version', '').strip()
            if av:
                node.agent_version = av

            # 提取基础指标
            sysinfo = data.get('sysinfo', {})
            snapshot = MetricsSnapshot(
                node_id=node_id,
                collected_at=_parse_iso(data.get('collected_at', datetime.now(timezone.utc).replace(tzinfo=None).isoformat())),
                cpu_usage=sysinfo.get('cpu_usage'),
                cpu_cores=json.dumps(sysinfo.get('cpu_cores', [])),
                load_1=sysinfo.get('load_1'),
                load_5=sysinfo.get('load_5'),
                load_15=sysinfo.get('load_15'),
                mem_total=sysinfo.get('mem_total'),
                mem_used=sysinfo.get('mem_used'),
                mem_free=sysinfo.get('mem_free'),
                mem_usage=sysinfo.get('mem_usage'),
                swap_total=sysinfo.get('swap_total'),
                swap_used=sysinfo.get('swap_used'),
                swap_free=sysinfo.get('swap_free'),
                disk_info=json.dumps(sysinfo.get('disk_info', [])),
                cpu_temp=sysinfo.get('cpu_temp'),
                disk_temps=json.dumps(sysinfo.get('disk_temps', {})),
                net_info=json.dumps(sysinfo.get('net_info', {})),
                uptime=sysinfo.get('uptime'),
                raid_info=json.dumps(data.get('raid_info', {})),
                raw_data=json.dumps(data),
            )
            db.session.add(snapshot)

            # 定期清理：每50次上报必触发一次，删除90天前的历史MetricsSnapshot数据，
            # 并清理30天前的 raw_data（保留结构化字段用于趋势图表，释放数据库体积）
            try:
                import random
                if random.random() < 0.02 or (snapshot.id and snapshot.id % 50 == 0):
                    now = datetime.now(timezone.utc).replace(tzinfo=None)

                    # 清理 90 天前的完整记录
                    cutoff_90 = now - timedelta(days=90)
                    deleted = MetricsSnapshot.query.filter(MetricsSnapshot.collected_at < cutoff_90).delete()
                    if deleted > 0:
                        db.session.commit()
                        logger.info(f'已清理 {deleted} 条过期MetricsSnapshot记录(90天前)')

                    # 清理 30 天前的 raw_data（仅清空原始JSON，保留结构化指标字段）
                    cutoff_30 = now - timedelta(days=30)
                    cleared = MetricsSnapshot.query.filter(
                        MetricsSnapshot.collected_at < cutoff_30,
                        MetricsSnapshot.raw_data.isnot(None),
                        MetricsSnapshot.raw_data != '',
                    ).update({'raw_data': None})
                    if cleared > 0:
                        db.session.commit()
                        logger.info(f'已清理 {cleared} 条MetricsSnapshot的raw_data(30天前)')
            except Exception as cleanup_err:
                logger.warning(f'清理过期MetricsSnapshot失败: {cleanup_err}')

            # 进程数据
            proc_data = data.get('processes', {})
            if proc_data:
                proc_rec = ProcessRecord(
                    node_id=node_id,
                    collected_at=snapshot.collected_at,
                    cpu_top10=json.dumps(proc_data.get('cpu_top5', proc_data.get('cpu_top10', []))),
                    mem_top10=json.dumps(proc_data.get('mem_top5', proc_data.get('mem_top10', []))),
                    zombie_procs=json.dumps(proc_data.get('zombie', [])),
                    abnormal_procs=json.dumps(proc_data.get('abnormal', [])),
                    proc_count=proc_data.get('proc_count', 0),
                )
                db.session.add(proc_rec)

            # SMART数据
            for disk_smart in data.get('smart', []):
                sr = SmartRecord(
                    node_id=node_id,
                    collected_at=snapshot.collected_at,
                    disk_name=disk_smart.get('disk'),
                    disk_type=disk_smart.get('type', 'sata'),
                    health_status=disk_smart.get('health', 'UNKNOWN'),
                    reallocated_sectors=disk_smart.get('reallocated_sectors', 0),
                    power_on_hours=disk_smart.get('power_on_hours'),
                    temperature=disk_smart.get('temperature'),
                    wear_leveling=disk_smart.get('wear_leveling'),
                    nvme_spare=disk_smart.get('nvme_spare'),
                    disk_model=disk_smart.get('model'),
                    disk_serial=disk_smart.get('serial'),
                    disk_size=disk_smart.get('size'),
                    raw_data=json.dumps(disk_smart),
                )
                db.session.add(sr)

            # 登录记录
            for login in data.get('login_records', []):
                lr = LoginRecord(
                    node_id=node_id,
                    username=login.get('username'),
                    ip_address=login.get('ip'),
                    login_time=_parse_iso(login['time']) if login.get('time') else None,
                    is_abnormal=login.get('is_abnormal', False),
                    abnormal_reason=login.get('abnormal_reason', ''),
                )
                db.session.add(lr)

            # 系统日志
            for log_item in data.get('sys_logs', []):
                sl = SysLog(
                    node_id=node_id,
                    log_level=log_item.get('level', 'INFO'),
                    log_time=_parse_iso(log_item['time']) if log_item.get('time') else datetime.now(timezone.utc).replace(tzinfo=None),
                    source=log_item.get('source', ''),
                    message=log_item.get('message', ''),
                )
                db.session.add(sl)

            # 端口监听信息
            for port_info in data.get('listening_ports', []):
                pr = PortRecord(
                    node_id=node_id,
                    collected_at=snapshot.collected_at,
                    protocol=port_info.get('protocol', ''),
                    port=port_info.get('port', 0),
                    address=port_info.get('address', ''),
                    pid=port_info.get('pid', ''),
                    process=port_info.get('process', ''),
                )
                db.session.add(pr)

            # 资产信息（仅存储硬件信息，已移除软件清单）
            asset_data = data.get('assets', {})
            if asset_data:
                asset = AssetRecord.query.filter_by(node_id=node_id).first()
                if not asset:
                    asset = AssetRecord(node_id=node_id)
                    db.session.add(asset)
                old_hw = json.loads(asset.hardware_info or '{}')
                new_hw = asset_data.get('hardware', {})
                if old_hw and old_hw != new_hw:
                    changes = json.loads(asset.hardware_changes or '[]')
                    changes.append({'time': datetime.now(timezone.utc).replace(tzinfo=None).isoformat(), 'before': old_hw, 'after': new_hw})
                    asset.hardware_changes = json.dumps(changes[-50:])  # 保留最近50条
                asset.hardware_info = json.dumps(new_hw)

            db.session.commit()
            logger.info(f'节点 {node_id} 数据上报成功')
            resp = {'code': 0, 'msg': '上报成功'}
            if getattr(request, '_auto_registered', False):
                resp['token'] = getattr(request, '_node_token', '')
                resp['registered'] = True
            elif getattr(request, '_need_token', False):
                # 首次注册时服务端异常导致agent未拿到token，补发
                resp['token'] = getattr(request, '_node_token', '')
                resp['registered'] = False
            return jsonify(resp)

        except Exception as e:
            db.session.rollback()
            logger.error(f'处理上报数据异常: {e}', exc_info=True)
            return jsonify({'code': 500, 'msg': '服务器内部错误'}), 500

    @app.route('/api/report/alert', methods=['POST'])
    @node_api_auth
    def api_report_alert():
        """接收子节点实时告警（rsync/HTTP模式）"""
        try:
            data = parse_request_data()
            node_id = data.get('node_id') or request.headers.get('X-Node-ID')
            if not node_id:
                return jsonify({'code': 400, 'msg': '缺少node_id'}), 400

            # 更新节点最后在线时间
            node = _get_or_create_node(node_id, data.get('node_name') or data.get('hostname'))
            av = data.get('agent_version', '').strip()
            if av:
                node.agent_version = av

            # 存储安全事件
            for event in data.get('security_events', []):
                se = SecurityEvent(
                    node_id=node_id,
                    event_type=event.get('type', 'unknown'),
                    severity=event.get('severity', 'warning'),
                    title=event.get('title', ''),
                    detail=json.dumps(event.get('detail', {})),
                    occurred_at=_parse_iso(event['time']) if event.get('time') else datetime.now(timezone.utc).replace(tzinfo=None),
                )
                db.session.add(se)

            # 存储告警
            for alert in data.get('alerts', []):
                ar = AlertRecord(
                    node_id=node_id,
                    alert_type=alert.get('type', 'unknown'),
                    severity=alert.get('severity', 'warning'),
                    title=alert.get('title', ''),
                    message=alert.get('message', ''),
                    detail=json.dumps(alert.get('detail', {})),
                )
                db.session.add(ar)

            db.session.commit()
            logger.info(f'节点 {node_id} 告警数据接收成功')
            resp = {'code': 0, 'msg': '告警已接收'}
            if getattr(request, '_auto_registered', False):
                resp['token'] = getattr(request, '_node_token', '')
                resp['registered'] = True
            return jsonify(resp)

        except Exception as e:
            db.session.rollback()
            logger.error(f'处理告警数据异常: {e}', exc_info=True)
            return jsonify({'code': 500, 'msg': '服务器内部错误'}), 500

    @app.route('/api/report/heartbeat', methods=['POST'])
    @node_api_auth
    def api_heartbeat():
        """子节点心跳上报"""
        try:
            data = parse_request_data()
            node_id = data.get('node_id') or request.headers.get('X-Node-ID')
            if not node_id:
                return jsonify({'code': 400, 'msg': '缺少node_id'}), 400
            node = _get_or_create_node(node_id, data.get('node_name') or data.get('hostname'))
            if data.get('ip'):
                node.ip = data['ip']
            av = (data.get('agent_version') or '').strip()
            if av:
                node.agent_version = av
            db.session.commit()
            resp = jsonify({'code': 0, 'msg': 'ok', 'server_time': datetime.now(timezone.utc).replace(tzinfo=None).isoformat()})
            if getattr(request, '_auto_registered', False):
                resp = jsonify({
                    'code': 0, 'msg': 'ok',
                    'server_time': datetime.now(timezone.utc).replace(tzinfo=None).isoformat(),
                    'token': getattr(request, '_node_token', ''),
                    'registered': True,
                })
            return resp
        except Exception as e:
            db.session.rollback()
            logger.warning(f'心跳处理异常: {e}')
            return jsonify({'code': 500, 'msg': '服务器内部错误'}), 500

    # ══════════════════════════════════════════
    #  Web Dashboard 数据查询 API
    # ══════════════════════════════════════════

    @app.route('/api/nodes', methods=['GET'])
    @login_required
    def api_nodes():
        """获取所有节点列表（含未解决告警状态）"""
        nodes = Node.query.order_by(Node.last_seen.desc()).all()
        # 批量查询每个节点的最新指标，避免N+1问题
        from sqlalchemy import func
        latest_subq = db.session.query(
            MetricsSnapshot.node_id,
            func.max(MetricsSnapshot.collected_at).label('max_time')
        ).group_by(MetricsSnapshot.node_id).subquery()
        latest_snapshots = db.session.query(MetricsSnapshot).join(
            latest_subq,
            (MetricsSnapshot.node_id == latest_subq.c.node_id) &
            (MetricsSnapshot.collected_at == latest_subq.c.max_time)
        ).all()
        latest_map = {s.node_id: s for s in latest_snapshots}

        # 批量查询每个节点的未解决告警（仅critical/warning）
        unresolved_alerts = db.session.query(
            AlertRecord.node_id,
            AlertRecord.severity,
            AlertRecord.alert_type,
            AlertRecord.title,
        ).filter(
            AlertRecord.resolved.is_(False),
        ).order_by(AlertRecord.created_at.desc()).all()
        node_alert_map = {}
        for a in unresolved_alerts:
            if a.node_id not in node_alert_map:
                node_alert_map[a.node_id] = []
            node_alert_map[a.node_id].append(a)

        result = []
        for node in nodes:
            d = node.to_dict()
            latest = latest_map.get(node.node_id)
            if latest:
                d['latest_metrics'] = latest.to_dict()
                try:
                    d['net_info'] = json.loads(latest.net_info or '{}')
                    d['disk_info'] = json.loads(latest.disk_info or '[]')
                    d['disk_temps'] = json.loads(latest.disk_temps or '{}')
                except Exception:
                    pass
            # 告警状态：critical > warning > normal
            alerts = node_alert_map.get(node.node_id, [])
            critical_alerts = [a for a in alerts if a.severity == 'critical']
            warning_alerts = [a for a in alerts if a.severity == 'warning']
            if critical_alerts:
                d['alert_status'] = 'critical'
                d['alert_summary'] = f'{len(critical_alerts)} 个高危告警'
                d['alert_details'] = [{'severity': a.severity, 'type': a.alert_type, 'title': a.title} for a in critical_alerts[:5]]
            elif warning_alerts:
                d['alert_status'] = 'warning'
                d['alert_summary'] = f'{len(warning_alerts)} 个告警'
                d['alert_details'] = [{'severity': a.severity, 'type': a.alert_type, 'title': a.title} for a in warning_alerts[:5]]
            else:
                d['alert_status'] = 'normal'
                d['alert_summary'] = ''
                d['alert_details'] = []
            result.append(d)
        return jsonify({'code': 0, 'data': result})

    @app.route('/api/nodes/<node_id>', methods=['GET'])
    @login_required
    def api_node_detail(node_id):
        """获取节点详情（最新一条完整数据）"""
        node = Node.query.filter_by(node_id=node_id).first_or_404()
        d = node.to_dict()

        latest = MetricsSnapshot.query.filter_by(node_id=node_id) \
            .order_by(MetricsSnapshot.collected_at.desc()).first()
        if latest:
            raw = json.loads(latest.raw_data or '{}')
            d['sysinfo'] = raw.get('sysinfo', {})
            d['raw'] = raw
            try:
                d['cpu_cores'] = json.loads(latest.cpu_cores or '[]')
                d['disk_info'] = json.loads(latest.disk_info or '[]')
                d['net_info'] = json.loads(latest.net_info or '{}')
                d['disk_temps'] = json.loads(latest.disk_temps or '{}')
            except Exception:
                pass

        # 最新进程数据
        proc = ProcessRecord.query.filter_by(node_id=node_id) \
            .order_by(ProcessRecord.collected_at.desc()).first()
        if proc:
            try:
                d['cpu_top10'] = json.loads(proc.cpu_top10 or '[]')
                d['mem_top10'] = json.loads(proc.mem_top10 or '[]')
                d['zombie_procs'] = json.loads(proc.zombie_procs or '[]')
                d['abnormal_procs'] = json.loads(proc.abnormal_procs or '[]')
                d['proc_count'] = proc.proc_count or 0
            except Exception:
                pass

        # 最新SMART数据
        smarts = SmartRecord.query.filter_by(node_id=node_id) \
            .order_by(SmartRecord.collected_at.desc()).limit(20).all()
        d['smart_records'] = []
        seen_disks = set()
        for s in smarts:
            if s.disk_name not in seen_disks:
                seen_disks.add(s.disk_name)
                d['smart_records'].append({
                    'disk': s.disk_name,
                    'type': s.disk_type,
                    'health': s.health_status,
                    'reallocated': s.reallocated_sectors,
                    'power_hours': s.power_on_hours,
                    'temp': s.temperature,
                    'wear': s.wear_leveling,
                    'nvme_spare': s.nvme_spare,
                    'model': s.disk_model,
                    'serial': s.disk_serial,
                    'size': s.disk_size,
                })

        # 最近登录记录（仅最近5条）
        logins = LoginRecord.query.filter_by(node_id=node_id) \
            .order_by(LoginRecord.login_time.desc()).limit(5).all()
        d['login_records'] = [{
            'username': l.username, 'ip': l.ip_address,
            'time': l.login_time.isoformat() if l.login_time else '',
            'abnormal': l.is_abnormal, 'reason': l.abnormal_reason
        } for l in logins]

        # 最近安全事件
        events = SecurityEvent.query.filter_by(node_id=node_id) \
            .order_by(SecurityEvent.occurred_at.desc()).limit(20).all()
        d['security_events'] = [e.to_dict() for e in events]

        # 最近系统日志
        logs = SysLog.query.filter_by(node_id=node_id) \
            .order_by(SysLog.log_time.desc()).limit(50).all()
        d['sys_logs'] = [{
            'level': l.log_level, 'time': l.log_time.isoformat() if l.log_time else '',
            'source': l.source, 'message': l.message
        } for l in logs]

        # 最新监听端口（去重，保留最新采集时间）
        ports = PortRecord.query.filter_by(node_id=node_id) \
            .order_by(PortRecord.collected_at.desc()).limit(200).all()
        seen_ports = set()
        unique_ports = []
        for p in ports:
            key = (p.protocol, p.port)
            if key not in seen_ports:
                seen_ports.add(key)
                unique_ports.append({
                    'protocol': p.protocol, 'port': p.port,
                    'address': p.address, 'process': p.process, 'pid': p.pid
                })
        d['listening_ports'] = unique_ports

        # 最新RAID信息（从快照中获取）
        latest_snap = MetricsSnapshot.query.filter_by(node_id=node_id) \
            .order_by(MetricsSnapshot.collected_at.desc()).first()
        if latest_snap and latest_snap.raid_info:
            try:
                d['raid_info'] = json.loads(latest_snap.raid_info)
            except Exception:
                d['raid_info'] = {}
        else:
            d['raid_info'] = {}

        return jsonify({'code': 0, 'data': d})

    @app.route('/api/nodes/<node_id>/history', methods=['GET'])
    @login_required
    def api_node_history(node_id):
        """获取节点历史趋势数据"""
        hours = min(int(request.args.get('hours', 24)), 720)
        since = datetime.now(timezone.utc).replace(tzinfo=None) - timedelta(hours=hours)
        snapshots = MetricsSnapshot.query.filter(
            MetricsSnapshot.node_id == node_id,
            MetricsSnapshot.collected_at >= since
        ).order_by(MetricsSnapshot.collected_at.asc()).limit(2000).all()

        times, cpu, mem, disk_usage = [], [], [], []
        for s in snapshots:
            times.append(s.collected_at.strftime('%m-%d %H:%M'))
            cpu.append(round(s.cpu_usage or 0, 1))
            mem.append(round(s.mem_usage or 0, 1))
            # 取第一个分区使用率
            try:
                disks = json.loads(s.disk_info or '[]')
                if disks:
                    disk_usage.append(disks[0].get('use_percent', 0))
                else:
                    disk_usage.append(0)
            except Exception:
                disk_usage.append(0)

        return jsonify({'code': 0, 'data': {
            'times': times, 'cpu': cpu, 'mem': mem, 'disk': disk_usage
        }})

    @app.route('/api/nodes/<node_id>/net_history', methods=['GET'])
    @login_required
    def api_node_net_history(node_id):
        """获取节点网卡流量历史"""
        hours = min(int(request.args.get('hours', 1)), 720)
        since = datetime.now(timezone.utc).replace(tzinfo=None) - timedelta(hours=hours)
        snapshots = MetricsSnapshot.query.filter(
            MetricsSnapshot.node_id == node_id,
            MetricsSnapshot.collected_at >= since
        ).order_by(MetricsSnapshot.collected_at.asc()).limit(2000).all()

        times = []
        ifaces = {}
        _nic_re = re.compile(r'^(ens|eth|bond|enp|enx|eno)\w*\d*$')
        for s in snapshots:
            t = s.collected_at.strftime('%H:%M') if s.collected_at else ''
            times.append(t)
            # 记录当前时间点已处理的网卡，用于补零
            seen_this_tick = set()
            try:
                net = json.loads(s.net_info or '{}')
                for iface, stats in net.items():
                    if not _nic_re.match(iface):
                        continue
                    seen_this_tick.add(iface)
                    if iface not in ifaces:
                        ifaces[iface] = {'rx': [], 'tx': []}
                        # 补零：新出现的网卡需补齐之前所有时间点
                        prev_len = len(times) - 1
                        if prev_len > 0:
                            ifaces[iface]['rx'] = [0] * prev_len
                            ifaces[iface]['tx'] = [0] * prev_len
                    ifaces[iface]['rx'].append(stats.get('rx_speed', 0) or 0)
                    ifaces[iface]['tx'].append(stats.get('tx_speed', 0) or 0)
            except Exception:
                pass
            # 补零：本时间点未出现的已知网卡填0，保持长度一致
            for iface in ifaces:
                if iface not in seen_this_tick:
                    ifaces[iface]['rx'].append(0)
                    ifaces[iface]['tx'].append(0)

        return jsonify({'code': 0, 'data': {'times': times, 'ifaces': ifaces}})

    @app.route('/api/alerts', methods=['GET'])
    @login_required
    def api_alerts():
        """获取告警列表"""
        try:
            page = max(1, int(request.args.get('page', 1)))
            per_page = min(100, max(1, int(request.args.get('per_page', 20))))
        except (ValueError, TypeError):
            page, per_page = 1, 20
        node_id = request.args.get('node_id')
        resolved = request.args.get('resolved', 'false').lower() == 'true'

        q = AlertRecord.query.filter_by(resolved=resolved)
        if node_id:
            q = q.filter_by(node_id=node_id)
        q = q.order_by(AlertRecord.created_at.desc())
        pagination = q.paginate(page=page, per_page=per_page, error_out=False)

        return jsonify({'code': 0, 'data': {
            'total': pagination.total,
            'pages': pagination.pages,
            'current_page': page,
            'items': [a.to_dict() for a in pagination.items]
        }})

    @app.route('/api/alerts/<int:alert_id>/resolve', methods=['POST'])
    @login_required
    def api_resolve_alert(alert_id):
        """标记告警为已处理"""
        alert = AlertRecord.query.get_or_404(alert_id)
        alert.resolved = True
        alert.resolved_at = datetime.now(timezone.utc).replace(tzinfo=None)
        db.session.commit()
        return jsonify({'code': 0, 'msg': '已标记为处理'})

    @app.route('/api/alerts/resolve_batch', methods=['POST'])
    @login_required
    def api_resolve_alerts_batch():
        """批量处理告警：按级别（severity）或全部（all）"""
        data = request.get_json() or {}
        action = data.get('action', '')  # 'critical', 'warning', 'all'
        node_id = data.get('node_id', '')  # 可选：限定节点

        query = AlertRecord.query.filter_by(resolved=False)
        if node_id:
            query = query.filter_by(node_id=node_id)
        if action in ('critical', 'warning'):
            query = query.filter_by(severity=action)

        count = query.count()
        now = datetime.now(timezone.utc).replace(tzinfo=None)
        query.update({'resolved': True, 'resolved_at': now}, synchronize_session=False)
        db.session.commit()
        logger.info(f'批量处理告警: action={action}, node={node_id or "all"}, 共 {count} 条')
        return jsonify({'code': 0, 'msg': f'已处理 {count} 条告警', 'count': count})

    # ══════════════════════════════════════════
    #  节点管理 API
    # ══════════════════════════════════════════

    @app.route('/api/nodes', methods=['POST'])
    @login_required
    @admin_required
    def api_create_node():
        """手动添加节点"""
        data = request.get_json()
        if not data or not data.get('node_id'):
            return jsonify({'code': 400, 'msg': '缺少必要参数node_id'}), 400
        if len(data['node_id']) > 64:
            return jsonify({'code': 400, 'msg': 'node_id长度不能超过64字符'}), 400
        # 验证 node_id 仅包含合法字符
        if not re.match(r'^[\w\-\.]+$', data['node_id']):
            return jsonify({'code': 400, 'msg': 'node_id只能包含字母、数字、下划线、连字符和点号'}), 400
        if Node.query.filter_by(node_id=data.get('node_id')).first():
            return jsonify({'code': 400, 'msg': '节点ID已存在'})
        # 验证 IP 地址格式
        ip_val = data.get('ip', '')
        if ip_val:
            import ipaddress as _ipaddr
            try:
                _ipaddr.ip_address(ip_val)
            except ValueError:
                return jsonify({'code': 400, 'msg': 'IP地址格式无效'}), 400
        import secrets as _secrets
        token = _secrets.token_urlsafe(32)
        node = Node(
            node_id=data['node_id'],
            name=data.get('name', data['node_id']),
            ip=data.get('ip', ''),
            description=data.get('description', ''),
            token=token,
        )
        db.session.add(node)
        db.session.commit()
        logger.info(f'管理员手动添加节点 {data["node_id"]}，已生成token')
        return jsonify({'code': 0, 'msg': '添加成功', 'data': node.to_dict(), 'token': token})

    @app.route('/api/nodes/<node_id>', methods=['PUT'])
    @login_required
    @admin_required
    def api_update_node(node_id):
        """更新节点配置（含阈值）"""
        node = Node.query.filter_by(node_id=node_id).first_or_404()
        data = request.get_json()
        if 'name' in data:
            node.name = data['name']
        if 'description' in data:
            node.description = data['description']
        if 'thresholds' in data:
            node.set_thresholds(data['thresholds'])
        db.session.commit()
        return jsonify({'code': 0, 'msg': '更新成功'})

    @app.route('/api/nodes/<node_id>', methods=['DELETE'])
    @login_required
    @admin_required
    def api_delete_node(node_id):
        """删除节点"""
        node = Node.query.filter_by(node_id=node_id).first_or_404()
        # 级联删除关联数据
        nid = node.node_id
        MetricsSnapshot.query.filter_by(node_id=nid).delete()
        ProcessRecord.query.filter_by(node_id=nid).delete()
        SmartRecord.query.filter_by(node_id=nid).delete()
        LoginRecord.query.filter_by(node_id=nid).delete()
        SecurityEvent.query.filter_by(node_id=nid).delete()
        AlertRecord.query.filter_by(node_id=nid).delete()
        AssetRecord.query.filter_by(node_id=nid).delete()
        SysLog.query.filter_by(node_id=nid).delete()
        PortRecord.query.filter_by(node_id=nid).delete()
        db.session.delete(node)
        db.session.commit()
        return jsonify({'code': 0, 'msg': '删除成功'})

    @app.route('/api/nodes/clear_data', methods=['POST'])
    @login_required
    @admin_required
    def api_clear_node_data():
        """清除节点历史数据（保留节点本身和配置），支持单个节点或全部节点"""
        data = request.get_json() or {}
        target = (data.get('node_id') or '').strip()

        if not target:
            return jsonify({'code': 400, 'msg': '请指定节点ID'}), 400

        if target == 'all':
            node_ids = [n.node_id for n in Node.query.all()]
        else:
            node_ids = [target]

        if not node_ids:
            return jsonify({'code': 400, 'msg': '没有可清除的节点'}), 400

        total_deleted = 0
        details = {}
        for nid in node_ids:
            deleted = 0
            deleted += MetricsSnapshot.query.filter_by(node_id=nid).delete()
            deleted += ProcessRecord.query.filter_by(node_id=nid).delete()
            deleted += SmartRecord.query.filter_by(node_id=nid).delete()
            deleted += LoginRecord.query.filter_by(node_id=nid).delete()
            deleted += SecurityEvent.query.filter_by(node_id=nid).delete()
            deleted += AlertRecord.query.filter_by(node_id=nid).delete()
            deleted += SysLog.query.filter_by(node_id=nid).delete()
            deleted += PortRecord.query.filter_by(node_id=nid).delete()
            # 保留 AssetRecord（硬件资产信息）
            details[nid] = deleted
            total_deleted += deleted

        db.session.commit()
        node_names = []
        for nid in node_ids:
            n = Node.query.filter_by(node_id=nid).first()
            node_names.append(n.name if n else nid)

        logger.info(f'用户 {session.get("username")} 清除了 {len(node_ids)} 个节点的历史数据，共 {total_deleted} 条记录')
        return jsonify({
            'code': 0,
            'msg': f'已清除 {len(node_ids)} 个节点的历史数据，共 {total_deleted} 条记录',
            'data': {
                'nodes': node_names,
                'total_deleted': total_deleted,
                'details': details,
            }
        })

    # ══════════════════════════════════════════
    #  系统配置 API
    # ══════════════════════════════════════════

    @app.route('/api/config', methods=['GET'])
    @login_required
    def api_get_config():
        """获取系统配置（屏蔽密码）"""
        configs = SystemConfig.query.all()
        result = {}
        for c in configs:
            key_lower = c.key.lower()
            if any(kw in key_lower for kw in ('pass', 'secret', 'token', 'key')):
                result[c.key] = '******' if c.value else ''
            else:
                result[c.key] = c.value
        return jsonify({'code': 0, 'data': result})

    @app.route('/api/config', methods=['POST'])
    @login_required
    @admin_required
    def api_update_config():
        """更新系统配置（敏感字段自动加密存储）"""
        data = request.get_json()
        for key, value in data.items():
            if value == '******':
                continue  # 跳过未修改的密码
            # 加密敏感字段（SMTP密码等）
            key_lower = key.lower()
            if any(kw in key_lower for kw in ('pass', 'password', 'secret')):
                if value:
                    value = encrypt_value(str(value), app.secret_key)
            cfg = SystemConfig.query.filter_by(key=key).first()
            if cfg:
                cfg.value = str(value)
            else:
                cfg = SystemConfig(key=key, value=str(value))
                db.session.add(cfg)
        db.session.commit()
        return jsonify({'code': 0, 'msg': '配置已保存'})

    @app.route('/api/config/test_smtp', methods=['POST'])
    @login_required
    @admin_required
    def api_test_smtp():
        """测试SMTP邮件配置"""
        from services.alert_service import test_smtp_config
        data = request.get_json()
        ok, msg = test_smtp_config(
            host=data.get('smtp_host'),
            port=int(data.get('smtp_port', 465)),
            user=data.get('smtp_user'),
            password=data.get('smtp_pass'),
            ssl=data.get('smtp_ssl', 'true').lower() == 'true',
            to=data.get('test_recipient'),
        )
        return jsonify({'code': 0 if ok else -1, 'msg': msg})

    # ══════════════════════════════════════════
    #  报表 API
    # ══════════════════════════════════════════

    @app.route('/api/reports/dashboard', methods=['GET'])
    @login_required
    def api_reports_dashboard():
        """报表仪表盘数据（Web 展示模式）"""
        from services.report_service import get_dashboard_data
        days = min(int(request.args.get('days', 7)), 365)
        node_id = request.args.get('node_id')
        node_ids = [node_id] if node_id else None
        data = get_dashboard_data(app, days=days, node_ids=node_ids)
        return jsonify({'code': 0, 'data': data})

    @app.route('/api/reports/html', methods=['GET'])
    @login_required
    def api_reports_html():
        """生成并下载HTML报表"""
        from services.report_service import generate_period_report
        from flask import Response
        days = min(int(request.args.get('days', 7)), 365)
        node_id = request.args.get('node_id')
        title = request.args.get('title', '')
        node_ids = [node_id] if node_id else None
        html = generate_period_report(app, days=days, node_ids=node_ids, title=title or None)
        return Response(html, mimetype='text/html',
                        headers={'Content-Disposition': f'attachment; filename="report.html"'})

    @app.route('/api/reports/summary', methods=['GET'])
    @login_required
    def api_reports_summary():
        """生成汇总报表数据"""
        node_id = request.args.get('node_id')
        days = min(int(request.args.get('days', 7)), 365)
        since = datetime.now(timezone.utc).replace(tzinfo=None) - timedelta(days=days)

        q = MetricsSnapshot.query.filter(MetricsSnapshot.collected_at >= since)
        if node_id:
            q = q.filter_by(node_id=node_id)
        from sqlalchemy import func
        count_result = q.count()

        if count_result == 0:
            return jsonify({'code': 0, 'data': {}})

        import statistics
        # 使用 yield_per 分批加载避免OOM
        cpu_rows = list(q.with_entities(MetricsSnapshot.cpu_usage).yield_per(1000))
        mem_rows = list(q.with_entities(MetricsSnapshot.mem_usage).yield_per(1000))
        cpu_vals = [r[0] for r in cpu_rows if r[0] is not None]
        mem_vals = [r[0] for r in mem_rows if r[0] is not None]

        result = {
            'period_days': days,
            'data_points': count_result,
            'cpu': {
                'avg': round(statistics.mean(cpu_vals), 1) if cpu_vals else 0,
                'max': round(max(cpu_vals), 1) if cpu_vals else 0,
                'min': round(min(cpu_vals), 1) if cpu_vals else 0,
            },
            'mem': {
                'avg': round(statistics.mean(mem_vals), 1) if mem_vals else 0,
                'max': round(max(mem_vals), 1) if mem_vals else 0,
                'min': round(min(mem_vals), 1) if mem_vals else 0,
            },
            'alert_count': AlertRecord.query.filter(AlertRecord.created_at >= since).count(),
        }
        return jsonify({'code': 0, 'data': result})

    # ══════════════════════════════════════════
    #  资产管理 API
    # ══════════════════════════════════════════

    @app.route('/api/assets', methods=['GET'])
    @login_required
    def api_assets():
        """获取所有节点资产信息"""
        assets = AssetRecord.query.all()
        result = []
        for a in assets:
            node = Node.query.filter_by(node_id=a.node_id).first()
            result.append({
                'node_id': a.node_id,
                'node_name': node.name if node else a.node_id,
                'hardware': json.loads(a.hardware_info or '{}'),
                'hw_changes': json.loads(a.hardware_changes or '[]'),
                'updated_at': a.updated_at.isoformat() if a.updated_at else '',
            })
        return jsonify({'code': 0, 'data': result})

    # ══════════════════════════════════════════
    #  用户管理 API
    # ══════════════════════════════════════════

    @app.route('/api/users/change_password', methods=['POST'])
    @login_required
    @admin_required
    def api_change_password():
        """修改密码（无需原密码，密码已通过Werkzeug hash加密存储）"""
        data = request.get_json()
        if not data or not data.get('new_password'):
            return jsonify({'code': 400, 'msg': '新密码不能为空'}), 400
        new_pwd = data['new_password']
        if len(new_pwd) < 8:
            return jsonify({'code': 400, 'msg': '新密码长度至少8位'}), 400
        # 密码复杂度校验：必须包含大小写字母、数字
        has_upper = any(c.isupper() for c in new_pwd)
        has_lower = any(c.islower() for c in new_pwd)
        has_digit = any(c.isdigit() for c in new_pwd)
        has_special = any(c in '!@#$%^&*()_+-=[]{}|;:,.<>?' for c in new_pwd)
        if not (has_upper and has_lower and has_digit):
            return jsonify({'code': 400, 'msg': '密码必须包含大写字母、小写字母和数字'}), 400
        user = User.query.get(session['user_id'])
        user.set_password(new_pwd)
        # 修改密码成功后清除强制改密码标记
        fc = SystemConfig.query.filter_by(key='force_password_change').first()
        if fc:
            fc.value = 'false'
        db.session.commit()
        return jsonify({'code': 0, 'msg': '密码修改成功'})

    @app.route('/api/users/me', methods=['GET'])
    @login_required
    def api_user_me():
        """获取当前登录用户信息"""
        force_pw = get_config('force_password_change', 'false') == 'true'
        return jsonify({'code': 0, 'data': {
            'username': session.get('username'),
            'role': session.get('role'),
            'force_password_change': force_pw,
        }})

    @app.route('/api/server_time', methods=['GET'])
    @login_required
    def api_server_time():
        """获取服务器当前时间（含时区信息）"""
        try:
            tz_name = get_config('server_timezone', 'Asia/Shanghai')
            try:
                from zoneinfo import ZoneInfo
            except ImportError:
                try:
                    from backports.zoneinfo import ZoneInfo
                except ImportError:
                    ZoneInfo = None

            if ZoneInfo:
                try:
                    tz = ZoneInfo(tz_name)
                    now_tz = datetime.now(tz)
                    offset_sec = int(now_tz.utcoffset().total_seconds())
                except Exception:
                    now_tz = datetime.now(timezone.utc)
                    offset_sec = 0
                    tz_name = 'UTC'
            else:
                now_tz = datetime.now(timezone.utc)
                offset_sec = 0

            return jsonify({
                'code': 0,
                'data': {
                    'iso': now_tz.strftime('%Y-%m-%dT%H:%M:%S'),
                    'ts': int(now_tz.timestamp()),
                    'offset': offset_sec,
                    'tz': tz_name,
                }
            })
        except Exception as e:
            now = datetime.now(timezone.utc)
            return jsonify({
                'code': 0,
                'data': {
                    'iso': now.strftime('%Y-%m-%dT%H:%M:%S'),
                    'ts': int(now.timestamp()),
                    'offset': 0,
                    'tz': 'UTC',
                }
            })

    # ══════════════════════════════════════════
    #  节点在线状态 / Ping 检测 API
    # ══════════════════════════════════════════

    @app.route('/api/nodes/<node_id>/ping', methods=['POST'])
    @login_required
    def api_node_ping(node_id):
        """对节点发起ICMP ping检测，判断真实连通性"""
        node = Node.query.filter_by(node_id=node_id).first_or_404()
        ip = node.ip
        if not ip:
            return jsonify({'code': -1, 'msg': '节点IP未知，无法ping'})
        # 验证 IP 地址格式，防止命令注入
        import ipaddress as _ipaddr
        try:
            _ipaddr.ip_address(ip)
        except ValueError:
            return jsonify({'code': -1, 'msg': f'节点IP格式无效'})
        import platform, subprocess as _sp
        try:
            system = platform.system().lower()
            if system == 'windows':
                cmd = ['ping', '-n', '2', '-w', '1000', ip]
            else:
                cmd = ['ping', '-c', '2', '-W', '1', ip]
            result = _sp.run(cmd, capture_output=True, text=True, timeout=5)
            alive = result.returncode == 0
        except Exception:
            return jsonify({'code': -1, 'msg': 'Ping执行失败，请稍后重试'})
        return jsonify({
            'code': 0,
            'data': {
                'alive': alive,
                'ip': ip,
                'msg': '在线（ping通）' if alive else '无响应（ping不通）'
            }
        })

    @app.route('/api/nodes/<node_id>/uptime_dots', methods=['GET'])
    @login_required
    def api_node_uptime_dots(node_id):
        """返回最近N天每天是否有上报记录（用于卡片色块展示）"""
        days = min(int(request.args.get('days', 14)), 30)
        today = datetime.now(timezone.utc).replace(tzinfo=None).date()
        # 查询各天是否有MetricsSnapshot记录
        from sqlalchemy import func, cast
        import sqlalchemy as sa
        since = datetime.combine(today - timedelta(days=days-1), __import__('datetime').time.min)
        rows = db.session.query(
            func.date(MetricsSnapshot.collected_at).label('day'),
            func.count().label('cnt')
        ).filter(
            MetricsSnapshot.node_id == node_id,
            MetricsSnapshot.collected_at >= since
        ).group_by(func.date(MetricsSnapshot.collected_at)).all()

        day_set = set(str(r.day) for r in rows)
        result = []
        for i in range(days - 1, -1, -1):
            d = today - timedelta(days=i)
            result.append({
                'date': d.isoformat(),
                'online': d.isoformat() in day_set,
            })
        return jsonify({'code': 0, 'data': result})

    # ══════════════════════════════════════════
    #  数据导出 API
    # ══════════════════════════════════════════

    @app.route('/api/export/config', methods=['GET'])
    @login_required
    def api_get_export_config():
        """获取定时导出配置"""
        keys = ['export_enabled', 'export_path', 'export_cron', 'export_node_ids']
        result = {}
        for key in keys:
            cfg = SystemConfig.query.filter_by(key=key).first()
            result[key] = cfg.value if cfg else ''
        return jsonify({'code': 0, 'data': result})

    @app.route('/api/export/config', methods=['POST'])
    @login_required
    @admin_required
    def api_save_export_config():
        """保存定时导出配置"""
        data = request.get_json()
        allowed = {'export_enabled', 'export_path', 'export_cron', 'export_node_ids'}
        for key, value in data.items():
            if key not in allowed:
                continue
            cfg = SystemConfig.query.filter_by(key=key).first()
            if cfg:
                cfg.value = str(value)
            else:
                cfg = SystemConfig(key=key, value=str(value))
                db.session.add(cfg)
        db.session.commit()
        return jsonify({'code': 0, 'msg': '导出配置已保存'})

    @app.route('/api/export/now', methods=['POST'])
    @login_required
    @admin_required
    def api_export_now():
        """立即执行一次数据导出（导出到用户指定路径）"""
        data = request.get_json() or {}
        node_ids_str = data.get('node_ids', 'all')
        export_path  = data.get('export_path', '').strip()

        # 路径必须填写
        if not export_path:
            return jsonify({'code': 400, 'msg': '请填写导出路径'}), 400
        # 路径必须以 / 开头
        if not export_path.startswith('/'):
            return jsonify({'code': 400, 'msg': '导出路径必须是绝对路径（以 / 开头）'}), 400

        # 黑名单：不允许导出到系统关键目录
        _FORBIDDEN = ('/', '/root', '/root/.ssh', '/bin', '/dev', '/home', '/boot', '/etc',
                      '/lib', '/lib64', '/proc', '/run', '/srv', '/tmp', '/var',
                      '/sbin', '/sys', '/usr', '/media', '/opt',
                      '/initrd.img.old', '/vmlinuz')
        resolved = os.path.realpath(export_path)
        for d in _FORBIDDEN:
            real_d = os.path.realpath(d)
            if resolved == real_d or resolved.startswith(real_d + '/'):
                return jsonify({'code': 400, 'msg': f'不允许导出到系统目录: {d}'}), 400
        # 额外检查用户 .ssh 目录
        import glob as _glob
        for ssh_dir in _glob.glob('/home/*/.ssh') + ['/root/.ssh']:
            real_ssh = os.path.realpath(ssh_dir)
            if resolved == real_ssh or resolved.startswith(real_ssh + '/'):
                return jsonify({'code': 400, 'msg': f'不允许导出到敏感目录'}), 400

        try:
            os.makedirs(resolved, exist_ok=True)
        except Exception as e:
            return jsonify({'code': 500, 'msg': f'创建导出目录失败: {e}'}), 500

        if not node_ids_str or node_ids_str.strip() == 'all':
            nodes = Node.query.all()
            node_ids = [n.node_id for n in nodes]
        else:
            node_ids = [nid.strip() for nid in node_ids_str.split(',') if nid.strip()]

        exported_files = []
        errors = []
        for nid in node_ids:
            try:
                snap = MetricsSnapshot.query.filter_by(node_id=nid)\
                    .order_by(MetricsSnapshot.collected_at.desc()).first()
                if not snap:
                    errors.append(f'{nid}: 无数据')
                    continue
                export_data = _build_export_data(snap)
                ts = datetime.now(timezone.utc).replace(tzinfo=None).strftime('%Y%m%d_%H%M%S')
                safe_nid = re.sub(r'[^\w\-]', '_', nid)
                fname = f'{safe_nid}_{ts}.json'
                fpath = os.path.join(resolved, fname)
                with open(fpath, 'w', encoding='utf-8') as f:
                    json.dump(export_data, f, ensure_ascii=False, indent=2)
                exported_files.append(fname)
                logger.info(f'已导出节点 {nid} 数据: {fpath}')
            except Exception as e:
                errors.append(f'{nid}: {e}')
                logger.warning(f'导出节点 {nid} 失败: {e}')

        return jsonify({
            'code': 0,
            'msg': f'导出完成，成功 {len(exported_files)} 个节点' + (f'，{len(errors)} 个失败' if errors else ''),
            'exported': exported_files,
            'errors': errors,
        })

    def _build_export_data(snap):
        """从快照构建导出JSON数据，优先使用raw_data，不存在则从结构化字段重建"""
        if snap.raw_data:
            try:
                return json.loads(snap.raw_data)
            except Exception:
                pass
        # raw_data 已被清理（>30天），用结构化字段重建最小导出数据
        data = {
            'node_id': snap.node_id,
            'collected_at': snap.collected_at.isoformat() if snap.collected_at else None,
            'sysinfo': {
                'cpu_usage': snap.cpu_usage,
                'cpu_cores': json.loads(snap.cpu_cores or '[]'),
                'load_1': snap.load_1,
                'load_5': snap.load_5,
                'load_15': snap.load_15,
                'mem_total': snap.mem_total,
                'mem_used': snap.mem_used,
                'mem_free': snap.mem_free,
                'mem_usage': snap.mem_usage,
                'swap_total': snap.swap_total,
                'swap_used': snap.swap_used,
                'swap_free': snap.swap_free,
                'disk_info': json.loads(snap.disk_info or '[]'),
                'cpu_temp': snap.cpu_temp,
                'disk_temps': json.loads(snap.disk_temps or '{}'),
                'net_info': json.loads(snap.net_info or '{}'),
                'uptime': snap.uptime,
            },
            'raid_info': json.loads(snap.raid_info or '{}'),
            '_note': 'raw_data已过期被清理，此为结构化字段重建版本',
        }
        return data

    @app.route('/api/export/download', methods=['POST'])
    @login_required
    @admin_required
    def api_export_download():
        """将所有节点最新快照打包为ZIP并下载到浏览器"""
        import zipfile, tempfile
        from flask import send_file as flask_send_file

        node_ids_str = (request.get_json() or {}).get('node_ids', 'all')
        if not node_ids_str or node_ids_str.strip() == 'all':
            nodes = Node.query.all()
            node_ids = [n.node_id for n in nodes]
        else:
            node_ids = [nid.strip() for nid in node_ids_str.split(',') if nid.strip()]

        # 创建临时ZIP文件
        tmp_fd, tmp_path = tempfile.mkstemp(suffix='.zip')
        os.close(tmp_fd)
        try:
            from flask import after_this_request as _after_req
            @_after_req
            def _cleanup_zip(response):
                try:
                    if os.path.exists(tmp_path):
                        os.unlink(tmp_path)
                except Exception:
                    pass
                return response

            with zipfile.ZipFile(tmp_path, 'w', zipfile.ZIP_DEFLATED) as zf:
                for nid in node_ids:
                    snap = MetricsSnapshot.query.filter_by(node_id=nid) \
                        .order_by(MetricsSnapshot.collected_at.desc()).first()
                    if not snap:
                        continue
                    try:
                        export_data = _build_export_data(snap)
                        safe_nid = re.sub(r'[^\w\-]', '_', nid)
                        node_obj = Node.query.filter_by(node_id=nid).first()
                        name = (node_obj.name if node_obj else safe_nid)
                        ts = snap.collected_at.strftime('%Y%m%d_%H%M%S') if snap.collected_at else 'unknown'
                        arcname = f'{name}_{ts}.json'
                        zf.writestr(arcname, json.dumps(export_data, ensure_ascii=False, indent=2))
                    except Exception:
                        continue
            return flask_send_file(tmp_path, as_attachment=True,
                                   download_name=f'ops-monitor_export_{datetime.now().strftime("%Y%m%d_%H%M%S")}.zip',
                                   mimetype='application/zip')
        except Exception as e:
            logger.error(f'导出失败: {e}', exc_info=True)
            try:
                os.unlink(tmp_path)
            except Exception:
                pass
            return jsonify({'code': 500, 'msg': '导出失败，请查看服务器日志'}), 500

    # ── 定时导出后台调度线程 ──────────────────────────
    import time as _exp_time

    def _get_export_config_val(key, default=''):
        try:
            with app.app_context():
                cfg = SystemConfig.query.filter_by(key=key).first()
                return cfg.value if cfg else default
        except Exception:
            return default

    def _do_scheduled_export():
        """执行一次定时导出（在 app_context 内运行）"""
        with app.app_context():
            try:
                export_path = _get_export_config_val('export_path', '').strip()
                node_ids_str = _get_export_config_val('export_node_ids', 'all').strip()
                if not export_path:
                    return
                os.makedirs(export_path, exist_ok=True)

                if not node_ids_str or node_ids_str == 'all':
                    nodes = Node.query.all()
                    node_ids = [n.node_id for n in nodes]
                else:
                    node_ids = [nid.strip() for nid in node_ids_str.split(',') if nid.strip()]

                exported = 0
                for nid in node_ids:
                    try:
                        snap = MetricsSnapshot.query.filter_by(node_id=nid)\
                            .order_by(MetricsSnapshot.collected_at.desc()).first()
                        if not snap:
                            continue
                        export_data = _build_export_data(snap)
                        ts = datetime.now(timezone.utc).replace(tzinfo=None).strftime('%Y%m%d_%H%M%S')
                        safe_nid = re.sub(r'[^\w\-]', '_', nid)
                        fpath = os.path.join(export_path, f'{safe_nid}_{ts}.json')
                        with open(fpath, 'w', encoding='utf-8') as f:
                            json.dump(export_data, f, ensure_ascii=False, indent=2)
                        exported += 1
                    except Exception as e:
                        logger.warning(f'定时导出节点 {nid} 失败: {e}')
                if exported:
                    logger.info(f'定时导出完成，共 {exported} 个节点，路径: {export_path}')

                # 清理超过60天的旧导出文件
                try:
                    cutoff_60 = _exp_time.time() - 60 * 86400
                    cleaned_count = 0
                    for fname in os.listdir(export_path):
                        fpath = os.path.join(export_path, fname)
                        if os.path.isfile(fpath) and fname.endswith('.json'):
                            if os.path.getmtime(fpath) < cutoff_60:
                                try:
                                    os.remove(fpath)
                                    cleaned_count += 1
                                except Exception:
                                    pass
                    if cleaned_count > 0:
                        logger.info(f'已清理 {cleaned_count} 个超过60天的旧导出文件，路径: {export_path}')
                except Exception:
                    pass
            except Exception as e:
                logger.warning(f'定时导出任务异常: {e}')

    def _cron_matches(cron_expr, now):
        """判断 cron 表达式是否匹配当前时间
        支持标准5字段格式: 分 时 日 月 周
        向后兼容2字段格式: 分 时（等价于 * * * 分 时）
        """
        try:
            parts = cron_expr.strip().split()
            if len(parts) == 2:
                m_expr, h_expr = parts[0], parts[1]
                dom_expr, mon_expr, dow_expr = '*', '*', '*'
            elif len(parts) >= 5:
                m_expr, h_expr, dom_expr, mon_expr, dow_expr = parts[0], parts[1], parts[2], parts[3], parts[4]
            else:
                return False

            def match(expr, val):
                if expr == '*':
                    return True
                if expr.startswith('*/'):
                    step = int(expr[2:])
                    return step > 0 and val % step == 0
                if ',' in expr:
                    return str(val) in [x.strip() for x in expr.split(',')]
                if '-' in expr and not expr.startswith('*/'):
                    rng = expr.split('-')
                    return int(rng[0]) <= val <= int(rng[1])
                return int(expr) == val

            return (match(m_expr, now.minute) and
                    match(h_expr, now.hour) and
                    match(dom_expr, now.day) and
                    match(mon_expr, now.month) and
                    match(dow_expr, now.weekday()))
        except Exception:
            return False

    def _export_scheduler_worker():
        """每分钟检测 cron 表达式并触发导出"""
        last_triggered_minute = -1
        while True:
            try:
                _exp_time.sleep(30)
                enabled = _get_export_config_val('export_enabled', 'false').lower()
                if enabled != 'true':
                    continue
                cron_expr = _get_export_config_val('export_cron', '0 6').strip()
                now = datetime.now(timezone.utc).replace(tzinfo=None)
                current_minute = now.hour * 60 + now.minute
                if _cron_matches(cron_expr, now) and current_minute != last_triggered_minute:
                    last_triggered_minute = current_minute
                    logger.info(f'触发定时导出任务 (cron: {cron_expr})')
                    _do_scheduled_export()
            except Exception as e:
                logger.error(f'定时导出调度线程异常: {e}', exc_info=True)

    import threading as _exp_threading
    _export_sched_thread = _exp_threading.Thread(
        target=_export_scheduler_worker, daemon=True, name='export-scheduler'
    )
    _export_sched_thread.start()

    # ─────────────── Session 清理后台线程 ───────────────
    import threading
    import time as _time

    def _do_cleanup_sessions():
        """执行 session 文件清理"""
        session_dir = app.config.get('SESSION_FILE_DIR', '')
        # 清理超过 5 小时的 session 文件（有效期4小时 + 1小时宽限）
        max_age = app.config.get('PERMANENT_SESSION_LIFETIME', timedelta(hours=4)).total_seconds() + 3600
        if os.path.isdir(session_dir):
            cleaned = 0
            now = _time.time()
            for fname in os.listdir(session_dir):
                fpath = os.path.join(session_dir, fname)
                if os.path.isfile(fpath) and now - os.path.getmtime(fpath) > max_age:
                    try:
                        os.remove(fpath)
                        cleaned += 1
                    except Exception as cleanup_err:
                        logger.warning(f'清理过期session文件失败: {cleanup_err}')
            if cleaned > 0:
                logger.info(f'定时任务: 已清理 {cleaned} 个过期session文件')

    def _session_cleanup_worker():
        """后台定期清理过期 session"""
        while True:
            try:
                _time.sleep(3600)  # 每小时执行一次
                with app.app_context():
                    _do_cleanup_sessions()
            except Exception as e:
                logger.error(f'Session清理线程异常: {e}', exc_info=True)

    # 启动 session 清理后台线程（守护线程）
    _cleanup_thread = threading.Thread(target=_session_cleanup_worker, daemon=True)
    _cleanup_thread.start()

    # ── WAL 定期 checkpoint 线程 ──
    def _wal_checkpoint_worker():
        """每6小时执行一次 WAL checkpoint，防止 WAL 文件无限增长"""
        while True:
            try:
                _time.sleep(6 * 3600)
                with app.app_context():
                    try:
                        engine = db.get_engine(app)
                    except (KeyError, AttributeError):
                        engine = db.engine
                    with engine.connect() as conn:
                        conn.execute(text('PRAGMA wal_checkpoint(TRUNCATE)'))
                        conn.commit()
                    logger.info('WAL checkpoint 完成')
            except Exception as e:
                logger.warning(f'WAL checkpoint 失败: {e}')

    _ckpt_thread = threading.Thread(target=_wal_checkpoint_worker, daemon=True, name='wal-checkpoint')
    _ckpt_thread.start()

    return app


if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser(description='运维监控系统服务端')
    parser.add_argument('--port', type=int, default=8080, help='监听端口')
    parser.add_argument('--host', default='0.0.0.0', help='监听地址')
    parser.add_argument('--debug', action='store_true', help='调试模式')
    args = parser.parse_args()

    app = create_app()
    logger.info(f'服务端启动，监听 {args.host}:{args.port}')
    app.run(host=args.host, port=args.port, debug=args.debug)
